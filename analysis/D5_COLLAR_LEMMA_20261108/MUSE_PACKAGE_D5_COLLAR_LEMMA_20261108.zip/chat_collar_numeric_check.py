"""chat numeric check for the D5 collar lemma: kernel (10) vs numerical E_yy, |K|*D, |dK/ds|*D^2, max R''."""
import mpmath as mp, random, math
mp.mp.dps=40
def geom(lam,xi,p):
    x=(xi[0],xi[1],lam*xi[2]); v=[x[i]-p[i] for i in range(3)]; D=mp.sqrt(sum(c*c for c in v))
    w=mp.sqrt(lam**2*(xi[0]**2+xi[1]**2)+xi[2]**2); n=(lam*xi[0]/w,lam*xi[1]/w,xi[2]/w)
    h=w*sum(v[i]*n[i] for i in range(3)); return x,v,D,w,n,h
def FE(lam,xi,p):
    x,v,D,w,n,h=geom(lam,xi,p); g=h/(w*D); return h*mp.acos(g)**2
def R(g): return mp.acos(g)/mp.sqrt(1-g*g)
def Rp(g): return mp.diff(R,g)
def K(lam,xi,p):
    x,v,D,w,n,h=geom(lam,xi,p); g=h/(w*D); T=v[1]/D; e=g*T-n[1]; S=g*g*(1-T*T)-2*e*e
    return 2*w/D*(R(g)*S-g*Rp(g)*e*e)
print("max R'' =", 4*mp.quad(lambda t:(1-t*t)**2/(1+t*t)**3,[0,1]), "(gamma=0)")
random.seed(5); m9=0; m66=0
for k in range(12):
    lam=mp.mpf(random.uniform(0.4,0.66)); tau=random.random(); a=(1-tau*tau)/(1+tau*tau); b=2*tau/(1+tau*tau)
    r=mp.mpf(random.uniform(15/16,0.9999)); p=(r*a,0,r*lam*b)
    th=random.uniform(0,math.pi); ph=random.uniform(0,2*math.pi)
    xi=[mp.mpf(math.sin(th)*math.cos(ph)),mp.mpf(math.sin(th)*math.sin(ph)),mp.mpf(math.cos(th))]; nn=mp.sqrt(sum(c*c for c in xi)); xi=[c/nn for c in xi]
    fd=mp.diff(lambda y: FE(lam,xi,(p[0],y,p[2])),0,2); kk=K(lam,xi,p); D=geom(lam,xi,p)[2]
    dk=mp.diff(lambda s: K(lam,xi,(s*a,0,s*lam*b)),r)
    m9=max(m9,abs(kk)*D); m66=max(m66,abs(dk)*D**2)
    print(k,'FD E_yy %.10e  K(10) %.10e'%(float(fd),float(kk)))
print('max |K|*D %.4f (bound 9) | max |dK/ds|*D^2 %.4f (bound 66)'%(float(m9),float(m66)))
