"""Exact algebra and rational-constant checks for a paper lemma.
No quadrature, positivity sampling, certificate run, or independent audit.
"""
from fractions import Fraction as F
from pathlib import Path
import json,hashlib

# Laurent polynomials in g,T,n,R,Rp,w,D; D is strictly positive.
NV=7
def const(x): return {(0,)*NV:F(x)} if x else {}
def var(i,power=1):
    e=[0]*NV;e[i]=power
    return {tuple(e):F(1)}
def add(*ps):
    r={}
    for p in ps:
        for e,v in p.items():r[e]=r.get(e,F(0))+v
    return {e:v for e,v in r.items() if v}
def mul(*ps):
    r=const(1)
    for p in ps:
        z={}
        for e,a in r.items():
            for f,b in p.items():
                h=tuple(x+y for x,y in zip(e,f));z[h]=z.get(h,F(0))+a*b
        r={e:v for e,v in z.items() if v}
    return r
def scale(p,a):return mul(const(a),p)
def neg(p):return scale(p,-1)
g,T,n,R,Rp,w,D=[var(i) for i in range(NV)]
invD=var(6,-1)
e=add(mul(g,T),neg(n))
gy=mul(e,invD)
gyy=mul(add(scale(mul(e,T),2),neg(mul(g,add(const(1),neg(mul(T,T)))))),invD,invD)
h=mul(w,D,g);hy=neg(mul(w,n))
direct=add(scale(mul(hy,R,gy),-4),scale(mul(h,Rp,gy,gy),-2),scale(mul(h,R,gyy),-2))
S=add(mul(g,g,add(const(1),neg(mul(T,T)))),scale(mul(e,e),-2))
compact=scale(mul(w,invD,add(mul(R,S),neg(mul(g,Rp,e,e)))),2)
assert not add(direct,neg(compact))

# Exact polynomial division proving integral x^4(1-x)^4/(1+x^2) = 22/7-pi.
poly=[F(0)]*9
for k,a in enumerate([1,-4,6,-4,1],4):poly[k]=F(a)
quot=[F(0)]*7
for k in range(8,1,-1):
    a=poly[k];quot[k-2]=a;poly[k]-=a;poly[k-2]-=a
assert poly[0]==-4 and all(v==0 for v in poly[1:])
assert sum((v/F(i+1) for i,v in enumerate(quot)),F(0))==F(22,7)

pi_upper=F(22,7)
C2=F(9);C3=F(66)
assert 2*pi_upper+2<C2
assert F(32,15)<3
assert 2*((pi_upper+1)+(10+6*pi_upper))==C3
assert F(25,36)<F(7,10) # atanh series bound for log 2
m=F(2,5);r0=F(15,16)
assert 2*r0*m*m==F(3,10)
assert F(3,10)>F(1,4)
near_coefficient=2*C2/(m*F(1,2));far_coefficient=C3/(2*m*F(3,10))
assert near_coefficient==90 and far_coefficient==275
kappa=F(1,100000000);sqrt_kappa=F(1,10000);epsilon=F(1,60000)
assert sqrt_kappa**2==kappa and 1-epsilon>=r0
assert 2/kappa<2**28
log_upper=28*F(7,10)
A=near_coefficient*sqrt_kappa;B=far_coefficient*log_upper
error=A+B*epsilon;lower=F(1,5)-error
assert A==F(9,1000) and B==5390
assert error==F(593,6000)<F(1,10)
assert lower==F(607,6000)>F(1,10)
result={'status':'EXACT_PAPER_ALGEBRA_CHECKS_ONLY_NOT_CERTIFICATE_OR_AUDIT',
        'directional_kernel_laurent_identity':'zero polynomial',
        'pi_upper_integral_identity':'exact',
        'C2':str(C2),'C3':str(C3),'A_coefficient':str(near_coefficient),
        'B_log_coefficient':str(far_coefficient),'kappa':str(kappa),'epsilon':str(epsilon),
        'A':str(A),'B_rational_upper':str(B),'error_upper':str(error),
        'H_lower_from_boundary_input':str(lower),'delta_max':str(2*epsilon-epsilon**2),
        'not_run':['H numerical sampling','production','independent verifier','Judge adoption']}
p=Path(__file__).with_name('collar_algebra_result.json')
p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
