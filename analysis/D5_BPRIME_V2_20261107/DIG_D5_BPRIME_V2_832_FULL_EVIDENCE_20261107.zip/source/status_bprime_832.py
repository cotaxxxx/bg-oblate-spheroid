#!/usr/bin/env python3
"""Read-only full Bprime status and strict completeness gate."""
from pathlib import Path
from fractions import Fraction as F
import json,sys,hashlib
R=Path(__file__).resolve().parent.parent
COVER=R/'inputs/bprime_cover_32x26.json'
PROD=R/'producer/boxes'
VER=R/'verifier/chat_bprime_verifier_full.jsonl'
def sig(b):return (F(b['tau'][0]),F(b['tau'][1]),F(b['lam'][0]),F(b['lam'][1]))
data=json.loads(COVER.read_text());boxes=data['boxes']
assert len(boxes)==832 and data['cells']=={'r':32,'s':32}
idx={sig(b):i for i,b in enumerate(boxes)}
assert len(idx)==832
p={}
for x in PROD.glob('[0-9][0-9][0-9][0-9].json'):
 v=json.loads(x.read_text());i=v['index']
 assert x.stem==f'{i:04d}' and i in range(832) and sig(v['box'])==sig(boxes[i])
 assert v['status']=='COMPLETED' and v['pass']==(F(v['lower'])>=F(1,5))
 p[i]=v
v={}
if VER.exists():
 with open(VER) as f:
  for line_no,line in enumerate(f,1):
   if not line.strip():continue
   row=json.loads(line);key=sig(row['box'])
   assert key in idx,('outside cover',line_no)
   i=idx[key]
   assert i not in v,('duplicate verifier result',i)
   assert row['cells']=={'r':32,'s':32}
   assert row['pass']==(F(row['lower'])>=F(1,5))
   v[i]=row
both=set(p)&set(v)
failp=[i for i,x in p.items() if not x['pass']]
failv=[i for i,x in v.items() if not x['pass']]
def worst(records):return min(records.items(),key=lambda kv:F(kv[1]['lower'])) if records else None
wp=worst(p);wv=worst(v)
print('BPRIME_832_STATUS')
print('producer:',len(p),'/832','PASS',len(p)-len(failp),'FAIL',len(failp))
print('verifier:',len(v),'/832','PASS',len(v)-len(failv),'FAIL',len(failv))
print('both_have:',len(both),'of 832')
print('producer_min:',None if wp is None else (wp[0],str(float(F(wp[1]['lower'])))))
print('verifier_min:',None if wv is None else (wv[0],str(float(F(wv[1]['lower'])))))
print('all_done:',len(p)==832 and len(v)==832)
print('both_all_pass:',len(p)==832 and len(v)==832 and not failp and not failv)
if len(p)==832 and len(v)==832:
 verdict='BPRIME_FACE_ALL_832_CANDIDATE_PASS' if not failp and not failv else 'NOT_PASS'
 final={'status':verdict,'producer_count':len(p),'verifier_count':len(v),
        'cover_sha256':hashlib.sha256(COVER.read_bytes()).hexdigest(),
        'producer_min_lower':wp[1]['lower'],'producer_min_index':wp[0],
        'verifier_min_lower':wv[1]['lower'],'verifier_min_index':wv[0],
        'producer_fails':failp,'verifier_fails':failv,
        'requires_chat_20_box_recheck':True,'gamma_sos_registration_pending':True,
        'color_and_general_domain':'OPEN','ft_q_v4_cross_check':'OPEN'}
 path=R/'state/FINAL_CHECK.json'
 path.write_text(json.dumps(final,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
 print('FINAL_CHECK_WRITTEN',path,'verdict',verdict)
