#!/bin/bash
# D5 B-prime v2: pause producer until unchanged chat verifier exits; resume from per-box results.
# Safe runner operates only under D5_BOUNDARY_BPRIME_V2_FULL_20261107. Does not touch B7.
set -euo pipefail
ROOT=/home/daybreak/D5_BOUNDARY_BPRIME_V2_FULL_20261107
cd "$ROOT"
exec 9>state/bprime_resume.lock
flock -n 9 || { echo 'ANOTHER RESUMER ACTIVE'; exit 3; }
date '+%F %T %Z'
echo 'PAUSED: producer checkpointed; waiting for original chat verifier completion'
while [[ ! -f state/chat_verifier_exit_code.txt ]]; do
 sleep 15
done
echo 'CHAT_EXIT_CODE' "$(cat state/chat_verifier_exit_code.txt)"
if [[ $(cat state/chat_verifier_exit_code.txt) != 0 ]]; then
 echo 'CHAT_ERROR: do not start Dig. Requires inspection.'
 exit 4
fi
if ! grep -q 'BPRIME VERDICT:' logs/chat_verifier_run.log; then
 echo 'CHAT_VERDICT_MISSING: do not start Dig.'
 exit 5
fi
for attempt in $(seq 1 180); do
 # Require 10 GiB memory headroom to protect all other processes.
 avail_kb=$(awk '/MemAvailable/ {print $2}' /proc/meminfo)
 if (( avail_kb > 10485760 )); then break; fi
 sleep 20
done
if (( avail_kb <= 10485760 )); then
 echo 'LOW_RAM_BLOCK: Dig resume prevented; no B7 changes'
 exit 6
fi
if pgrep -f 'python.*[d]ig_bprime_832_batch.py --workers' >/dev/null; then
 echo 'DIG_ALREADY_ACTIVE: no duplicate batch'
 exit 7
fi
echo 'RESUMING_DIG_AFTER_CHAT_AND_RAM_CHECK'
date '+%F %T %Z'
set +e
nice -n 18 taskset -c 8,9 /home/daybreak/.pyenv/versions/3.11.16/bin/python -u source/dig_bprime_832_batch.py --workers 2 --limit 832 > logs/dig_producer_resume.log 2>&1
rc=$?
set -e
echo "$rc" > state/dig_producer_exit_code.txt
echo DIG_RESUME_EXIT="$rc"
if (( rc != 0 )); then
 echo 'DIG_ERROR: no evidence package produced'
 exit "$rc"
fi
python3 source/status_bprime_832.py > logs/dig_final_check.log 2>&1
cat logs/dig_final_check.log
if ! grep -q 'both_all_pass: True' logs/dig_final_check.log; then
 echo 'ALL_BOXES_NOT_PASS: no PASS evidence ZIP'
 exit 8
fi
python3 source/package_bprime_832.py > logs/package_bprime_832.log 2>&1
cat logs/package_bprime_832.log
echo 'FULL_EVIDENCE_PACKAGE_COMPLETE'
