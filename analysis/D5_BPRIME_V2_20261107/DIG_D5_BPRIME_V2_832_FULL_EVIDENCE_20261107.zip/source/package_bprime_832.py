#!/usr/bin/env python3
"""Strict evidence packaging after BOTH original full-run programs exit successfully.
Produces ZIP without modifying B7, original sources, or result files.
"""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,zipfile,random,sys
R=Path(__file__).resolve().parent.parent
P=R/'producer';V=R/'verifier';STATE=R/'state'; SRC=R/'source'
CAL=Path('/home/daybreak/D5_BOUNDARY_BPRIME_V2_CAL_20261107')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def key(b):return (F(b['tau'][0]),F(b['tau'][1]),F(b['lam'][0]),F(b['lam'][1]))
assert (STATE/'dig_producer_exit_code.txt').read_text().strip()=='0'
assert (STATE/'chat_verifier_exit_code.txt').read_text().strip()=='0'
assert sha(R/'inputs/bprime_cover_32x26.json')=='071062a9f4eddbd8c90195c892d6408d4c50e77024f1db8e899a080e21cca291'
assert sha(SRC/'bprime_v2_pilot.py')=='d60fe187150db01fd92420353da43e1ac186a5cd4a802f206976e7a4c888f531'
assert sha(SRC/'chat_bprime_iv.py')=='93b9431dffee9931675b9adf937f99118981b7128f0e6c89699b8158a452d098'
cover=json.loads((R/'inputs/bprime_cover_32x26.json').read_text())
boxes=cover['boxes'];assert len(boxes)==832 and cover['cells']=={'r':32,'s':32}
dprod={}
for i in range(832):
 path=P/'boxes'/f'{i:04d}.json'
 assert path.is_file(),path
 x=json.loads(path.read_text())
 assert x['index']==i and key(x['box'])==key(boxes[i])
 assert x['status']=='COMPLETED' and x['pass']==(F(x['lower'])>=F(1,5))
 dprod[i]=x
verfile=V/'chat_bprime_verifier_full.jsonl'
vrows=[json.loads(line) for line in verfile.read_text().splitlines() if line.strip()]
assert len(vrows)==832,len(vrows)
keys={key(b):i for i,b in enumerate(boxes)};assert len(keys)==832
dver={}
for x in vrows:
 k=key(x['box']);assert k in keys,k
 idx=keys[k];assert idx not in dver
 assert x['pass']==(F(x['lower'])>=F(1,5))
 dver[idx]=x
assert len(dver)==832
log=(R/'logs/chat_verifier_run.log').read_text()
assert 'BPRIME VERDICT: PASS' in log,log[-900:]
original_producer_log=(R/'logs/dig_producer_run.log').read_text()
resumed_producer_log=(R/'logs/dig_producer_resume.log').read_text()
assert 'DIG_PRODUCER_FINISHED DONE ALL_PASS True PASS_COUNT 832' in original_producer_log+resumed_producer_log
(R/'logs/dig_producer_run_combined.log').write_text(original_producer_log+'\\n=== SAFE DIG RESUME AFTER CHAT VERIFIER ===\\n'+resumed_producer_log)
assert all(x['pass'] for x in dprod.values()) and all(x['pass'] for x in dver.values())
worstp=sorted(dprod,key=lambda i:F(dprod[i]['lower']))[:10]
worstv=sorted(dver,key=lambda i:F(dver[i]['lower']))[:10]
rng=random.Random(20261107)
random10=rng.sample([i for i in range(832) if i not in worstv],10)
out=[]
for kind,indices in (('verifier_lowest10',worstv),('verifier_random10',random10)):
 for i in indices:
  out.append(dict(category=kind,index=i,box=boxes[i],
                  verifier_lower_exact=dver[i]['lower'],producer_lower_exact=dprod[i]['lower']))
sample=STATE/'RECHECK_20_BOXES.json'
sample.write_text(json.dumps({'status':'SAMPLE_CANDIDATE_FOR_CHAT_RECOMPUTATION',
'seed':20261107,'selection':'verifier 10 smallest exact bounds + 10 reproducible random distinct',
'entries':out},ensure_ascii=False,indent=2)+'\n')
summary={'status':'BPRIME_FACE_ALL_832_PRODUCER_AND_VERIFIER_PASS_CANDIDATE',
 'coverage':'face r=1 only; collar/general remain OPEN',
 'target':'1/5','count':832,'producer_min_exact':dprod[worstp[0]]['lower'],
 'producer_min_float':float(F(dprod[worstp[0]]['lower'])),
 'producer_min_box':boxes[worstp[0]],
 'verifier_min_exact':dver[worstv[0]]['lower'],
 'verifier_min_float':float(F(dver[worstv[0]]['lower'])),
 'verifier_min_box':boxes[worstv[0]],
 'cover_sha256':sha(R/'inputs/bprime_cover_32x26.json'),
 'warning':'user note mentions cover SHA prefix deb6bc3b, does NOT match pinned source 071062a9',
 'chat_20_box_recheck':'PENDING','gamma_SOS_evidence':'NOT_INCLUDED_PENDING_FORMAL_REGISTRATION',
 'FT_q_V4':'NOT_CROSS_CHECKED','B7_V53':'STOPPED_LOW_MEMORY_20261107_1233_NO_DIRECT_B7_MUTATION'}
summary_path=STATE/'RUN_COMPLETION_SUMMARY.json'
summary_path.write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
need=[
 R/'inputs/bprime_cover_32x26.json',
 R/'inputs/D5_BOUNDARY_FACE_BPRIME_SPEC_20261106.md',
 R/'inputs/D5_BOUNDARY_FACE_BPRIME_SPEC_V2_DELTA_20261107.md',
 R/'inputs/MUSE_REQUEST_D5_BPRIME_V2_VERIFIER_20261107.md',
 SRC/'bprime_v2_pilot.py',SRC/'chat_bprime_iv.py',
 SRC/'chat_m22iv.py',SRC/'chat_m40iv.py',SRC/'dig_bprime_832_batch.py',
 SRC/'status_bprime_832.py',SRC/'resume_after_verifier.sh',SRC/'package_bprime_832.py',
 P/'dig_bprime_producer_full.jsonl',
 P/'DONE.json',
 V/'chat_bprime_verifier_full.jsonl',
 R/'logs/chat_verifier_run.log',
 R/'logs/dig_producer_run.log',R/'logs/dig_producer_resume.log',R/'logs/dig_producer_run_combined.log',
 STATE/'RUN_MANIFEST.json',STATE/'INPUT_PINS.json',
 STATE/'dig_producer_exit_code.txt',STATE/'chat_verifier_exit_code.txt',
 STATE/'RECHECK_20_BOXES.json',STATE/'FINAL_CHECK.json',summary_path,
 CAL/'V2_CALIBRATION_SUMMARY.json',
 CAL/'V2_CALIBRATION_REPORT.md',
 CAL/'DIG_Q1_ENDPOINT_NOTE_20261107.md',
 CAL/'DIG_Q1_ENDPOINT_CHECKS_20261107.json',
]
for i in range(832):need.append(P/'boxes'/f'{i:04d}.json')
assert all(x.exists() for x in need),[str(p) for p in need if not p.exists()]
paths={}
for x in need:
 if x.is_relative_to(R):dest=x.relative_to(R).as_posix()
 else:dest='calibration/'+x.name
 assert dest not in paths,dest
 paths[dest]=x
files={k:{'sha256':sha(v),'bytes':v.stat().st_size} for k,v in paths.items()}
manifest={'name':'DIG_D5_BPRIME_V2_832_FULL_EVIDENCE_20261107.zip',
          'count_files_excluding_manifest':len(paths),
          'source_pins':{'cover':'071062a9f4eddbd8c90195c892d6408d4c50e77024f1db8e899a080e21cca291',
          'pilot':'d60fe187150db01fd92420353da43e1ac186a5cd4a802f206976e7a4c888f531',
          'verifier':'93b9431dffee9931675b9adf937f99118981b7128f0e6c89699b8158a452d098'},
          'files':files,
          'formal_adoption':'PENDING CHAT 20-BOX CHECK; FACE ONLY',
          'memory_incident':'B7 automatically stopped 2026-11-07 12:33 due to B-prime resource contention',
          'git':'unchanged; no commit/push'}
mp=STATE/'EVIDENCE_MANIFEST.json'
mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
zip_path=R/'DIG_D5_BPRIME_V2_832_FULL_EVIDENCE_20261107.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for dest,source in paths.items():z.write(source,arcname=dest)
 z.write(mp,arcname='state/EVIDENCE_MANIFEST.json')
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(paths)+1
 for dest,source in paths.items():assert hashlib.sha256(z.read(dest)).hexdigest()==sha(source)
print('FULL_832_EVIDENCE_ZIP',zip_path)
print('ZIP_SHA256',sha(zip_path),'bytes',zip_path.stat().st_size)
print('MANIFEST_SHA256',sha(mp),'file_count',len(paths)+1)
print('MIN_PRODUCER',summary['producer_min_float'],'MIN_VERIFIER',summary['verifier_min_float'])
print('CHAT_RECHECK_CANDIDATES',len(out))
