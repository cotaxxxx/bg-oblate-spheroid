#!/usr/bin/env python3
"""Dig producer 832 boxes. Adapter ONLY; original bprime_v2_pilot.py unchanged.
Resumable per-box atomic outputs. Verifier is independent and run separately.
"""
from __future__ import annotations
from pathlib import Path
from fractions import Fraction as F
import sys,os,json,time,hashlib,argparse,traceback
from multiprocessing import get_context
R=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(R/'source'))
import bprime_v2_pilot as PILOT
COVER=R/'inputs/bprime_cover_32x26.json'
OUT=R/'producer'
EXPECTED_SHA='071062a9f4eddbd8c90195c892d6408d4c50e77024f1db8e899a080e21cca291'
PILOT_SHA='d60fe187150db01fd92420353da43e1ac186a5cd4a802f206976e7a4c888f531'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ident(b):return (F(b['tau'][0]),F(b['tau'][1]),F(b['lam'][0]),F(b['lam'][1]))
def validate_cover(data):
 boxes=data['boxes'];assert len(boxes)==832
 assert data['cells']=={'r':32,'s':32}
 keys=[ident(b) for b in boxes]
 assert len(set(keys))==832
 ts=sorted({(b[0],b[1]) for b in keys});ls=sorted({(b[2],b[3]) for b in keys})
 assert len(ts)==32 and len(ls)==26
 assert ts[0][0]==0 and ts[-1][1]==1 and ls[0][0]==F(2,5) and ls[-1][1]==F(33,50)
 assert all(a[0]<a[1] and a[1]==b[0] for a,b in zip(ts,ts[1:]))
 assert all(a[0]<a[1] and a[1]==b[0] for a,b in zip(ls,ls[1:]))
 assert set(keys)=={(t0,t1,l0,l1) for t0,t1 in ts for l0,l1 in ls}
 return boxes
def work(arg):
 i,box=arg;t=time.time()
 try:
  params={'name':f'BOX_{i:04d}','tau':box['tau'],'lam':box['lam']}
  v=PILOT.compute(params,32,'whole')
  return {'index':i,'box':box,'status':'COMPLETED','lower':v['lower_exact'],
          'lower_float':v['lower_decimal'],'pass':F(v['lower_exact'])>=F(1,5),
          'mid_lower':v['raw_mid_lower_exact'],'curv_lower':v['raw_curvature_lower_exact'],
          'elapsed_seconds':v['seconds'],'source_sha256':PILOT_SHA,
          'check_source_sha256':sha(R/'source/bprime_v2_pilot.py')}
 except Exception:
  return {'index':i,'box':box,'status':'ERROR','error':traceback.format_exc(),
          'elapsed_seconds':time.time()-t}
def atomic_json(path,v):
 tmp=path.with_suffix('.tmp.'+str(os.getpid()))
 with open(tmp,'w') as f:
  json.dump(v,f,ensure_ascii=False,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
 os.replace(tmp,path)
def main():
 p=argparse.ArgumentParser();p.add_argument('--workers',type=int,default=2);p.add_argument('--limit',type=int,default=832)
 a=p.parse_args()
 assert 1<=a.workers<=4
 assert a.limit in (1,832),a.limit
 assert sha(COVER)==EXPECTED_SHA
 assert sha(R/'source/bprime_v2_pilot.py')==PILOT_SHA
 boxes=validate_cover(json.loads(COVER.read_text()))
 OUT.mkdir(exist_ok=True);(OUT/'boxes').mkdir(exist_ok=True)
 todo=[];completed={}
 for i,b in enumerate(boxes[:a.limit]):
  path=OUT/'boxes'/f'{i:04d}.json'
  if path.exists():
   v=json.loads(path.read_text())
   assert v['index']==i and ident(v['box'])==ident(b)
   assert v['source_sha256']==PILOT_SHA
   assert v['status']=='COMPLETED'
   assert v['pass']==(F(v['lower'])>=F(1,5))
   completed[i]=v
  else:todo.append((i,b))
 print('DIG_PRODUCER_COVER PASS 832 SHA',EXPECTED_SHA,'grid 32x32',flush=True)
 print('DIG_PRODUCER_START workers',a.workers,'completed',len(completed),'todo',len(todo),flush=True)
 failures=0
 if todo:
  with get_context('fork').Pool(a.workers) as pool:
   for v in pool.imap_unordered(work,todo,chunksize=1):
    i=v['index']
    if v['status']=='COMPLETED':
     atomic_json(OUT/'boxes'/f'{i:04d}.json',v);completed[i]=v
    else:
     atomic_json(OUT/'boxes'/f'{i:04d}.error.json',v);failures+=1
    print('DIG_PRODUCER_RESULT',i,v['status'],'LOWER',v.get('lower_float'),'PASS',v.get('pass'),
          'SECONDS',round(v['elapsed_seconds'],1),'COMPLETED',len(completed),'of',a.limit,flush=True)
    if failures:
     print('DIG_PRODUCER_ERRORS',failures,flush=True)
  # No failure can be counted as PASS, even if other 831 boxes passed
 if len(completed)==a.limit:
  results=[completed[i] for i in range(a.limit)]
  with open(OUT/'dig_bprime_producer_full.jsonl','w') as f:
   for v in results:f.write(json.dumps(v,ensure_ascii=False,sort_keys=True)+'\n')
  worst=min(results,key=lambda v:F(v['lower']))
  summary={'status':'DONE' if a.limit==832 else 'PILOT_ONE','completed':a.limit,
   'cover_sha256':EXPECTED_SHA,'producer_source_sha256':PILOT_SHA,
   'min_lower_exact':worst['lower'],'worst_box':worst['box'],
   'pass_count':sum(x['pass'] for x in results),
   'fail_count':sum(not x['pass'] for x in results),
   'all_pass':all(x['pass'] for x in results)}
  atomic_json(OUT/'DONE.json' if a.limit==832 else OUT/'PILOT_ONE.json',summary)
  print('DIG_PRODUCER_FINISHED',summary['status'],'ALL_PASS',summary['all_pass'],
        'PASS_COUNT',summary['pass_count'],'WORST_LOWER',float(F(worst['lower'])),flush=True)
 else:print('DIG_PRODUCER_INCOMPLETE',len(completed),'/',a.limit,flush=True)
if __name__=='__main__':main()
