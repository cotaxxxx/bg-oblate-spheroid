#!/usr/bin/env python3
"""D5 boundary B' v2 contact-centred polar coordinates, Dig pilot only.
Strictly read-only toward B7 and old B' directories. No Git changes.
New formula and verifier NEED independent chat/Muse audit before evidence.
"""
from __future__ import annotations
from pathlib import Path
from fractions import Fraction as Q
import sys,json,time,math,hashlib,argparse,traceback,itertools
from flint import arb,ctx
ctx.prec=160
M40=Path("/home/daybreak/D5_M40_work/m40_run_20261105")
sys.path.insert(0,str(M40))
from chat_m40iv import Kn,I
ROOT=Path(__file__).resolve().parent
def aa(q):
 q=Q(q);return arb(q.numerator)/q.denominator
def iv(a,b=None):
 if b is None:return aa(a)
 l,h=aa(a),aa(b)
 return (l+h)/2+arb(0,(h-l)/2)
def dyad(x):
 m,e=x.man_exp();m,e=int(m),int(e)
 return Q(m*(1<<e),1) if e>=0 else Q(m,1<<(-e))
def meet(x,low=None,high=None):
 l=x.lower() if low is None else max(x.lower(),aa(low))
 h=x.upper() if high is None else min(x.upper(),aa(high))
 if l>h:raise ArithmeticError('invalid exact geometry intersection '+str((x,low,high)))
 return (l+h)/2+arb(0,(h-l)/2)
class Jet:
 __slots__=('a','b','c')
 def __init__(self,a,b=0,c=0):
  self.a=a if isinstance(a,arb) else aa(a)
  self.b=b if isinstance(b,arb) else aa(b)
  self.c=c if isinstance(c,arb) else aa(c)
 @staticmethod
 def var(x):return Jet(x,1)
 @staticmethod
 def lift(x):return x if isinstance(x,Jet) else Jet(x)
 def __add__(self,x):
  x=Jet.lift(x);return Jet(self.a+x.a,self.b+x.b,self.c+x.c)
 __radd__=__add__
 def __neg__(self):return Jet(-self.a,-self.b,-self.c)
 def __sub__(self,x):return self+(-Jet.lift(x))
 def __rsub__(self,x):return Jet.lift(x)-self
 def __mul__(self,x):
  x=Jet.lift(x)
  return Jet(self.a*x.a,self.a*x.b+self.b*x.a,self.a*x.c+self.b*x.b+self.c*x.a)
 __rmul__=__mul__
 def inv(self):
  ai=1/self.a
  return Jet(ai,-self.b*ai*ai,(self.b*self.b-self.a*self.c)*ai*ai*ai)
 def __truediv__(self,x):return self*Jet.lift(x).inv()
 def __rtruediv__(self,x):return Jet.lift(x)*self.inv()
 def sqrt(self):
  y=self.a.sqrt();iy=1/y
  return Jet(y,self.b*iy/2,self.c*iy/2-self.b*self.b*iy*iy*iy/8)
 def cap(self,lo=None,hi=None):return Jet(meet(self.a,lo,hi),self.b,self.c)
def r_jet(g):
 gl=max(Q(0),dyad(g.lower()))
 gh=min(Q(1),dyad(g.upper()))
 if not Q(0)<=gl<=gh<=Q(1):raise ArithmeticError("gamma violates [0,1]")
 qq=I((1-gh)/(1+gh),(1-gl)/(1+gl))
 one=arb(1);inverse=1/(one+g)
 result=[]
 for m in range(4):
  k=Kn(m+1,qq)
  v=2*(-1)**m*math.factorial(m)*iv(k.a,k.b)*(inverse**(m+1))
  if not v.is_finite():raise ArithmeticError("nonfinite R derivative")
  result.append(v)
 return result
def density(lam,tau,r,s,eps_cos,var=None):
 # f includes geometric Jacobian from polar r=tan(psi/4), s=tan(theta/2).
 R=Jet.var(r) if var=='r' else Jet(r)
 S=Jet.var(s) if var=='s' else Jet(s)
 L=Jet(lam);T=Jet(tau);O=Jet(1)
 r2=R*R;s2=S*S
 x=2*R/(O+r2)          # sin(psi/2)
 y=(O-r2)/(O+r2)       # cos(psi/2)
 sigma=2*x             # 4r/(1+r^2)
 sinpsi=2*x*y
 cospsi=O-2*x*x
 costh=eps_cos*(O-s2)/(O+s2)
 sinth=2*S/(O+s2)
 a=((O-T*T)/(O+T*T)).cap(0,1)
 b=(2*T/(O+T*T)).cap(0,1)
 # nu=-x Q+y(-b,0,a)*cos(theta)+y(0,1,0)*sin(theta)
 nx=-x*a-y*b*costh
 ny=y*sinth
 nz=-x*b+y*a*costh
 xiz=(b*cospsi+a*costh*sinpsi).cap(-1,1)
 lo=dyad(lam.lower())
 lam2=L*L
 K=(nx*nx+ny*ny+lam2*nz*nz).cap(lo*lo,1)
 n=(ny*ny/K).cap(0,1)
 w2=(lam2+(O-lam2)*xiz*xiz).cap(lo*lo,1)
 gamma=(L*sigma/(2*w2.sqrt()*K.sqrt())).cap(0,1)
 derivs=r_jet(gamma.a)
 D=Jet(0,gamma.b,gamma.c)
 Rfun=Jet(derivs[0])+D*derivs[1]+D*D*(derivs[2]/2)
 Rp=Jet(derivs[1])+D*derivs[2]+D*D*(derivs[3]/2)
 alpha=O-n-2*n*(O-2*K)*(O-2*K)
 beta=n*(O-2*K)*(O-2*K)
 f=gamma/(2*K)*(alpha*Rfun-gamma*beta*Rp)
 jac=sinpsi*4/(O+r2)*2/(O+s2)
 val=f*jac
 if not (val.a.is_finite() and val.b.is_finite() and val.c.is_finite()):
  raise ArithmeticError(f"nonfinite jet: {eps_cos} r={r} s={s} var={var}")
 return val
PARENTS=[
 dict(name='EQUATOR',lam=('2/5','21/50'),tau=('0','1/16')),
 dict(name='MIDDLE',lam=('1/2','13/25'),tau=('1/2','9/16')),
 dict(name='POLE',lam=('16/25','33/50'),tau=('15/16','1'))
]
def bounds_for(parent,part='whole'):
 l0,l1=map(Q,parent['lam']);t0,t1=map(Q,parent['tau'])
 if part=='whole':return (l0,l1),(t0,t1)
 a,b=map(int,part.split('x'))
 assert a in (0,1) and b in (0,1)
 lm=(l0+l1)/2;tm=(t0+t1)/2
 return ((l0,lm) if a==0 else (lm,l1)),((t0,tm) if b==0 else (tm,t1))
def compute(parent,n,part='whole'):
 bounds_l,bounds_t=bounds_for(parent,part)
 l,t=iv(*bounds_l),iv(*bounds_t)
 start=time.monotonic()
 midpoint=arb(0);curvature=arb(0)
 r_worst=None; s_worst=None;mincurv=None
 for cos_sign in (-1,1):
  for i in range(n):
   r0,r1=Q(i,n),Q(i+1,n);rm=(r0+r1)/2;dr=r1-r0
   for j in range(n):
    s0,s1=Q(j,n),Q(j+1,n);sm=(s0+s1)/2;ds=s1-s0
    area=aa(dr*ds)
    fmid=density(l,t,aa(rm),aa(sm),cos_sign).a
    fr2=density(l,t,iv(r0,r1),iv(s0,s1),cos_sign,'r').c*2
    fs2=density(l,t,aa(rm),iv(s0,s1),cos_sign,'s').c*2
    cm=area*(aa(dr*dr)/24*fr2+aa(ds*ds)/24*fs2)
    midpoint+=area*fmid
    curvature+=cm
    if mincurv is None or cm.lower()<mincurv:
     mincurv=cm.lower();r_worst=[str(r0),str(r1)];s_worst=[str(s0),str(s1)]
 # Signed total and individual pieces are enclosed separately.
 total=midpoint+curvature
 lo=dyad(total.lower())
 pref=Q(113,355) if lo>=0 else Q(106,333)
 bound=lo*pref
 return dict(status="CALIBRATION_ONLY_NOT_INDEPENDENTLY_AUDITED",
  box=parent['name'],part=part,lambda_range=[str(v) for v in bounds_l],
  tau_range=[str(v) for v in bounds_t],grid=n,branches=2,cut='NONE',
  raw_mid_lower_exact=str(dyad(midpoint.lower())),
  raw_mid_upper_exact=str(dyad(midpoint.upper())),
  raw_curvature_lower_exact=str(dyad(curvature.lower())),
  raw_curvature_upper_exact=str(dyad(curvature.upper())),
  raw_total_lower_exact=str(lo),prefactor=str(pref),
  lower_exact=str(bound),lower_decimal=float(bound),
  midpoint_lower_decimal=float(midpoint.lower()),
  curvature_lower_decimal=float(curvature.lower()),
  min_curvature_cell=dict(r=r_worst,s=s_worst),
  seconds=time.monotonic()-start,
  proof_status="NOT_CERTIFIED")
def point_check(n,lam="2/5",tau="0"):
 start=time.monotonic();v=arb(0)
 l,t=aa(lam),aa(tau)
 for sign in (-1,1):
  for i in range(n):
   r=aa(Q(2*i+1,2*n))
   for j in range(n):
    s=aa(Q(2*j+1,2*n))
    v+=density(l,t,r,s,sign).a/arb(n*n)
 h=v/arb.pi()
 return dict(point=[lam,tau],n=n,h_float=float(h.mid()),
  h_interval=str(h),seconds=time.monotonic()-start,
  status="NUMERICAL_MIDPOINT_REFERENCE_ONLY")
def main():
 ap=argparse.ArgumentParser()
 ap.add_argument('--case',choices=['EQUATOR','MIDDLE','POLE'])
 ap.add_argument('--grid',type=int,choices=[16,32],default=16)
 ap.add_argument('--part',choices=['whole','0x0','0x1','1x0','1x1'],default='whole')
 ap.add_argument('--point',type=int,choices=[8,16,32],default=None)
 args=ap.parse_args()
 if args.point:
  r=point_check(args.point)
  name=f"POINT_{args.point}"
 else:
  assert args.case
  parent=next(v for v in PARENTS if v['name']==args.case)
  r=compute(parent,args.grid,args.part)
  name=f"{args.case}_{args.grid}_{args.part}"
 r['source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 r['kn_source_sha256']=hashlib.sha256((M40/'chat_m40iv.py').read_bytes()).hexdigest()
 (ROOT/(name+'.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2)+"\n")
 print(name, r.get('lower_decimal',r.get('h_float')), 'mid',r.get('midpoint_lower_decimal'),
       'curv',r.get('curvature_lower_decimal'),'sec',round(r['seconds'],2),flush=True)
if __name__=='__main__':main()
