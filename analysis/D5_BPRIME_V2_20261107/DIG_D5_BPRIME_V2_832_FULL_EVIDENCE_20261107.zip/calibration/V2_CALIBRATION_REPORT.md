# D5 B-prime v2 / Dig calibration record

2026-11-07 / DIAGNOSTIC ONLY, NOT CERTIFIED / NO GIT / B7 UNCHANGED

Contact-centered polar r=tan(psi/4), s=tan(theta/2), two cos(theta) branches; no cut; midpoint-line rule with Jacobian included before differentiation. Original M40 Kn is reused unchanged.

## Whole parent rectangle
| Box | Grid | Final H lower | Midpoint lower (raw) | Curvature lower (raw) | Time (s) |
|---|---:|---:|---:|---:|---:|
| EQUATOR | 16x16 | -7.958528969 | +0.575582829 | -25.577376618 | 4.89 |
| EQUATOR | 32x32 | +0.103724493 | +0.574479231 | -0.248619094 | 21.04 |
| MIDDLE | 16x16 | -13.266308739 | +0.575771006 | -42.252004998 | 4.35 |
| MIDDLE | 32x32 | -0.040712654 | +0.575693403 | -0.703592583 | 25.77 |
| POLE | 16x16 | -0.610382137 | +1.657715548 | -3.575236779 | 4.41 |
| POLE | 32x32 | +0.480879956 | +1.655166568 | -0.144437500 | 18.46 |

## Four sub-boxes on each parent lambda x tau rectangle

Every set of 4 boxes partitions its parent rectangle exactly, including shared endpoints. The parent H lower is min, NEVER sum, of its 4 universal parameter sub-box lower bounds.

| Parent | Grid | 0x0 | 0x1 | 1x0 | 1x1 | min | margin over 1/4 |
|---|---:|---:|---:|---:|---:|---:|---:|
| EQUATOR | 16x16 | -1.502583567 | -2.225953365 | -1.261761551 | -1.854077735 | -2.225953365 | -2.475953365 |
| EQUATOR | 32x32 | +0.272990815 | +0.265447047 | +0.277378128 | +0.270102186 | +0.265447047 | +0.015447047 |
| MIDDLE | 16x16 | -4.562266232 | -4.679977099 | -3.739351889 | -3.851253094 | -4.679977099 | -4.929977099 |
| MIDDLE | 32x32 | +0.448407188 | +0.463033356 | +0.450084567 | +0.464585941 | +0.448407188 | +0.198407188 |
| POLE | 16x16 | -0.112210478 | -0.063220450 | -0.073016928 | -0.028304264 | -0.112210478 | -0.362210478 |
| POLE | 32x32 | +0.644390502 | +0.653114540 | +0.631112362 | +0.639692080 | +0.631112362 | +0.381112362 |

## Interpretation and verification gates

All 12 uniform 32x32 child boxes have positive lower bounds exceeding 1/4, SUBJECT TO audit of the newly written Dig polar code and inherited M40 Kn. The 3 sample parent rectangles are NOT a full lambda/tau cover.
Separate midpoint/curvature columns show strict outward rational LOWER endpoints before multiplication by 1/pi, not interval centres. Final lower includes both pieces and a sign-safe rational 1/pi enclosure.
The underlying code uses Arb 160-bit outward enclosures and Taylor jets, with R^m via the prior M40 signed-remainder Kn (m<=3). The q=1 endpoint at the contact requires explicit independent audit.
No sigma_c, no cut. The new coordinates eliminate division by sigma, including at r=0.
Numerical-only sanity checks: equator lambda=2/5,tau=0: 16x16 0.397435145685, 32x32 0.397180849686. Lambda=tau=1/2: 16x16 0.819786110893, 32x32 0.819361323026.
No producer/verifier full-domain run, no independently audited PASS, no SHA-pinned all-domain rational cover, no Git commit/push or B7 mutation.

## Provenance

Source file: bprime_v2_pilot.py SHA-256 d60fe187150db01fd92420353da43e1ac186a5cd4a802f206976e7a4c888f531
Inherited M40 source: /home/daybreak/D5_M40_work/m40_run_20261105/chat_m40iv.py SHA-256 d39be478485cb1faaf804ddbf970ce1c790b0d7a5d0bf7f2fb400561c2cdad1b
User-uploaded v2 spec SHA-256: 2d27f944e2a8f6890d37ea0d4883f06a8e83fc250c62568bc10e936451b7ec27 (upload-verified; remote copy not present).
Each of the 30 result JSON files contains exact rational lower endpoints and source SHA.

## Dig status

PILOT CALIBRATION POSITIVE ON THREE SAMPLED PARENT RECTANGLES after 2x2 outer splitting and 32x32 inner grid. Formal proof remains OPEN. Next: chat independent verifier and Muse diff audit before any full cover or Judge adoption.
