# Dig verification note — D5 B′ v2, endpoint q = 1

2026-11-07 JST / DIG TECHNICAL NOTE / submitted with existing pilot calibration
Status: ANALYTIC DERIVATION + UNIT TESTS; NEW EVALUATOR UNREVIEWED; NOT_CERTIFIED.

## 1. Why q = 1 occurs and why no cut is needed

Use the coordinates in chat's v2 delta:

- Q=(a,0,b) on the unit sphere, e1=(-b,0,a), e2=(0,1,0).
- xi=Q cos(psi)+(e1 cos(theta)+e2 sin(theta))sin(psi).
- r=tan(psi/4), sin(psi/2)=2r/(1+r²), cos(psi/2)=(1-r²)/(1+r²).
- sigma=|xi-Q|=4r/(1+r²).
- nu=(xi-Q)/sigma=-sin(psi/2)Q+cos(psi/2)(e1 cos(theta)+e2 sin(theta)); this is the continuous **definition at r=0** as well.

At r=0, sigma=0, nu=e1 cos(theta)+e2 sin(theta) and gamma=lambda sigma/(2 w sqrt(K))=0.
Therefore q=(1-gamma)/(1+gamma) equals exactly 1 at r=0. The pilot does **not** divide by sigma; denominators K>=lambda_lo²>0, w²>=lambda_lo²>0, and 1+gamma>=1. Thus f times the angular Jacobian has a smooth r=0 extension, provided the R derivatives have valid endpoint values.

## 2. R derivatives and moments

A(t)=1+t²+(1-t²)gamma=(1+gamma)(1+q t²), q=(1-gamma)/(1+gamma).

R(gamma)=2 integral_0^1 1/A(t) dt.
R^(m)(gamma) = 2(-1)^m m! (1+gamma)^(-m-1) K_{m+1}(q),
where K_n(q)=integral_0^1 (1-t²)^(n-1)/(1+q t²)^n dt, n=1,...,4.

For gamma in [0,1], q in [0,1], including both endpoints. K_n is nonincreasing in q because its integrand has nonpositive q derivative.

## 3. Signed Taylor remainder remains valid at q = 1

The reused M40 file chat_m40iv.py implements NSER=30 and

T_N(q)=sum_{m=0}^N (-1)^m binom(n+m-1,m) q^m B_mn,
B_mn=integral_0^1 t^{2m}(1-t²)^{n-1} dt (exact rational),
E_N(q)=binom(n+N,N+1) q^(N+1) B_{N+1,n}.

For any x>=0, the finite Taylor theorem with integral remainder applied to
h(x)=(1+x)^(-n) gives, for even N=30,

  0 <= T_N(x) - h(x) <= binom(n+N,N+1) x^(N+1).

Reason: h^(N+1)(y)=(-1)^(N+1)*(n)_(N+1)*(1+y)^(-n-N-1);
the remainder sign is negative (N+1 odd), while its magnitude is at
most the next Taylor coefficient because (1+y)^(-n-N-1)<=1 for y>=0.
This is a **finite Taylor bound**, not an unjustified convergence claim at x=1.

Multiply by (1-t²)^(n-1), put x=q t², and integrate 0<=t<=1:

  T_N(q)-E_N(q) <= K_n(q) <= T_N(q),   0<=q<=1.

Hence the inequalities **still hold at q=1**. There is no divergent tail:
the remainder is bounded by an explicit finite nonnegative rational.

For interval q in [q_lo,q_hi] subset [0,1], use monotonicity:

  T_N(q_hi)-E_N(q_hi) <= K_n(q) <= T_N(q_lo).

This is the existing chat_m40iv.Kn interval rule. Its endpoints and all
B_mn are computed by exact fractions and rounded outward to fixed binary
intervals. This analysis extends the existing function's docstring
"0<=q<1" to the q=1 endpoint **mathematically**; the source is unchanged.
The source has not yet undergone an independent new-usage endpoint audit.

## 4. Implementation pin and runtime handling

Dig pilot: bprime_v2_pilot.py, function r_jet(g).

- Gamma is intersected with [0,1] (geometry), keeping r=0 -> gamma=0.
- gl=max(0,lower(gamma)), gh=min(1,upper(gamma)) are exact dyadic endpoints.
- q_lo=(1-gh)/(1+gh), q_hi=(1-gl)/(1+gl).
- chat_m40iv.Kn(n,I(q_lo,q_hi)) encloses moments with the above bounds for n=1..4.
- 1/(1+gamma) is computed as a positive interval inverse; never subtract nearly
  equal values to evaluate nu or divide by sigma.
- The first and second derivatives of R and R' in the midpoint-line Taylor
  jet use R^(0),...,R^(3), so n=1..4 suffice.

Endpoint special-casing or deletion of the r=0 cell is **not** necessary
for the mathematical formula. However, the exact correctness of the
implementation's outward arithmetic, jet derivatives and interval
intersection remains an independent chat/Muse audit requirement.

## 5. Unit checks and evidence

The attached DIG_Q1_ENDPOINT_CHECKS_20261107.json reports, for n=1,2,3,4:

- exact rational T_30(1), E_30(1), rational lower and upper K_n(1);
- 70-digit mpmath integration K_n(1) strictly inside those rational bounds;
- exact positive remainder and explicit interval width;
- gamma=0, q=1 equality at the contact and the absence of sigma division
  verified by source-level inspection.

The mpmath integral is **diagnostic only**, NOT an independent proof.
The proof of endpoint inclusion is the finite Taylor remainder bound above.

## 6. Scope and handoff

- No new full-domain positive claim: all 30 pilot checks cover only the
  three sampled parent rectangles (16x16 / 32x32; whole and four quarters).
- The lower bounds >1/4 on all twelve 32x32 child boxes are Dig **candidates**,
  not accepted by Judge without an independent verifier and Muse diff audit.
- The user-reported chat independent verifier is separate evidence. This
  package does not claim to have received or verified its source/results.
- No B7 V5.3 process, monitor, checkpoint, Git repository or published
  evidence has been modified by creation of this package.
