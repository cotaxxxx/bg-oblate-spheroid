import json, sys
from fractions import Fraction as F
sys.path.insert(0,'/tmp/claude-0/-home-claude/c84560e9-80f0-5030-8308-5fed2f20ba54/scratchpad/b7v54iv')
import chat_b7v54_iv as V
X='x/'
O=json.load(open(X+'OUTER_16_EXACT.json'))
dig=[((F(b['lambda'][0]),F(b['lambda'][1])),(F(b['tau'][0]),F(b['tau'][1])),(F(b['delta'][0]),F(b['delta'][1]))) for b in sorted(O['boxes'],key=lambda b:b['outer_id'])]
mine=V.outer_split(((F(2,5),F(173,400)),(F(7,8),F(29,32)),(F(1,25),F(4,25))),(2,2,4))
print('outer16 identical to chat split (same order):', dig==mine)
cells=[]; ref=[]
for l in open(X+'STAGE_B_20549_LEAVES_AND_DIG_REFERENCE.jsonl'):
    d=json.loads(l); cells.append(d['cell_ypt'])
    ref.append([F(o['reference_J_lower_exact']) for o in sorted(d['outer16_reference'],key=lambda o:o['outer_id'])])
json.dump({'cells':cells},open('stageB_cells.json','w'))
S=[sum(r[k] for r in ref) for k in range(16)]
print('leaves',len(cells),'| Dig ref min_r sum %.12f'%float(min(S)))
near=[json.loads(l) for l in open(X+'V53_FROZEN_NEAR_19590_4D_LEAVES.jsonl')]
json.dump({'leaves':[{'cell':n['cell_yptu']} for n in near],'ref':[n['J_lower_exact'] for n in near]},open('near_leaves.json','w'))
print('near leaves',len(near),'| sum ref %.12f'%float(sum(F(n['J_lower_exact']) for n in near)), '| max p', max(F(n['cell_yptu'][1][1]) for n in near))
from collections import Counter; print(Counter(n['bound_source'] for n in near))
