import sys, time, json, re
from fractions import Fraction as Fr
sys.path.insert(0,'.')
import chat_b7v54_iv as V
doc=open('/mnt/user-data/attachments/c84560e9-80f0-5030-8308-5fed2f20ba54/6501a8c7-ASTRA_B7_V54_D3_CURVATURE_REDESIGN_20261107_6_.md').read()
B=json.loads(doc.split('# 付録B')[1].split('```json')[1].split('```')[0])
OUTER=((Fr(2,5),Fr(173,400)),(Fr(7,8),Fr(29,32)),(Fr(1,25),Fr(4,25)))
outers=V.outer_split(OUTER,(2,2,4))
def cell(band,iy,ip,it):
    lo,hi=(Fr(1,100),Fr(1,10)) if band=='middle' else (Fr(1,10),Fr(1))
    w=(hi-lo)/32
    return ((Fr(iy,32),Fr(iy+1,32)),(lo+ip*w,lo+(ip+1)*w),(Fr(it,32),Fr(it+1,32)))
for band in ('middle','far'):
    rows=B[band]['rows']; cells=[cell(band,*r['index']) for r in rows]
    t0=time.time(); P3=V.p3_lower(cells,outers,Fr(23,77)); F0=V.f0_lower(cells,outers); dt=time.time()-t0
    sm_p3=0; sm_c=0; sm_cx=0; sm_cxw=0
    for k,r in enumerate(rows):
        p3=[x if x is not None else Fr(-10**9) for x in P3[k]]
        comb=[max(a,b) for a,b in zip(p3,F0[k])]
        cw=float(Fr(r['new_weighted'])); cc=float(Fr(r['new_candidate_combined']))
        print(band, r['index'], 'chat P3 min_r %.6e'%float(min(p3)), 'Codex P3 %.6e'%cw, '| chat comb min_r %.6e'%float(min(comb)), 'Codex comb %.6e'%cc)
        sm_p3+=min(p3); sm_c+=min(comb); sm_cx+=Fr(r['new_candidate_combined']); sm_cxw+=Fr(r['new_weighted'])
    print(band,'SUM chat P3 %.6e | Codex P3 %.6e | chat comb %.6e | Codex comb %.6e'%(float(sm_p3),float(sm_cxw),float(sm_c),float(sm_cx)), '| %.1fs for %d cells x 16'%(dt,len(cells)))
