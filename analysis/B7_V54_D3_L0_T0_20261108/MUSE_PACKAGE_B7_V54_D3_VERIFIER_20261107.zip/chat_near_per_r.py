#!/usr/bin/env python3
"""chat: near band [P0, 1/100] of a V5.3 frozen box, recomputed with the chat B7IV leaf bounds on each outer
sub-box r (valid on that r).  usage: python3 -I chat_near_per_r.py NEAR.json --outer la lb ta tb da db
--split 2 2 4 [--workers N] [--out near_per_r.json]
NEAR.json: {"leaves": [{"cell": [[ya,yb],[pa,pb],[ta,tb],[ua,ub]]}, ...]}  (tiling [0,1]x[P0,1/100]x[0,1]^2)."""
import sys, os, json, time, hashlib, argparse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from multiprocessing import Pool
import b7iv_vleaf as VL
import chat_b7v54_iv as V

def work(a):
    outer, chunk = a
    return [(lb[0], lb[1]) for lb in VL.leaf_bounds(outer, chunk)]

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('near')
    ap.add_argument('--outer', nargs=6, required=True); ap.add_argument('--split', nargs=3, type=int, default=[2, 2, 4])
    ap.add_argument('--workers', type=int, default=os.cpu_count()); ap.add_argument('--out', default='near_per_r.json')
    a = ap.parse_args()
    o = [Fr(x) for x in a.outer]; outer = ((o[0], o[1]), (o[2], o[3]), (o[4], o[5]))
    raw = open(a.near, 'rb').read(); sha = hashlib.sha256(raw).hexdigest(); d = json.loads(raw)
    leaves = [VL.parse_leaf(lf, outer) for lf in d['leaves']]
    ok, info = VL.check_tiling([lf['cell'] for lf in leaves], ((Fr(0), Fr(1)), (VL.P0, Fr(1, 100)), (Fr(0), Fr(1)), (Fr(0), Fr(1))))
    print('NEAR', a.near, 'sha256', sha, '| leaves', len(leaves), '| TILING', 'PASS' if ok else 'FAIL', info, flush=True)
    outers = V.outer_split(outer, tuple(a.split))
    res = {'sha256': sha, 'tiling': ok, 'per_r': []}
    t0 = time.time()
    with Pool(a.workers) as pool:
        for r, ob in enumerate(outers):
            # leaf hints (outer_parts etc.) default to 1; parse against this sub-box
            lv = [VL.parse_leaf(lf, ob) for lf in d['leaves']]
            chunks = [(ob, lv[i:i + 400]) for i in range(0, len(lv), 400)]
            tot = Fr(0); src = {}
            for part in pool.imap(work, chunks):
                for lo, s in part:
                    tot += lo; src[s] = src.get(s, 0) + 1
            res['per_r'].append({'r': r, 'outer': [[str(x) for x in iv] for iv in ob], 'J_near': str(tot), 'src': src})
            print('  r=%d J_near=%.9f %s %.0fs' % (r, float(tot), src, time.time() - t0), flush=True)
    json.dump(res, open(a.out, 'w'), indent=1)
if __name__ == '__main__':
    main()
