import sys, random, math, mpmath as mp
from fractions import Fraction as Fr
sys.path.insert(0,'.')
import numpy as np
import chat_b7v54_iv as V
from b7iv_ia import IA
import b7iv_vk as VK
TH=Fr(23,77)
def P(x): return IA.from_pairs([(Fr(x),Fr(x))])
random.seed(3); bad=0; rows=[]
for k in range(40):
    lam=random.uniform(.4,.4325); tau=random.uniform(.875,29/32); de=random.uniform(1/25,4/25)
    y,t=random.random(),random.random(); p=random.uniform(0.01,1)
    rows.append((lam,tau,de,y,p,t))
# (1) F*w vs F_K at u
for (lam,tau,de,y,p,t) in rows[:20]:
    u=random.random(); w=32*p*(1-p*p)/(1+p*p)**3
    for eps in (1,-1):
        q0,q1,A,B,thg=V.kernel([P(x) for x in (lam,tau,de,y,p,t)],eps,None)
        z=u*u; Fv=(float(q0.v.lo[0])+float(q1.v.lo[0])*z)/(float(A.v.lo[0])+float(B.v.lo[0])*z)**2
        K=VK.F_K([IA(float(x)) for x in (lam,tau,de,y,p,t,u)],eps,form='kappa')[1].v
        if not (float(np.ravel(K.lo)[0])-1e-9*(1+abs(Fv*w)) <= Fv*w <= float(np.ravel(K.hi)[0])+1e-9*(1+abs(Fv*w))): bad+=1
print('F*w vs F_K outside:',bad)
# float reference of Fbar(u-integrated) via F_K/w
def fbar_float(lam,tau,de,y,p,t):
    w=32*p*(1-p*p)/(1+p*p)**3; tot=0
    for eps in (1,-1):
        f=lambda u: float(np.ravel(VK.F_K([IA(float(x)) for x in (lam,tau,de,y,p,t,u)],eps,form='kappa')[1].v.lo)[0])
        tot+=mp.quad(lambda u: f(float(u)),[0,1])
    return tot/w
bad=0; bad2=0
for (lam,tau,de,y,p,t) in rows[:8]:
    Vp=[P(x) for x in (lam,tau,de,y,p,t)]
    fb=V.Fbar(Vp,TH); ref=fbar_float(lam,tau,de,y,p,t)
    ok=fb.lo[0]-1e-7<=ref<=fb.hi[0]+1e-7; bad+=not ok
    for var in (3,4,5):
        dd=V.Fbar_xx(Vp,var,TH)
        hstep=1e-3; X=[lam,tau,de,y,p,t]
        def g(v):
            Z=list(X); Z[var]=v; return float(V.Fbar([P(x) for x in Z],TH).lo[0])
        num=(g(X[var]+hstep)-2*g(X[var])+g(X[var]-hstep))/hstep**2
        ok2=dd.lo[0]-1e-3*(1+abs(num))<=num<=dd.hi[0]+1e-3*(1+abs(num)); bad2+=not ok2
        print(' var',var,'Fxx',float(dd.lo[0]),float(dd.hi[0]),'num',num, ok2)
    print('Fbar',float(fb.lo[0]),float(fb.hi[0]),'ref',ref,ok)
print('Fbar outside',bad,'Fxx outside',bad2)
