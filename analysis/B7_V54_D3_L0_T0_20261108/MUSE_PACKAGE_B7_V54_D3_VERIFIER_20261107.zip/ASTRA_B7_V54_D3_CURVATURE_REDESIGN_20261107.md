# B7 V5.4 D3 曲率下界の再設計
## Astra依頼への数学設計回答案 — 2026年11月7日

作成：Codex。対象：D-OB P2／B7 V5.4／D3 `L0_T0_D3`。
位置づけ：数学設計と局所producer実験。独立verifier、全領域証明、採用裁定ではない。

**提案は、exact核の共通平方根分母を消去し、p方向を回転の微分として評価したうえで、正のヤコビアン重みを厳密に積分する方法である。** uの共通有理モーメントと符号付き剰余は維持する。

代表18セルの局所実験では既存一般下界との併用を含めて改善した。ただし、D3の遠方2帯全体で必要な正の下界を得られるか、30万セル以内に収まるかは未確認である。既存の外部PCの計算・証明書・V5.3凍結値・公式24/40は変更していない。外部PCでは資料を読み、試作計算は別環境のコピーで行った。

# 1. 改良した数学式と証明

## 1.1 現状の診断と対象

外側普遍パラメータは
\[
(\lambda,\tau,\delta)\in
[2/5,173/400]\times[7/8,29/32]\times[1/25,4/25].
\]
内側は \(y,t,u\in[0,1]\)、pは中帯 \([1/100,1/10]\) と遠方帯 \([1/10,1]\)、\(\varepsilon=\pm1\) の和である。

Digの32³記録では、遠方帯のPeano単独の内訳が次のとおりである。

| 項目 | J単位の下界寄与 |
|---|---:|
| 中点値 | −2,564.560520829 |
| y曲率 | −7,299,279.918554 |
| p曲率 | −37,884,018.313632 |
| t曲率 | −820.924172 |
| 合計 | −45,186,683.716878 |
| 既存一般下界との併用後 | −138.598955759 |

尾部の診断用上界は約0.00244131で、既に評価に含まれる。これを再度差し引かない。

p曲率の粗さは最大の障害だが、中点下界も8³・16³・32³で約−2508・−2555・−2565のままである。したがって、**曲率の支払いだけを小さくする設計では不十分**であり、核の値そのものの区間依存性も減らす必要がある。

## 1.2 記号と幾何

\[
a=\frac{1-\tau^2}{1+\tau^2},\quad b=\frac{2\tau}{1+\tau^2},\quad
N_y=1-a^2y(2-y),\quad
M=\delta+(1-\delta)a^2y(2-y),
\]
\[
s=\sqrt{(1-\delta)N_y},\qquad
d=1-s=\frac{M}{1+s},\qquad
q=\left(\frac{(1-y)a}{\sqrt{N_y}},0,\frac b{\sqrt{N_y}}\right).
\]
dの数値評価には \(M/(1+s)\) を用いる。
\[
c_b=\varepsilon\frac{1-t^2}{1+t^2},\quad s_b=\frac{2t}{1+t^2},
\quad e=(-c_bq_z,s_b,c_bq_x).
\]
\(q\cdot q=e\cdot e=1,\ q\cdot e=0\) である。

\[
\sigma=\frac{2p}{1+p^2},\quad g=\frac{1-p^2}{1+p^2},\quad
C=1-2\sigma^2,\quad S_\theta=2\sigma g,
\]
\[
\xi=Cq+S_\theta e,\qquad
v=\xi-sq=(d-2\sigma^2)q+2\sigma g\,e,
\]
\[
\Delta=d^2+4s\sigma^2,\qquad h=d+2s\sigma^2=1-sC.
\]

直交性から
\[
|\xi|^2=1,\quad |v|^2=\Delta,\quad \xi\cdot v=h.
\]
旧核の \(\omega,H_h\) は
\[
\omega=\frac v{\sqrt\Delta},\qquad H_h=\frac h{\sqrt\Delta}.
\]
ここで \(\omega\) は原コードの \((o_x,o_y,o_z)\) である。

## 1.3 共通平方根分母の完全消去

以下を定義する。
\[
V=v_x^2+v_y^2+\lambda^2v_z^2,\qquad
U=v_y^2+\lambda^2v_z^2,
\]
\[
W=\lambda^2(\xi_x^2+\xi_y^2)+\xi_z^2,\quad
\mathcal T=\sqrt{WV},\quad \mathcal G=\lambda h.
\]
VとUは平方和で評価する。特に \(U=V-v_x^2\) による差し引き評価を主経路にしない。

旧核に含まれるEの分子を
\[
\mathcal E=
-sq_x S_\theta^2s_b^2-sS_\theta c_bv_z
 +(1-\lambda^2)\xi_xv_z^2
\]
とおくと、
\[
\boxed{\mathcal E=h v_x-\xi_xV}
\]
および
\[
\boxed{\mathcal E
=v_xv_z\{sq_z+(1-\lambda^2)v_z\}-sq_xU}
\]
が成立する。

**証明。**
\(v_y=\xi_y=S_\theta s_b\)、
\(S_\theta c_b=\xi_zq_x-\xi_xq_z\) を代入すると
\[
\mathcal E
=-sq_x(v_y^2+\xi_zv_z)
 +\xi_x\{sq_zv_z+(1-\lambda^2)v_z^2\}.
\]
さらに \(h=\xi_xv_x+v_y^2+\xi_zv_z\)、
\(sq_xv_x+sq_zv_z=h-\Delta\) を用いれば
\[
\mathcal E=(\xi_x-sq_x)h-\xi_x\{\Delta-(1-\lambda^2)v_z^2\}
=h v_x-\xi_xV.
\]
\(h=\xi\cdot v,\ \xi=v+sq\) を使って展開すれば第三式も得られる。□

\[
\mathcal P=h^2U,\qquad \mathcal R=\mathcal E^2,
\]
\[
n(z)=\mathcal T(\mathcal P-2\mathcal R)(1+z)
     +\mathcal G(\mathcal P-\mathcal R)(1-z),\qquad z=u^2,
\]
\[
D(z)=V\{(\mathcal T+\mathcal G)+(\mathcal T-\mathcal G)z\}.
\]

旧核との対応は
\[
V_2=\frac V\Delta,\ U_2=\frac U\Delta,\quad
T=\frac{\mathcal T}{\sqrt\Delta},\ G=\frac{\mathcal G}{\sqrt\Delta},
\quad P=\frac{\mathcal P}{\Delta^2},\ R=\frac{\mathcal R}{\Delta^2}.
\]
旧式の \(W_{\rm old}=4\sigma/\sqrt\Delta\) と
\(\mathrm{jac}=4(1-p^2)/\{(1+p^2)^2(1+t^2)\}\) を代入すると、
分子・分母に現れる \(\Delta\) の全べきが相殺する。したがってexact核は
\[
\boxed{
 K(y,p,t,u;\alpha,\varepsilon)=
 \frac{32p(1-p^2)}{(1+p^2)^3(1+t^2)}
 \frac{n(u^2)}{D(u^2)^2}
}
\tag{A}
\]
となる。これは近似ではない。外側 \(\alpha=(\lambda,\tau,\delta)\) の各点で同一である。

\(\sqrt\Delta\)、\(\kappa\)、その逆数の重複した微分は不要になる。ただし \(\mathcal T=\sqrt{WV}\) は残る。**全ての平方根を除去したという主張ではない。**

## 1.4 p微分を回転の微分に置き換える

\[
\theta=4\arctan p,\qquad
C=\cos\theta=\frac{1-6p^2+p^4}{(1+p^2)^2},\quad
S_\theta=\sin\theta=\frac{4p(1-p^2)}{(1+p^2)^2}.
\]
実装は右辺の有理式だけでよく、三角関数の数値評価は不要である。

\[
a_p=\theta'=\frac4{1+p^2},\qquad
b_p=\theta''=-\frac{8p}{(1+p^2)^2},\qquad
\eta=-S_\theta q+Ce.
\]
p微分ではs,q,eは固定されるから、
\[
\boxed{\xi_p=v_p=a_p\eta,\qquad
\xi_{pp}=v_{pp}=b_p\eta-a_p^2\xi,}
\tag{B}
\]
\[
\boxed{h_p=s a_pS_\theta,\qquad
h_{pp}=s(b_pS_\theta+a_p^2C).}
\tag{C}
\]
CとSのjetを直接作る場合は
\[
C_p=-a_pS_\theta,\ C_{pp}=-b_pS_\theta-a_p^2C,\qquad
(S_\theta)_p=a_pC,\ (S_\theta)_{pp}=b_pC-a_p^2S_\theta.
\]

**値の厳密範囲。** p区間 \([a_0,b_0]\subset[0,1]\) ではCは単調減少なので
\([C(b_0),C(a_0)]\) が正確な値域となる。
Sは \(p_*=\sqrt2-1\) で最大1となる。区間がp*を含むかは
\[
a_0^2+2a_0-1\le0\le b_0^2+2b_0-1
\]
で有理数だけで判定できる。含めば上端1、含まなければ端点値の最大、下端は端点値の最小である。

例えば
\[
V_p=2(v_xv_{x,p}+v_yv_{y,p}+\lambda^2v_zv_{z,p}),
\]
\[
V_{pp}=2\{v_{x,p}^2+v_xv_{x,pp}
+v_{y,p}^2+v_yv_{y,pp}
+\lambda^2(v_{z,p}^2+v_zv_{z,pp})\}.
\]
U,Wも同様に評価する。平方項の非負性を失わない。

\[
\mathcal E_p=h_pv_x+hv_{x,p}-\xi_{x,p}V-\xi_xV_p,
\]
\[
\mathcal E_{pp}=h_{pp}v_x+2h_pv_{x,p}+hv_{x,pp}
-\xi_{x,pp}V-2\xi_{x,p}V_p-\xi_xV_{pp}.
\]
1.3の三つの同一式から得た \((\mathcal E,\mathcal E_p,\mathcal E_{pp})\) は、成分ごとの区間交差を取れる。異なる量を交差するのではなく、同じexact量の異なる包含を交差する。

\[
(\mathcal E^2)_{pp}=2(\mathcal E_p^2+\mathcal E\mathcal E_{pp})
\]
を使い、\(\mathcal E_p^2\) の非負性を保持する。混合符号の分子全体を正と仮定してはいけない。

y,t方向ではs,q,eの依存性も微分する。式(B)(C)をそのままy,t微分に流用しない。

## 1.5 exact核の2階微分とu消去

(A)を \(K=Q(z)/D(z)^2\)、Q,Dともzの一次多項式として扱う。任意の内側変数xについて
\[
\boxed{
K_{xx}=
\frac{
 Q_{xx}D^2-4Q_xDD_x-2QDD_{xx}+6Q(D_x)^2
}{D^4}.
}
\tag{D}
\]
分子はzの三次以下。**exact式を微分してから**係数区間を計算し、共通モーメントでuを積分する。既に得た下界、max、切り詰め尾部式を微分しない。

p方向の重みを含めたまま(A)を使う通常Peano候補も残せる。以下のwについて
\[
w(p)=\frac{32p(1-p^2)}{(1+p^2)^3},
\]
\[
w'(p)=32\frac{1-8p^2+3p^4}{(1+p^2)^4},\qquad
w''(p)=-384\frac{p(2-5p^2+p^4)}{(1+p^2)^5}.
\]
\(K=wF\) とすれば \(K_{pp}=wF_{pp}+2w'F_p+w''F\) である。p=1でも有限。wで割った数値区間やlog wを使わない。

## 1.6 推奨：正のp重みによる逐次求積

(A)を
\[
K=w(p)F,\qquad
F=\frac{n(z)}{(1+t^2)D(z)^2}
\tag{E}
\]
と分ける。wはpだけに依存し、\([0,1]\) で非負である。
Fは(E)の明示式から評価し、p=1でK/wという0/0を作らない。

pセル \([a_0,b_0]\) に対し
\[
M_0=\int_{a_0}^{b_0}w(p)\,dp
=4\left[
 \left(\frac{2p}{1+p^2}\right)^2
 \right]_{a_0}^{b_0}>0,
\]
\[
c=\frac{\int pw(p)\,dp}{M_0},\qquad
M_2=\int w(p)(p-c)^2\,dp,\qquad
\kappa_p=\frac{M_2}{2M_0}.
\]
cは外側パラメータに依存しない。

\(\bar F(p)=\int_0^1F(p,u)\,du\) について、セル内で
\(\bar F_{pp}\ge L_p\) が成り立つなら
\[
\boxed{\int_{a_0}^{b_0}w(p)\bar F(p)\,dp
\ge M_0\bar F(c)+\frac{M_2}{2}L_p.}
\tag{F}
\]

**証明。** \(\bar F(p)-L_pp^2/2\) は凸であるため、cでの接線評価から
\[
\bar F(p)\ge \bar F(c)+\bar F_p(c)(p-c)+\frac{L_p}{2}(p-c)^2.
\]
wを掛けて積分し、重心の定義により一次項が消える。□

w′、w″を曲率の負担に入れる必要がなくなる。この変更は誤差項を捨てる操作ではなく、**同じexact積分に対する別の求積公式**である。従来の通常Peano候補と同じセル積分の下界として比較できる。

### 3変数への拡張

y,tは通常の中点、pは重心cを評価点とする。
\[
m=(m_y,c,m_t),\quad
\mu_C=h_yh_tM_0,\quad
\kappa_y=h_y^2/24,\quad\kappa_t=h_t^2/24.
\]
\[
\bar F(y,p,t;\alpha)=\sum_{\varepsilon=\pm1}\int_0^1F\,du.
\]

任意の順序 \(\pi\) について、各方向の2階微分下界 \(L_{\pi_j}\) は、先に処理した変数だけを評価点に固定し、現在と未処理の変数をセル全幅に残した領域で取る。すると
\[
\boxed{
\int_C\sum_\varepsilon\int_0^1K\,du\,dy\,dp\,dt
\ge \mu_C\left[
 \bar F(m)+\sum_{j=1}^3\kappa_{\pi_j}L_{\pi_j}
\right].
}
\tag{G}
\]
これは各次元の積分作用素と点評価作用素の差を逐次展開し、(F)と通常中点則を適用すれば得られる。混合微分は必要ない。

外側パラメータは各評価領域の全幅に残す。Lが正の場合も(G)は成立する。
6順序それぞれの**完成したセル下界**のmaxは有効である。

### cと分散を有理区間だけで求める

\(m_p=(a_0+b_0)/2,\ \ell=b_0-a_0\) とし、
\[
W_j=\int w(p)(p-m_p)^jdp,\quad j=1,2.
\]
すると \(c=m_p+W_1/M_0,\ M_2=W_2-W_1^2/M_0\)。

\[
k_* =1+(a_0^2+b_0^2)/2,\quad
r(p)=\frac{p^2-(a_0^2+b_0^2)/2}{k_*},\quad
|r|\le \rho=\frac{b_0^2-a_0^2}{2+a_0^2+b_0^2}\le\frac13.
\]
\[
(1+r)^{-3}
=\sum_{k=0}^{L}(-1)^k\binom{k+2}{2}r^k+R_L.
\]
\[
|R_L|\le
B_L=\frac{\binom{L+3}{2}\rho^{L+1}}
 {1-\rho(L+4)/(L+2)}
\]
（分母が正であるLを選ぶ）。多項式部分を有理数で正確に積分すれば
\[
\left|W_j-\frac{32}{k_*^3}
 \int p(1-p^2)(p-m_p)^j
 \sum_{k=0}^L(-1)^k\binom{k+2}{2}r(p)^k\,dp\right|
\le
\frac{32\ell(\ell/2)^j}{k_*^3}B_L.
\]
試作はL=15。M0は上の厳密有理式を使う。

cは区間で包み、その区間上でFを評価する。cを任意の近傍有理数に置換し、一次項が消えたことにしてはいけない。
\(0\le M_2\le M_0\ell^2/4\) は値の交差に使える。
\(\kappa_pL_p\) は符号を含めた区間積で評価する。L_p<0なのに分散の下端を掛ける誤りを避ける。

## 1.7 共通有理モーメントと符号付き剰余の維持

D=A+Bzとおく。今回の
\[
A=V(\mathcal T+\mathcal G),\quad B=V(\mathcal T-\mathcal G),
\]
\[
D_0=A+B/2=V(3\mathcal T+\mathcal G)/2,\qquad
\vartheta=\frac B{2A+B}
=\frac{\mathcal T-\mathcal G}{3\mathcal T+\mathcal G}
\]
は旧核と同じ\(\vartheta\)を持つ。

\(\tilde a=(\lambda\xi_x,\lambda\xi_y,\xi_z)\),
\(\tilde b=(v_x,v_y,\lambda v_z)\) とすると
\[
\mathcal T^2-\mathcal G^2=|\tilde a\times\tilde b|^2\ge0.
\]
したがって
\[
\vartheta=
\frac{|\tilde a\times\tilde b|^2}
 {(\mathcal T+\mathcal G)(3\mathcal T+\mathcal G)}
\]
も同一式であり、値域の交差に使える。

また
\[
h^2-M\Delta=4s^2(\sigma^2-d/2)^2\ge0.
\]
旧正規化T≤1、\(H_h\ge\sqrt M\ge\sqrt\delta\) より
\(G/T\ge\lambda\sqrt\delta\ge2/25\)。ゆえに
\[
0\le\vartheta\le\frac{1-2/25}{3+2/25}=\frac{23}{77}.
\]
従来のD3定数を維持できる。

次数dの係数多項式 \(q(z)=\sum q_jz^j\)、r=2または4について
\[
\mu_{jm}=\int_0^1u^{2j}(2u^2-1)^mdu
=\sum_{k=0}^m\binom mk\frac{2^k(-1)^{m-k}}{2(j+k)+1}.
\]
Nを奇数として
\[
\int_0^1\frac{q(u^2)}{D(u^2)^r}du
=D_0^{-r}\left[
\sum_{m=0}^{N}(-1)^m\binom{r+m-1}{m}\vartheta^m
\sum_jq_j\mu_{jm}+\text{tail}\right].
\]

\[
c_{r,N}(b)=
\frac{\binom{r+N}{N+1}b^{N+1}}
 {1-b(r+N+1)/(N+2)},\qquad b=23/77.
\]
Taylor剰余は、N+1が偶数なので非負で、
\(0\le R\le c_{r,N}(b)(2u^2-1)^{N+1}\)。

\[
\beta_i=\sum_{j=0}^i\frac{\binom ij}{\binom dj}q_j,\quad
\Omega_i=\int_0^1\binom di u^{2i}(1-u^2)^{d-i}(2u^2-1)^{N+1}du\ge0.
\]
係数区間 \(\beta_i\in[\beta_i^-,\beta_i^+]\) なら
\[
-c_{r,N}\sum_i\max(0,-\beta_i^-)\Omega_i
\le\text{tail}\le
c_{r,N}\sum_i\max(0,\beta_i^+)\Omega_i.
\]
ここでβの上付き±は区間端点。分子の全係数に絶対値を掛けて符号を捨てない。

u消去はF、\(F_{yy},F_{pp},F_{tt}\) に対して同じ方式で実行する。パラメータ領域はコンパクトで、d>0、V>0、D>0だから、微分とu積分の交換に特異性の問題はない。

## 1.8 外側minを集計後に取る

外側を同じ16箱 \(O_r\) に分け、各セルCに対し全 \(\alpha\in O_r\) で有効な下界 \(L_{Cr}\) を保持する。候補方式のmaxは同じ(C,r)内で取る。

\[
\boxed{
J_{\mathrm{middle+far}}^-
=\min_r\left\{
 \sum_{C\in\mathrm{middle}}L_{Cr}
+\sum_{C\in\mathrm{far}}L_{Cr}
\right\}.
}
\tag{H}
\]
これは
\[
\sum_C\min_rL_{Cr}\le\min_r\sum_CL_{Cr}
\]
により現行の「各セルで外側min」以上に鋭い。両帯でも同じ外側パラメータであるため、帯ごとのminを足すより(H)が有利になることがある。

**証明。** 任意の実パラメータαを含むrを一つ選べば、全セルで同じrの下界を足せる。その総和はrについての最小値以上。外側を積分・加算していない。□

# 2. Dig producerへの実装仕様

## 2.1 実装する候補

既存ファイルを変更せず、新しい実験モジュールで次を比較する。

| ID | 内容 | 役割 |
|---|---|---|
| P0 | 現行κ型の3D Peano | 再現用基準 |
| P1 | (A)の分母消去＋通常Peano | 相殺だけの効果 |
| P2 | P1＋(B)(C)のp微分＋Eの同一式交差 | 曲率鋭化の効果 |
| P3 | P2＋(G)の正重み求積 | 推奨候補 |
| F0 | 現行ASTRA3／K-floor | 有効な一般下界の保持 |

各(C,r)で候補の完成した積分下界のmaxを保存する。P3がP2以上とは理論上保証しないので、P2を捨てない。既存全外箱のF0は各小外箱にも有効だが、rごとに再評価したF0があればさらに比較できる。

実行順：
1. 外側分割と内側被覆を有理端点で固定。
2. pセルのM0,c,κpを事前計算し共有。
3. 原核との対応を固定した代数式から各方向のjetを作成。
4. Q,Dから(D)の係数を共通分母のまま構成。
5. u積分をN=23の共通モーメント＋符号付き尾部で包含。
6. 同一外側r内でεの和を取り、各順序の完成した下界を構成。
7. 候補max、セル合計、両帯合計、外側minの順で集計。
8. 凍結近帯と一度だけの接触補正を最後に接続。

### 実装上の必須事項

- p微分ではq,s,eを定数として扱うが、y/t微分では必要な依存性を全て残す。
- V,Uは平方和。RはEの区間を二乗する専用演算を使う。
- \(\lambda^2\Delta\le V\le\Delta\)、\(\lambda^2\le W\le1\) は値にだけ適用する。
- 証明済み値域で値を交差したとき、その端点やmax/minを微分しない。
- 同じ量を表す複数のexact式から得たjet同士なら、値・一階・二階をそれぞれ交差してよい。
- \(\mathcal T-\mathcal G\)、D0、ϑの同値式を交差する場合も、値域制約とexact微分を混同しない。
- p=1を含むセルを除外しない。w=0でもFは明示式で有限。
- 全候補は同じ3Dセル・同じu全区間を積分する。凍結4D葉を比例配分して流用しない。
- F0とP3の被積分関数の点ごとのmaxを積分するのではない。**同じセル積分に対する下界のmax**である。
- 外側箱の下界を足し合わせない。
- 数学的に証明していない符号によるclampを導入しない。
- 包含失敗・空交差・分母非正・範囲外の重心はエラーとして記録する。

### 分母の数値スケール

新しいDは中帯の一部で小さくなる。必要なら正の2のべきζをセルと外側箱ごとに選び、評価中は定数として固定して、QをQ/ζ²、DをD/ζへ同時に置き換える。同じexact核と微分を保ちながら固定精度の絶対丸めの影響を抑えられる。ζの選択規則を微分してはならない。今回の18セル比較にはこの追加正規化を使っていない。

## 2.2 記録形式

各(C,r)に次を残す：
- セルID、厳密端点、外側IDと端点、εの合算規則、方式ID、順序、N。
- 下界の厳密有理値（またはdyadic整数／共通スケール）。
- 中点または重心値の積分寄与、y/p/tの曲率寄与、丸め残差。
- M0、cの包含、κpの包含、pモーメント打切りL。
- 使用したu尾部定数、尾部の診断値、二重控除しないことを示す規約。
- 同一式交差の採否と空交差数、F0とのwinner。
- 各rの累積和、最後のminを与えるr。
- 入力ソース・試作コード・出力のSHA256、壁時計時間、総worker数、合計RSS。
- 最終葉数と、試し分割を含む評価回数を別々に記録する。

現行報告の約32MiBは親プロセスRSSであり、全worker合計として扱わない。

## 2.3 凍結近帯・prefactor・接触補正

固定する値は
\[
J_{\rm near,53}^-=
-\frac{453203225328119695582617599454763550807}
 {340282366920938463463374607431768211456}.
\]
新しい両帯下界をJfarとし、\(J_{\rm total}^-=J_{\rm near,53}^-+Jfar\)。

\[
c_+=636619773/10^9,\qquad c_-=636619772/10^9.
\]
\[
P_{54}(J)=
\begin{cases}
\lambda_-c_-J,&J\ge0,\\
\lambda_+c_+J,&J<0.
\end{cases}
\]
\[
H^-\ge P_{54}(J_{\rm total}^-)-2\lambda_+K_Q\sigma_0,\quad
K_Q=275/4,\quad p_0=1/2000000,\quad
\sigma_0=\frac{2p_0}{1+p_0^2}.
\]
接触補正はここで一度だけ支払う。帯ごと・セルごとに再度差し引かない。

D3全外箱の十分条件は
\[
Jfar>R_*,
\]
\[
\boxed{
R_*=
\frac{
288568724395643889222132655271240794799057335728007165689001
}{
216630482844882344256795079980460805302199958478083491627008
}
\approx1.332078111104395.
}
\]
依頼文の1.3320781111は表示用丸め値であり、厳密比較には使わない。

# 3. 代表セルの小規模較正

## 3.1 今回実施した局所実験

使用条件：
- 各帯の32³格子から固定9セル、合計18セル。
- インデックスは0始まり。
- 外側2×2×4の16箱、N=23、順序y→p→t。
- コピーしたDigの2^-128外向き丸め、共通モーメントを使用。
- 新pモーメントはL=15。
- 独立verifierではなく、producerの数学設計比較である。

選定インデックスは各帯共通：
\[
(0,0,0),(0,15,15),(0,31,31),
(15,0,31),(15,15,15),(15,31,0),
(31,0,15),(31,15,0),(31,31,31).
\]
例えば遠方帯の \((0,15,15)\) は
\[
[0,1/32]\times[167/320,11/20]\times[15/32,1/2].
\]

旧欄は**現行Peanoと一般下界の併用値**、新欄はP2/P3と既存下界の併用値である。単独Peanoだけを相手にした改善率ではない。

| 帯 | (iy,ip,it) | 旧・一般下界併用 | 新・一般下界併用 |
|---|---|---:|---:|
| 中帯 | (0, 0, 0) | -0.000624469633682 | -0.000624469633682 |
| 中帯 | (0, 15, 15) | -2.43797976228e-05 | -8.21547799222e-07 |
| 中帯 | (0, 31, 31) | -9.33978963283e-06 | 4.3659890733e-07 |
| 中帯 | (15, 0, 31) | -0.000189322331464 | -0.000128991091316 |
| 中帯 | (15, 15, 15) | -7.78905023799e-06 | 1.06389917236e-07 |
| 中帯 | (15, 31, 0) | -1.70651195205e-05 | -1.90121693756e-06 |
| 中帯 | (31, 0, 15) | -0.00106267220728 | -0.000306162899677 |
| 中帯 | (31, 15, 0) | -1.53752923251e-05 | -8.37418090603e-06 |
| 中帯 | (31, 31, 31) | 1.29919007312e-07 | 9.95155780189e-07 |
| **中帯9セル部分和** | — | **-0.00195028330276** | **-0.00106918242571** |
| 遠方帯 | (0, 0, 0) | -0.000950474429906 | -0.00079692877538 |
| 遠方帯 | (0, 15, 15) | -0.00443423796113 | 0.000158998832684 |
| 遠方帯 | (0, 31, 31) | -1.59242106023e-05 | 4.95536695393e-06 |
| 遠方帯 | (15, 0, 31) | -0.003656547482 | -0.000314066977944 |
| 遠方帯 | (15, 15, 15) | -0.00448862529878 | 0.000162737203056 |
| 遠方帯 | (15, 31, 0) | 0 | 1.23129823735e-05 |
| 遠方帯 | (31, 0, 15) | -0.00757823593987 | -0.000453642240849 |
| 遠方帯 | (31, 15, 0) | -0.005534976776 | 4.43694505491e-05 |
| 遠方帯 | (31, 31, 31) | 0 | 6.93867392229e-06 |
| **遠方帯9セル部分和** | — | **-0.0266590220983** | **-0.00117432548463** |

遠方帯の選定9セルでは6セルが正の下界を持つ。残る3セルは負である。

この18セルのP0再実行結果は、既存n32 JSONLの `new_J_lower` と全件で厳密有理数として一致した。
新旧の点jetの値・一階・二階について432成分の包含区間の重なりを確認した。
また、Eの同一式・ベクトル長・内積を192組の有理幾何データで厳密演算により確認した。

これらは実装の整合性検査であり、連続領域の恒等式の証明は第1節にある。点検査を全領域証明の代用にしない。

**上表は18セルだけであり、全帯の積分値、全帯の符号、30万セルでの閉鎖可能性を示さない。** とくに新しい中帯・遠方帯の下界を、これらの部分和から外挿してはいけない。

## 3.2 困難セルの追加診断

既存n32ファイルを読んで選んだ遠方帯の代表的な難所は次の二つ。

| インデックス | 選定根拠 |
|---|---|
| (0,6,1) | 旧p曲率の最悪セル |
| (0,8,0) | 旧中点値の最悪セル |

分母相殺＋正重みだけの段階（P2の回転微分・E交差を追加する前）でも、Peano単独下界は次のように変化した。

| セル | 旧Peano単独 | 分母相殺＋重み、ypt | 同方式の6順序max |
|---|---:|---:|---:|
| (0,6,1) | −26167.515970 | −0.000958904 | −0.000846356 |
| (0,8,0) | −19405.360865 | −0.000664409 | −0.000649323 |

この表の旧欄は一般下界との併用前である。上の18セル比較表と基準が異なることに注意する。難所での分母依存性の削減を診断するための表であり、実運用全体の改善倍率ではない。

## 3.3 Digに依頼する次の較正セット

各帯について以下の和集合を固定し、重複を除く。
1. 上記9セル。
2. 旧p曲率の最悪8セル。
3. 旧中点値の最悪8セル。
4. \(\sqrt2-1\) を跨ぐpセル、p=1隣接セル。
5. y,tの端点面と中央部を含むセル。

記録から抽出した最悪8セル：
- 中帯p：\((0,0,0),(0,0,1),(0,0,2),(0,0,3),(1,0,0),(1,0,1),(1,0,2),(0,0,4)\)。
- 中帯mid：\((0,0,0),(0,0,1),(1,0,0),(0,0,2),(1,0,1),(2,0,0),(1,0,2),(2,0,1)\)。
- 遠方p：\((0,6,1),(0,6,2),(0,6,0),(0,6,3),(0,6,4),(1,6,1),(0,6,5),(1,6,2)\)。
- 遠方mid：\((0,8,0),(0,8,1),(1,8,0),(0,8,2),(1,8,1),(2,8,0),(1,8,2),(0,9,0)\)。

各セルをP0〜P3で比較し、pだけ二分、yだけ二分、tだけ二分した子の和を親と比較する。
N=23を固定し、u尾部が支配する例だけN=31を追加する。
外側16箱を固定した比較を先に行い、中点幅の残るセルに限って外側のλ・τ・δを一方向ずつ二分する。

最初から全セルで6順序を実行せず、代表集合で2〜3順序を選ぶ。順序による改善を確認した難所でのみ6順序を比較する。

# 4. 旧方式と新方式の比較方法

同じ(C,r)について次の二系列を分ける。

**通常Peano同士：**
P0対P1対P2では、同じ積分領域上の \(\int K_{pp}du\) の下端・幅、同じ \(h_p^2/24\) を掛けた積分寄与を直接比較する。分母相殺と回転微分のどちらが効いたかを分離できる。

**通常Peanoと重み付き方式：**
P3の \(\int F_{pp}du\) は \(\int K_{pp}du\) と別の量である。生の二階微分値の大小を「改善率」にしない。
比較するのは
\[
|C|\frac{h_p^2}{24}L_{K,pp}
\quad\text{と}\quad
h_yh_tM_0\kappa_pL_{F,pp},
\]
および各方式の中点／重心寄与と最終セル下界である。

最小化する外側rが変わる場合、異なるrの中点項・曲率項を混ぜて合計を再構成しない。同じrを固定した比較も併記する。

全体で記録する項目：
- J^-そのもの、正寄与の和、負寄与の和。
- 同じ領域の旧併用下界との差。
- 中点／重心の包含幅、方向別の負の曲率支払い。
- 方式の採用数、外側minが切り替わる頻度。
- 各rの帯別・両帯総和。
- 総時間、葉数、全workerのRSS、失敗セル数。
- 改善を得るために追加した外側評価回数。

旧8³→16³→32³の負の大きさだけから得た収束指数aを、新方式の正の到達下界の証拠として流用しない。基準となる被積分式と求積公式が変わっている。

凍結V5.3葉はp=1/10に839葉が交差する。凍結葉の値を体積比で切って局所maxを取らない。今回のF0比較は現行一般下界との同一3Dセル比較であり、凍結4D葉との \(\Sigma\Delta_C\) ではない。

# 5. 30万セル以内で閉じられるかを判断する条件

## 5.1 予算の定義

判定用のセル数は、両遠方帯の**合計最終3D葉数**を数える。外側16箱・ε・jet評価回数は別に明示する。

「D3全体で30万」に近帯凍結葉も含める場合に備え、当初はV5.3の全113,605葉を保守的に予約し、
\[
N_{\rm middle}+N_{\rm far}\le300000-113605=186395
\]
を実装上の上限とする。実際に保持する近帯葉数が正本から確定すれば、その数で予約を見直せる。近帯下界そのものは変更しない。

試し分割の累積評価数と最終葉数は別の数なので両方報告する。外側の細分化を「セル数が増えないから無償」と扱わない。

## 5.2 段階条件

まず第3節の局所較正を完了する。その後、改良方式を用いた両帯全被覆について次を順に実施する。

| 段階 | 両帯の最終葉数目安 | 目的 |
|---|---:|---|
| A | 8,192（各16³） | 新式で全領域の値と誤差内訳を初めて測る |
| B | 32,768以下 | p偏重の異方分割の利益を測る |
| C | 65,536以下 | 一部だけの改善でないことを確認 |
| D | 131,072以下 | 予算内到達の見通しを判断 |
| 最終上限 | 186,395 | 近帯全葉を予約した保守的上限 |

B以降は一様格子の単純拡大を既定にしない。親セルを二分した実際の下界増分を使う。

## 5.3 適応分割

各セル・外側箱・方向の支払い
\[
E_{C,r,j}=\mu_C\kappa_j\max(0,-L_{C,r,j})
\]
は候補選定の指標にはなるが、子セルでの改善を保証しない。

実際の優先度は、試し二分した二つの子の下界和を使い、
\[
g_j=\max\left(0,\,
 \min_r\{S_r-L_{Cr}+L_{C_1r}+L_{C_2r}\}
 -\min_rS_r\right)
\]
を追加葉1枚・実測時間で評価する。S_rは両帯の現在総和。
最悪rだけを改善しても別のrが制約になることがあるので、全rの総和から再計算する。

親下界を保存し、
\[
L_{\mathrm{subtree},r}=\max(L_{\mathrm{parent},r},
 L_{\mathrm{child1},r}+L_{\mathrm{child2},r})
\]
とすれば、同一領域の保証下界を単調に保てる。最終的にどの親／子被覆を採用したかを証拠に明記し、親と子を重複加算しない。

各候補分割は有理中点を用い、被覆の隙間・重複を防ぐ。
外側分割を更新する場合は、旧累積値を子外側へ単に割り振らず、その子で有効な値として再評価または正当な継承を行う。

## 5.4 「見通し」と「成立」の区別

**計算続行の見通し：**
- 新方式の中点／重心幅と方向別誤差の減少が、同じ外側被覆で複数段階にわたり確認できる。
- p二分による実測増分が予算残量に対して有望である。
- 外側箱の幅に由来する停滞が支配していない。
- 目標を「負の量が0へ近づくこと」でなく \(Jfar>R_*\) に置く。

外挿をする場合でも、例えば \(J_N\approx J_\infty-cN^{-a}\) は経験モデルに過ぎず、少なくとも新方式の3段階と追加の確認段階を分ける。推定 \(J_\infty>R_*\) だけで成立とはしない。

**この証明方式での数値条件成立：**
- 全外側・両帯の完全被覆があり、
- 全ての包含・尾部・重心モーメントが有効で、
- 最終葉数が上限以下で、
- 厳密有理数で \(\min_rS_r>R_*\) となること。

その後のchat独立照合・採用判断は別段階である。本回答はそれらを代行しない。

必要なら、特定の外側点で両帯積分の**保証付き上界**を算出する。これがR*以下なら、その点では「固定近帯下界＋この遠方目標」という十分条件を満たせないと判定できる。ただし、それはHそのものが非正という証明ではない。通常の浮動小数点求積値ではこの不可能判定をしない。

# 6. 成立しない場合の原因と次の数学的改良

| 残る症状 | 原因候補 | 次の数学的改良 |
|---|---|---|
| p二分しても中点／重心幅が残る | 外側依存性が支配 | 外側方向の中心化Taylor包含を積分後の量に対して作る。外側は引き続き普遍量として最小化する |
| p曲率だけ大きい | V、𝒯、Eの相関が未保存 | rational p式の分子を共通分母で展開し、p方向のBernstein／Taylor模型でまとめて包含する。exact分子の符号証明が必要 |
| y曲率が支配に移る | q,sのy依存性 | y方向にも幾何恒等式・中心化を導入し、y分割を優先 |
| t端点やε別評価で幅が残る | 二つのεの相殺未利用 | εの和をexact代数段階で整理する。分母が違う場合の項別相殺を仮定しない |
| u尾部が初めて支配する | 打切り次数の不足 | N=31、さらに局所ϑ上界。現在は第一優先ではない |
| 正の真値は見えるが二階支払いが残る | 二階公式の限界 | 正重みに対する2点Gauss型と4階剰余。ただし新たな4階包含を先に設計する |
| 予算内で目標に達しない | 真の余裕不足または残る包含幅 | 保証付き上界による障害診断、または外側依存性の解析改善。セル数超過で押し切らない |

今回の提案では、分母相殺、回転微分、Eの同一式、正重み求積は数学的に導出でき、局所改善も得られた。**D3全体の閉鎖見通しは、改良方式による全被覆較正の結果を待つ。**

# 付録A. 参照した証拠

依頼書：`ASTRA_REQUEST_B7_V54_D3_CURVATURE_20261107.md`。
外部PCの基準ディレクトリ：
`/home/daybreak/B7_V54_MATH_STAGE_20261107/`。

| ファイル | SHA256 |
|---|---|
| DIG_V54_D3_STAGED_CALIBRATION_20261107.md | 9548990b452933fa79c43edd4143f2217ff55ca27b502c82ff0f75324f646eaa |
| V54_D3_STAGE_SCALING_ANALYSIS.json | 95f4107c1c842c2461c274269b5f5c11fae8abb453ec01712da28162fb5ce866 |
| DIG_V54_D3_STAGED_PRODUCER_EVIDENCE_MANIFEST.json | 8b3f210ca7802ac7aad174034796c47c42d085fa5e3ba2346f6911a06e118bb5 |
| b7_v54_peano3_producer.py | b0f1c3cdbb6ece659ed8fe9a94582d9006d1d0bff5a1b5c4aa507cff78c466f1 |
| b7_v54_d3_staged_uniform_producer.py | 2ce3b970483c7ca6e22fa89804565290799cc8ee098f33b805aefd05a2262886 |
| b7_v54_common_moments_proto.py | e73d57f91d8c949ddad260c28a61c6a69c0e4ac06d0dadd687a8b29a5d259059 |
| stage_20261107_verified/D3_middle_n32_outer2x2x4_N23.jsonl | 20e20b5b10087d6e3fdfebec20e259c950cd5cb7d5f000e551713a0e8c05c68a |
| stage_20261107_verified/D3_far_n32_outer2x2x4_N23.jsonl | ef60a9450283c4e6afb51dabae23a764be87dc5f7a6e0de49d90c45356759bfb |

算術・jetのコピー元：
`/home/daybreak/B7_work/b7_v53/`。

| ファイル | SHA256 |
|---|---|
| v3_fixed_128.py | ed724a764c7e3c9b01792e43ab37a68b8f62b8915a64ec663f69ce94b515bcf1 |
| v6_b_ad2_128.py | 9621a4e967f88b8e93883963e1663f101e1eb1691673fbc10ebab0ad1e02062c |

凍結マニフェスト：
`/home/daybreak/B7_work/V53_FROZEN_20261107/V53_FROZEN_MANIFEST.json`
SHA256：
`81f115ec174c53976abf1847bf41ba760b5e1a03005d2c92a60b2f659c7b6eb3`。

本文の既存全帯数値はDigのproducer記録に基づく。今回全ての全帯行を独立再計算したわけではない。JSONLは各32,768行であることとSHAを確認し、選定行の再現と難所の抽出に用いた。

# 付録B. 局所比較の厳密値

以下の値は選定18セルだけの結果である。`new_weighted` はP3単独、
`new_candidate_combined` は既存下界を保持した候補max。
帯全体の値ではない。

```json
{
  "middle": {
    "subset_only": true,
    "rows": [
      {
        "index": [
          0,
          0,
          0
        ],
        "old_combined": "-212496005019481456255178184462240381/340282366920938463463374607431768211456",
        "new_candidate_combined": "-212496005019481456255178184462240381/340282366920938463463374607431768211456",
        "new_weighted": "-340840339260583050750165408009615901/340282366920938463463374607431768211456"
      },
      {
        "index": [
          0,
          15,
          15
        ],
        "old_combined": "-2074003810032019036629738270393037/85070591730234615865843651857942052864",
        "new_candidate_combined": "-139779114829016927802276365078065/170141183460469231731687303715884105728",
        "new_weighted": "-139779114829016927802276365078065/170141183460469231731687303715884105728"
      },
      {
        "index": [
          0,
          31,
          31
        ],
        "old_combined": "-794541430700894120907736308121933/85070591730234615865843651857942052864",
        "new_candidate_combined": "74283454790629997084594479847799/170141183460469231731687303715884105728",
        "new_weighted": "74283454790629997084594479847799/170141183460469231731687303715884105728"
      },
      {
        "index": [
          15,
          0,
          31
        ],
        "old_combined": "-16105762765349876876932866695507999/85070591730234615865843651857942052864",
        "new_candidate_combined": "-43893393864680865564189469296999129/340282366920938463463374607431768211456",
        "new_weighted": "-43893393864680865564189469296999129/340282366920938463463374607431768211456"
      },
      {
        "index": [
          15,
          15,
          15
        ],
        "old_combined": "-2650476451047642837924179982289375/340282366920938463463374607431768211456",
        "new_candidate_combined": "36202612853754792684582677961983/340282366920938463463374607431768211456",
        "new_weighted": "36202612853754792684582677961983/340282366920938463463374607431768211456"
      },
      {
        "index": [
          15,
          31,
          0
        ],
        "old_combined": "-5806959262234077993971569149712701/340282366920938463463374607431768211456",
        "new_candidate_combined": "-323475299772285559299855157048781/170141183460469231731687303715884105728",
        "new_weighted": "-323475299772285559299855157048781/170141183460469231731687303715884105728"
      },
      {
        "index": [
          31,
          0,
          15
        ],
        "old_combined": "-22600538372240898308289543477817569/21267647932558653966460912964485513216",
        "new_candidate_combined": "-6511364760346759446820589374753039/21267647932558653966460912964485513216",
        "new_weighted": "-6511364760346759446820589374753039/21267647932558653966460912964485513216"
      },
      {
        "index": [
          31,
          15,
          0
        ],
        "old_combined": "-5231940864479247596507816320076621/340282366920938463463374607431768211456",
        "new_candidate_combined": "-712396524931873191244138737865305/85070591730234615865843651857942052864",
        "new_weighted": "-712396524931873191244138737865305/85070591730234615865843651857942052864"
      },
      {
        "index": [
          31,
          31,
          31
        ],
        "old_combined": "44209147316267863734699502012351/340282366920938463463374607431768211456",
        "new_candidate_combined": "169316982168887364801933608758251/170141183460469231731687303715884105728",
        "new_weighted": "169316982168887364801933608758251/170141183460469231731687303715884105728"
      }
    ],
    "sums": {
      "old_combined": "-663647018430111689890361111153479707/340282366920938463463374607431768211456",
      "new_candidate_combined": "-363823926491867781191220262895828963/340282366920938463463374607431768211456",
      "new_weighted": "-492168260732969375686207486443204483/340282366920938463463374607431768211456"
    }
  },
  "far": {
    "subset_only": true,
    "rows": [
      {
        "index": [
          0,
          0,
          0
        ],
        "old_combined": "-323429688706125658111947425052493593/340282366920938463463374607431768211456",
        "new_candidate_combined": "-271180809953554986596262012049608945/340282366920938463463374607431768211456",
        "new_weighted": "-271180809953554986596262012049608945/340282366920938463463374607431768211456"
      },
      {
        "index": [
          0,
          15,
          15
        ],
        "old_combined": "-377223247226126245306572650586209745/85070591730234615865843651857942052864",
        "new_candidate_combined": "54104499123264995738138312175698943/340282366920938463463374607431768211456",
        "new_weighted": "54104499123264995738138312175698943/340282366920938463463374607431768211456"
      },
      {
        "index": [
          0,
          31,
          31
        ],
        "old_combined": "-5418728075108016258378166530631597/340282366920938463463374607431768211456",
        "new_candidate_combined": "1686223996044976670017979707534365/340282366920938463463374607431768211456",
        "new_weighted": "1686223996044976670017979707534365/340282366920938463463374607431768211456"
      },
      {
        "index": [
          15,
          0,
          31
        ],
        "old_combined": "-4860385280988028761691890670438051/1329227995784915872903807060280344576",
        "new_candidate_combined": "-53435727313224494745723074123319733/170141183460469231731687303715884105728",
        "new_weighted": "-53435727313224494745723074123319733/170141183460469231731687303715884105728"
      },
      {
        "index": [
          15,
          15,
          15
        ],
        "old_combined": "-1527400040890700904475277601398599777/340282366920938463463374607431768211456",
        "new_candidate_combined": "55376600642099132623106123116109809/340282366920938463463374607431768211456",
        "new_weighted": "55376600642099132623106123116109809/340282366920938463463374607431768211456"
      },
      {
        "index": [
          15,
          31,
          0
        ],
        "old_combined": "0",
        "new_candidate_combined": "523736348238219116047287766095469/42535295865117307932921825928971026432",
        "new_weighted": "523736348238219116047287766095469/42535295865117307932921825928971026432"
      },
      {
        "index": [
          31,
          0,
          15
        ],
        "old_combined": "-2578740062704972311319460089434737571/340282366920938463463374607431768211456",
        "new_candidate_combined": "-154366455451506396516201081638281423/340282366920938463463374607431768211456",
        "new_weighted": "-154366455451506396516201081638281423/340282366920938463463374607431768211456"
      },
      {
        "index": [
          31,
          15,
          0
        ],
        "old_combined": "-470863749547697128041024993340466345/85070591730234615865843651857942052864",
        "new_candidate_combined": "7549070825921309222444793498629769/170141183460469231731687303715884105728",
        "new_weighted": "7549070825921309222444793498629769/170141183460469231731687303715884105728"
      },
      {
        "index": [
          31,
          31,
          31
        ],
        "old_combined": "0",
        "new_candidate_combined": "2361108385568525529677720037586151/340282366920938463463374607431768211456",
        "new_weighted": "2361108385568525529677720037586151/340282366920938463463374607431768211456"
      }
    ],
    "sums": {
      "old_combined": "-4535797569702567873274288934877653977/170141183460469231731687303715884105728",
      "new_candidate_combined": "-99900563861696092667425304442894319/85070591730234615865843651857942052864",
      "new_weighted": "-99900563861696092667425304442894319/85070591730234615865843651857942052864"
    }
  }
}
```

# 付録C. 実装再現用の試作コード

以下は既存producer算術を再利用する局所設計実験であり、独立verifierではない。
外部PCの既存ファイルへ上書きせず、別の実験ディレクトリで扱う。

同階層の `source/` に付録AとSHAが一致する次の4ファイルのコピーを置く：
`b7_v54_peano3_producer.py`、
`b7_v54_common_moments_proto.py`、
`v3_fixed_128.py`、
`v6_b_ad2_128.py`。

下の二つのコードブロックを、それぞれ指定ファイル名で保存して
`python3 curvature_prototype.py`、
続いて `python3 analytic_prototype.py` を実行する。
全領域の計算、適応分割、採用裁定は実装していない。

## C.1 curvature_prototype.py

```python
"""Local design experiment using COPIES of producer arithmetic; not an independent verifier.
No remote write, frozen update, domain certificate, or adoption decision.
"""
from fractions import Fraction as F
from math import comb
from functools import lru_cache
from itertools import product
from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path(__file__).parent/'source'))
import b7_v54_peano3_producer as old
from v3_fixed_128 import I,iv,S
from v6_b_ad2_128 import D2,intersect_value

def meetval(x,lo,hi):
    a=max(x.v.lo,lo.lo);b=min(x.v.hi,hi.hi)
    if a>b:raise ValueError('empty value intersection')
    return D2(I.raw(a,b),x.d1,x.d2)

def reduced(outer,coords,eps,direction=None,weighted=False):
    lam,tau,delta=[D2(I(*pair)) for pair in outer]
    y,p,t=[D2.variable(I(*pair)) if i==direction else D2(I(*pair)) for i,pair in enumerate(coords)]
    aa=(1-tau.sq())/(1+tau.sq());bs=2*tau/(1+tau.sq())
    nn=1-aa.sq()*y*(2-y);mm=delta+(1-delta)*aa.sq()*y*(2-y)
    s=((1-delta)*nn).sqrt();d=mm/(1+s)
    qx=(1-y)*aa/nn.sqrt();qz=bs/nn.sqrt()
    k=1+p.sq();sig=2*p/k;g=(1-p.sq())/k
    cb=eps*(1-t.sq())/(1+t.sq());sb=2*t/(1+t.sq())
    v0=d-2*sig.sq();v1=2*sig*g
    vx=v0*qx-v1*cb*qz;vy=v1*sb;vz=v0*qz+v1*cb*qx
    xx=(1-2*sig.sq())*qx-v1*cb*qz;xy=v1*sb;xz=(1-2*sig.sq())*qz+v1*cb*qx
    h=d+2*s*sig.sq();dd=d.sq()+4*s*sig.sq()
    vv=vx.sq()+vy.sq()+lam.sq()*vz.sq()
    vv=meetval(vv,lam.v.sq()*dd.v,dd.v)
    uu=vy.sq()+lam.sq()*vz.sq()
    ww=intersect_value(lam.sq()*(xx.sq()+xy.sq())+xz.sq(),F(4,25),1)
    tt=(ww*vv).sqrt();gg=lam*h
    ee=-s*qx*v1.sq()*sb.sq()-s*v1*cb*vz+(1-lam.sq())*xx*vz.sq()
    pp=h.sq()*uu;rr=ee.sq()
    q0=tt*(pp-2*rr)+gg*(pp-rr);q1=tt*(pp-2*rr)-gg*(pp-rr)
    weight=1/(1+t.sq())
    if not weighted:
        w=32*p*(1-p.sq())/(k.sq()*k)
        if direction==1:
            z=p.v.sq();kk=1+z
            w=D2(w.v,32*(1-8*z+3*z.sq())/kk.sq().sq(),
                 -384*p.v*(2-5*z+z.sq())/(kk.sq().sq()*kk))
        weight=weight*w
    return weight*q0,weight*q1,vv*(tt+gg),vv*(tt-gg)

def integral(outer,coords,eps,direction,weighted=False):
    q0,q1,a,b=reduced(outer,coords,eps,direction,weighted)
    coeff=[q0.v,q1.v] if direction is None else old.d2_coefficients(q0,q1,a,b)
    return old.integrate_rational_moments(coeff,a.v,b.v,2 if direction is None else 4,23,'D3')

@lru_cache(None)
def weighted_data(a,b,N=15):
    mid=(a+b)/2;h=b-a;v=(a*a+b*b)/2;ks=1+v;rho=(b*b-a*a)/(2+a*a+b*b)
    c=F(comb(N+3,2))*rho**(N+1)/(1-rho*F(N+4,N+2))
    def polyint(j,k):
        total=F(0)
        for l in range(k+1):
            for z in range(j+1):
                cc=comb(k,l)*(-v)**(k-l)*comb(j,z)*(-mid)**(j-z)
                for d,sign in [(1,1),(3,-1)]:
                    n=2*l+z+d
                    total+=cc*sign*(b**(n+1)-a**(n+1))/F(n+1)
        return total
    bounds=[]
    for j in (1,2):
        val=32/ks**3*sum((F((-1)**k*comb(k+2,2))*polyint(j,k)/ks**k for k in range(N+1)),F(0))
        err=32*h*(h/2)**j*c/ks**3
        bounds.append(I(val-err,val+err))
    m0=4*((2*b/(1+b*b))**2-(2*a/(1+a*a))**2)
    assert m0>0
    w1,w2=bounds;centroid=iv(mid)+w1/m0
    variance=w2-w1.sq()/m0
    variance=old.clampI(variance,0,m0*h*h/4)
    assert iv(a).lo<=centroid.lo<=centroid.hi<=iv(b).hi
    return m0,centroid,variance/(2*m0),w1,w2

def new_cell(outer,cell,weighted=False,order=(0,1,2)):
    mids=[((a+b)/2,(a+b)/2) for a,b in cell]
    fac=[iv((b-a)**2/F(24)) for a,b in cell]
    mass=(cell[0][1]-cell[0][0])*(cell[2][1]-cell[2][0])
    if weighted:
        m0,c,fac[1],_,_=weighted_data(*cell[1]);mass*=m0
        mids[1]=(F(c.lo,S),F(c.hi,S))
    else:mass*=cell[1][1]-cell[1][0]
    val=sum((integral(outer,mids,e,None,weighted) for e in (1,-1)),iv(0))
    total=val;terms={};curves={};prior=[]
    for axis in order:
        coords=[mids[i] if i in prior else cell[i] for i in range(3)]
        curv=sum((integral(outer,coords,e,axis,weighted) for e in (1,-1)),iv(0))
        term=curv*fac[axis];total+=term;curves['ypt'[axis]]=curv;terms['ypt'[axis]]=term
        prior.append(axis)
    return {'scaled':old.mult_scaled_i(total,mass),'midpoint':old.mult_scaled_i(val,mass),
            'terms':{k:old.mult_scaled_i(v,mass) for k,v in terms.items()},'curvature':curves}

OUT=((F(2,5),F(173,400)),(F(7,8),F(29,32)),(F(1,25),F(4,25)))
def subboxes(counts=(2,2,4)):
    sides=[[(a+(b-a)*F(j,n),a+(b-a)*F(j+1,n)) for j in range(n)] for (a,b),n in zip(OUT,counts)]
    return list(product(*sides))

def small_checks():
    # Intersections are consistency tests only. Algebraic identity is proved in the report.
    checks=0;max_rel_width=0
    for y,p,t,eps,axis in product([F(0),F(1,2),F(1)], [F(1,100),F(1,10),F(1,2),F(1)], [F(0),F(1,2),F(1)],[-1,1],[None,1]):
        outer=tuple(((a+b)/2,(a+b)/2) for a,b in OUT);coords=((y,y),(p,p),(t,t));z=F(37,100)**2
        q0,q1,a,b=old.geom_jet(outer,coords,eps,axis);o=(q0+q1*z)/(a+b*z).sq()
        q0,q1,a,b=reduced(outer,coords,eps,axis);n=(q0+q1*z)/(a+b*z).sq()
        for fld in ['v','d1','d2']:
            x=getattr(o,fld);v=getattr(n,fld)
            assert max(x.lo,v.lo)<=min(x.hi,v.hi),(y,p,t,eps,axis,fld)
            max_rel_width=max(max_rel_width,float(F(v.hi-v.lo,max(S,abs(v.lo),abs(v.hi)))))
            checks+=1
    return {'old_new_point_jet_overlap_checks':checks,'max_relative_new_point_interval_width':max_rel_width}

def run():
    begin=time.monotonic();checks=small_checks();rows=[]
    indices=[(0,0,0),(0,15,15),(0,31,31),(15,0,31),(15,15,15),(15,31,0),(31,0,15),(31,15,0),(31,31,31)]
    for name,(pa,pb) in [('middle',(F(1,100),F(1,10))),('far',(F(1,10),F(1)))]:
        for index in indices:
            ranges=[(F(0),F(1)),(pa,pb),(F(0),F(1))]
            cell=tuple((a+(b-a)*F(j,32),a+(b-a)*F(j+1,32)) for (a,b),j in zip(ranges,index))
            each=[]
            for oi,outer in enumerate(subboxes()):
                orig=old.cell_peano(outer,cell,'D3',23)
                new=new_cell(outer,cell,False);weighted=new_cell(outer,cell,True)
                def record(x,legacy=False):
                    if legacy:
                        return dict(lower=str(old.exact_lower(x['scaled'])),mid=float(old.exact_lower(x['value'])*x['volume']),
                            payments={k:float(old.exact_lower(v)*x['volume']) for k,v in x['curvature_terms'].items()})
                    return dict(lower=str(old.exact_lower(x['scaled'])),mid=float(old.exact_lower(x['midpoint'])),
                        payments={k:float(old.exact_lower(v)) for k,v in x['terms'].items()})
                each.append({'outer':oi,'old':record(orig,True),'cancelled':record(new),'weighted':record(weighted)})
            summary={k:float(min(F(r[k]['lower']) for r in each)) for k in ['old','cancelled','weighted']}
            rows.append({'band':name,'index':index,'cell':[[str(a),str(b)] for a,b in cell],'summary':summary,'outer_rows':each})
            print(name,index,summary,flush=True)
    sums={}
    for band in ['middle','far']:
        rr=[r for r in rows if r['band']==band]
        sums[band]={k:sum(r['summary'][k] for r in rr) for k in ['old','cancelled','weighted']}
        sums[band]['weighted_min_after_sum']=float(min(sum((F(r['outer_rows'][j]['weighted']['lower']) for r in rr),F(0)) for j in range(16)))
        sums[band]['candidate_max_min_after_sum']=float(min(sum((max(F(r['outer_rows'][j][k]['lower']) for k in ['old','cancelled','weighted']) for r in rr),F(0)) for j in range(16)))
    result={'status':'DESIGN_EXPERIMENT_ONLY_NOT_DOMAIN_CERTIFICATE','source':'local copies of Dig producer arithmetic',
        'N':23,'grid_n':32,'outer_subdivision':[2,2,4],'order':'ypt','representative_cells_per_band':9,
        'checks':checks,'sample_subset_sums_NOT_FULL_DOMAIN':sums,'seconds':time.monotonic()-begin,'rows':rows,
        'not_done':['full-domain sum','adaptive calibration','independent verifier','300000-cell feasibility certification']}
    p=Path(__file__).with_name('curvature_experiment.json');p.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))

if __name__=='__main__':run()

```

## C.2 analytic_prototype.py

```python
"""Additional exact p-rotation identities, local design experiment only."""
import curvature_prototype as c
from curvature_prototype import F,I,D2,iv,S,intersect_value,meetval
from pathlib import Path
import json,time

def meetjet(a,b):
    def meet(x,y):
        lo=max(x.lo,y.lo);hi=min(x.hi,y.hi)
        if lo>hi:raise ValueError('inconsistent equivalent jets')
        return I.raw(lo,hi)
    return D2(meet(a.v,b.v),meet(a.d1,b.d1),meet(a.d2,b.d2))

def rotation(pair,direction):
    a,b=pair
    def co(x):return (1-6*x*x+x**4)/(1+x*x)**2
    def si(x):return 4*x*(1-x*x)/(1+x*x)**2
    cc=I(co(b),co(a));ss=I(min(si(a),si(b)),1 if a*a+2*a-1<=0<=b*b+2*b-1 else max(si(a),si(b)))
    if direction!=1:return D2(cc),D2(ss)
    p=I(a,b);k=1+p.sq();alpha=4/k;beta=-8*p/k.sq()
    return D2(cc,-alpha*ss,-beta*ss-alpha.sq()*cc),D2(ss,alpha*cc,beta*cc-alpha.sq()*ss)

def fast(outer,coords,eps,direction=None,weighted=False):
    lam,tau,delta=[D2(I(*pair)) for pair in outer]
    y,p,t=[D2.variable(I(*pair)) if i==direction else D2(I(*pair)) for i,pair in enumerate(coords)]
    aa=(1-tau.sq())/(1+tau.sq());bs=2*tau/(1+tau.sq())
    nn=1-aa.sq()*y*(2-y);mm=delta+(1-delta)*aa.sq()*y*(2-y)
    s=((1-delta)*nn).sqrt();d=mm/(1+s)
    qx=(1-y)*aa/nn.sqrt();qz=bs/nn.sqrt()
    k=1+p.sq();sig=2*p/k
    cb=eps*(1-t.sq())/(1+t.sq());sb=2*t/(1+t.sq())
    co,si=rotation(coords[1],direction)
    v0=meetjet(co-s,d-2*sig.sq())
    vx=v0*qx-si*cb*qz;vy=si*sb;vz=v0*qz+si*cb*qx
    xx=co*qx-si*cb*qz;xy=si*sb;xz=co*qz+si*cb*qx
    h=meetjet(1-s*co,d+2*s*sig.sq());dd=d.sq()+4*s*sig.sq()
    vv=meetval(vx.sq()+vy.sq()+lam.sq()*vz.sq(),lam.v.sq()*dd.v,dd.v)
    uu=vy.sq()+lam.sq()*vz.sq()
    ww=intersect_value(lam.sq()*(xx.sq()+xy.sq())+xz.sq(),F(4,25),1)
    tt=(ww*vv).sqrt();gg=lam*h
    e0=-s*qx*si.sq()*sb.sq()-s*si*cb*vz+(1-lam.sq())*xx*vz.sq()
    e1=h*vx-xx*vv
    e2=vx*vz*(s*qz+(1-lam.sq())*vz)-s*qx*uu
    ee=meetjet(meetjet(e0,e1),e2)
    pp=h.sq()*uu;rr=ee.sq()
    q0=tt*(pp-2*rr)+gg*(pp-rr);q1=tt*(pp-2*rr)-gg*(pp-rr)
    weight=1/(1+t.sq())
    if not weighted:
        w=32*p*(1-p.sq())/(k.sq()*k)
        if direction==1:
            z=p.v.sq();kk=1+z
            w=D2(w.v,32*(1-8*z+3*z.sq())/kk.sq().sq(),-384*p.v*(2-5*z+z.sq())/(kk.sq().sq()*kk))
        weight*=w
    return weight*q0,weight*q1,vv*(tt+gg),vv*(tt-gg)

def run():
    c.reduced=fast;start=time.monotonic();checks=c.small_checks()
    baseline=json.loads(Path(__file__).with_name('curvature_experiment.json').read_text());rows=[]
    for r in baseline['rows']:
        cell=tuple(tuple(F(x) for x in pair) for pair in r['cell']);each=[]
        for oi,outer in enumerate(c.subboxes()):
            vals={k:c.new_cell(outer,cell,weighted=v) for k,v in [('analytic',False),('analytic_weighted',True)]}
            each.append({'outer':oi,**{k:{'lower':str(c.old.exact_lower(x['scaled'])),
                 'mid':float(c.old.exact_lower(x['midpoint'])),
                 'payments':{j:float(c.old.exact_lower(z)) for j,z in x['terms'].items()}} for k,x in vals.items()}})
        result={'band':r['band'],'index':r['index'],'cell':r['cell'],'summary':{k:float(min(F(z[k]['lower']) for z in each)) for k in ['analytic','analytic_weighted']},'outer_rows':each}
        rows.append(result);print(r['band'],r['index'],result['summary'],flush=True)
    out={'status':'DESIGN_EXPERIMENT_ONLY_NOT_DOMAIN_CERTIFICATE','checks':checks,'seconds':time.monotonic()-start,'rows':rows}
    Path(__file__).with_name('analytic_experiment.json').write_text(json.dumps(out,indent=2)+'\n')

if __name__=='__main__':run()

```


# 付録D. 今回の試作ファイルのSHA256

数学的保証の対象は本文の恒等式・求積補題であり、下記ファイルの実験結果は選定セルに限る。

| ファイル | SHA256 |
|---|---|
| curvature_prototype.py | 4459ee261d3c12c3f8f3f53dbb811fd4f5e2273312dee84c4762f71a59d7e6de |
| analytic_prototype.py | 77d826a476db3218e43ad4a3ea2b64d9edbb84298bf9ebfd074a2e2bff42d399 |
| curvature_experiment.json | c1c8afbee3266e29c3e13f1cf7a3b693f775ef6d886b76c45ddf13005f93bc7d |
| analytic_experiment.json | 28ed3a75afd43b5ed5855f422bcfef0990866b41046550de60129611e56f62ad |
| comparison_summary.json | 229c2ce87eda8633e8803fdd3d85171fdc767c23659c8f7a765b51041ceebc8f |
| extra_calibration.py | f69652bfccf51c9865471daca67d87d424a4cdafd6e5ee4575f50f331344f904 |
| extra_calibration.json | 2d07dc0564992134c9665bba003e13f35d53d0453d8193df1695b0fc1e3f19f6 |
| exact_identity_checks.json | 178e1bcb97bde8aa64dc4f07f8ab1415209f77830382a022d3054328763b5388 |
