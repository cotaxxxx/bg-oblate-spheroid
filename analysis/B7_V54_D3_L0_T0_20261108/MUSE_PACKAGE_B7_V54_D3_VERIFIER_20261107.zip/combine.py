import json, sys, hashlib
from fractions import Fraction as F
sys.path.insert(0,'../b7v54iv'); import b7iv_vleaf as VL
S=[F(0)]*16; n=0
for l in open('stageB_chat_ps8.jsonl'):
    d=json.loads(l); n+=1
    for r,x in enumerate(d['lower']): S[r]+=F(x)
N=json.load(open('near_per_r.json')); Jn=[F(x['J_near']) for x in N['per_r']]
assert n==20549 and len(Jn)==16 and N['tiling']
T=[a+b for a,b in zip(Jn,S)]; r=min(range(16),key=lambda k:T[k]); J=T[r]
lam_lo,lam_hi=F(2,5),F(173,400)
pre=J*lam_lo*VL.TWO_OVER_PI[0] if J>=0 else J*lam_hi*VL.TWO_OVER_PI[1]
H=pre-2*lam_hi*VL.KQ*VL.sigma(VL.P0)
for k in range(16): print('r=%2d near %+.6f mid+far %+.6f total %+.6f'%(k,float(Jn[k]),float(S[k]),float(T[k])))
print('min r',r,'J_total',float(J)); print('H lower =',H); print('H lower = %.10f'%float(H), 'VERDICT', 'PASS' if H>0 else 'NOT PASS')
json.dump({'per_r':[{'r':k,'J_near':str(Jn[k]),'J_midfar':str(S[k]),'J_total':str(T[k])} for k in range(16)],'min_r':r,'J_total':str(J),'H_lower':str(H)},open('D3_L0T0_chat_final.json','w'),indent=1)
