#!/usr/bin/env python3
"""chat B7 V5.4 verifier -- runner (one outer box).
usage: python3 -I chat_b7v54_run.py CELLS.json --outer la lb ta tb da db --split 2 2 4 --thbar 23/77
                 [--near NEAR_LEAVES.json] [--workers N] [--out out.jsonl]
CELLS.json : {"cells": [[[ya,yb],[pa,pb],[ta,tb]], ...]}  (rational strings), tiling [0,1]x[1/100,1]x[0,1]
NEAR_LEAVES: V5.3 leaf file (b7iv format) restricted to p <= 1/100, tiling [0,1]x[P0,1/100]x[0,1]^2
H >= pre(J_near + min_r S_r) - 2 lam_hi (275/4) sigma(P0),  pre(z) = lam_lo c_- z (z>=0), lam_hi c_+ z (z<0).
"""
import sys, os, json, time, hashlib, argparse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from multiprocessing import Pool
import chat_b7v54_iv as V
import b7iv_vleaf as VL

P_CUT = Fr(1, 100)

def work(args):
    cells, outers, thbar = args
    p3 = V.p3_lower(cells, outers, thbar)
    f0 = V.f0_lower(cells, outers)
    out = []
    for k in range(len(cells)):
        row = []
        for r in range(len(outers)):
            a = p3[k][r]; b = f0[k][r]
            if a is not None and a >= b: row.append((a, 'P3'))
            else: row.append((b, 'F0'))
        out.append(row)
    return out

def near_total(path, outer, workers):
    raw = open(path, 'rb').read(); sha = hashlib.sha256(raw).hexdigest(); d = json.loads(raw)
    leaves = [VL.parse_leaf(lf, outer) for lf in d['leaves']]
    ok, info = VL.check_tiling([lf['cell'] for lf in leaves], ((Fr(0), Fr(1)), (VL.P0, P_CUT), (Fr(0), Fr(1)), (Fr(0), Fr(1))))
    print('NEAR file', path, 'sha256', sha, '| leaves', len(leaves), '| TILING', 'PASS' if ok else 'FAIL', info, flush=True)
    chunks = [leaves[i:i + 500] for i in range(0, len(leaves), 500)]
    tot = Fr(0); src = {}
    with Pool(workers) as pool:
        for res in pool.imap(_near_work, [(outer, c) for c in chunks]):
            for lo, s in res:
                tot += lo; src[s] = src.get(s, 0) + 1
    print('NEAR sources', src, '| J_near (chat) = %.12f' % float(tot), flush=True)
    return tot, ok

def _near_work(a):
    outer, chunk = a
    return [(lb[0], lb[1]) for lb in VL.leaf_bounds(outer, chunk)]

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('cells')
    ap.add_argument('--outer', nargs=6, required=True); ap.add_argument('--split', nargs=3, type=int, default=[2, 2, 4])
    ap.add_argument('--thbar', default='23/77'); ap.add_argument('--near', default=None)
    ap.add_argument('--workers', type=int, default=os.cpu_count()); ap.add_argument('--chunk', type=int, default=40)
    ap.add_argument('--out', default='chat_b7v54_cells.jsonl')
    a = ap.parse_args()
    o = [Fr(x) for x in a.outer]; outer = ((o[0], o[1]), (o[2], o[3]), (o[4], o[5])); thbar = Fr(a.thbar)
    lam_lo, lam_hi = outer[0]
    assert lam_lo >= Fr(2, 5)
    dlo = outer[2][0]
    # theta bound: th <= (1 - chi)/(3 + chi), chi >= lam_lo sqrt(delta_lo); require the stated th_bar to be proved
    chi2 = lam_lo ** 2 * dlo                       # chi^2 lower bound
    # need (1-chi)/(3+chi) <= thbar  <=>  chi >= (1 - 3 thbar)/(1 + thbar) =: chi_req
    chi_req = (1 - 3 * thbar) / (1 + thbar)
    assert chi_req <= 0 or chi2 >= chi_req ** 2, 'th_bar not proved for this outer box'
    raw = open(a.cells, 'rb').read(); sha = hashlib.sha256(raw).hexdigest()
    cells = [tuple((Fr(x[0]), Fr(x[1])) for x in c) for c in json.loads(raw)['cells']]
    print('CELLS file', a.cells, 'sha256', sha, '| cells', len(cells), flush=True)
    t0 = time.time()
    ok, info = VL.check_tiling([c + ((Fr(0), Fr(1)),) for c in cells], ((Fr(0), Fr(1)), (P_CUT, Fr(1)), (Fr(0), Fr(1)), (Fr(0), Fr(1))))
    print('TILING (middle+far)', 'PASS' if ok else 'FAIL', info, '%.1fs' % (time.time() - t0), flush=True)
    outers = V.outer_split(outer, tuple(a.split))
    chunks = [(cells[i:i + a.chunk], outers, thbar) for i in range(0, len(cells), a.chunk)]
    S = [Fr(0)] * len(outers); src = {'P3': 0, 'F0': 0}; t0 = time.time()
    with Pool(a.workers) as pool, open(a.out, 'w') as f:
        k0 = 0
        for k, res in enumerate(pool.imap(work, chunks)):
            for j, row in enumerate(res):
                c = cells[k0 + j]
                for r, (lo, s) in enumerate(row):
                    S[r] += lo; src[s] += 1
                f.write(json.dumps({'cell': [[str(x) for x in iv] for iv in c], 'lower': [str(lo) for lo, s in row], 'src': [s for lo, s in row]}) + '\n')
            k0 += len(res)
            if (k + 1) % 50 == 0: print('  chunks', k + 1, '/', len(chunks), '%.0fs' % (time.time() - t0), flush=True)
    rmin = min(range(len(outers)), key=lambda r: S[r]); Jfar = S[rmin]
    print('per-r sums:', ['%.6f' % float(x) for x in S])
    print('sources (cell x r):', src, '| %.0fs' % (time.time() - t0))
    print('J_middle+far (chat) = %s = %.12f  (min at r=%d %s)' % (Jfar, float(Jfar), rmin, outers[rmin]))
    if a.near:
        Jn, okn = near_total(a.near, outer, a.workers)
        J = Jn + Jfar
        pre = J * lam_lo * VL.TWO_OVER_PI[0] if J >= 0 else J * lam_hi * VL.TWO_OVER_PI[1]
        H = pre - 2 * lam_hi * VL.KQ * VL.sigma(VL.P0)
        print('J_total (chat) = %.12f | H lower (chat) = %s = %.10f' % (float(J), H, float(H)))
        print('B7 V5.4 VERDICT:', 'PASS' if (H > 0 and ok and okn) else 'NOT PASS')

if __name__ == '__main__':
    main()
