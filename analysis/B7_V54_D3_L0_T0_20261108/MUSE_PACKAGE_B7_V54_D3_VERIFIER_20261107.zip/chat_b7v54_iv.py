#!/usr/bin/env python3
"""chat independent verifier for B7 V5.4 (3-D cells, u eliminated) -- 2026-11-07.

Mathematics (Codex designs, chat-audited ACCEPT):
  ASTRA_B7_V54_DESIGN_20261107.md            (u elimination, central moments, signed tail, Lemma 3)
  ASTRA_B7_V54_D3_CURVATURE_REDESIGN_20261107.md (kernel (A) without sqrt(Delta), rotation p-derivatives,
                                               E identities, positive-weight centroid rule (F)(G), min_r after sums (H))
Kernel:  K = w(p) F,  w = 32p(1-p^2)/(1+p^2)^3,  F = Q(z)/D(z)^2,  z = u^2,
         Q = (n0 + n1 z)/(1+t^2),  D = A + B z  (A = V(T+G), B = V(T-G)),  per branch eps = +-1.
Cell C = Iy x Ip x It, outer sub-box r (lam, tau, delta intervals), order y -> p -> t:
  int_C sum_eps int_0^1 K  >=  hy*ht*M0 * [ Fbar(my, c, mt) + hy^2/24 Ly + M2/(2 M0) Lp + ht^2/24 Lt ]
  Ly = inf_{r x C} Fbar_yy,  Lp = inf_{r x {my} x Ip x It} Fbar_pp,  Lt = inf_{r x {my} x {c} x It} Fbar_tt,
  c = centroid of w on Ip, M0 = int w, M2 = int w (p-c)^2  (exact rational enclosures).
u-integrals: int_0^1 q(z)/D^r du = D0^-r [ sum_{m<=N} (-1)^m C(r+m-1,m) th^m sum_j q_j mu_jm + tail ],
  th = B/(2A+B) in [0, th_bar], tail in [-c_rN(th) sum beta_i^- om_i, +c_rN(th) sum beta_i^+ om_i], N odd.
F0 (valid on C x [0,1]_u): ASTRA3 and K_FLOOR from the chat B7IV verifier (b7iv_vleaf).
Per (C, r): L = max(P3, ASTRA3, K_FLOOR);  J = min_r sum_C L_{C,r}.
Uses: b7iv_ia (IA, JT), b7iv_vk (CL), b7iv_vleaf (ASTRA3, constants, tiling) -- chat B7IV 2026-11-04.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from fractions import Fraction as Fr
from math import comb
from b7iv_ia import IA, JT, enclose_fracs, dn, up
import b7iv_vk as VK
import b7iv_vleaf as VL

NTERM = 23                                   # odd
assert NTERM % 2 == 1

# ------------------------------------------------------------- exact moment tables
def mu(j, m):
    return sum((Fr(comb(m, k) * 2 ** k * (-1) ** (m - k), 2 * (j + k) + 1) for k in range(m + 1)), Fr(0))
MU = {(j, m): mu(j, m) for j in range(4) for m in range(NTERM + 1)}
def omega(i, d, n):
    return comb(d, i) * sum(((-1) ** k * comb(d - i, k) * mu(i + k, n) for k in range(d - i + 1)), Fr(0))
OM = {(i, d): omega(i, d, NTERM + 1) for d in (1, 3) for i in range(d + 1)}
assert all(v >= 0 for v in OM.values())

def IAc(q):
    lo, hi = enclose_fracs([Fr(q)]); return IA(lo[0], hi[0])

def u_integral(qs, A, B, r, th_bar, th_extra=None):
    """Enclosure of int_0^1 (sum_j qs[j] z^j)/(A+Bz)^r du, z=u^2.  qs, A, B: IA arrays (values)."""
    d = len(qs) - 1
    B = B.clamp(0.0, None)                                    # T >= G (Gram)
    th = B / (2 * A + B)
    if th_extra is not None:
        th = th.meet(th_extra)
    th = th.clamp(0.0, float(dn(float(th_bar))) if Fr(float(th_bar)) > th_bar else float(th_bar))
    D0 = A + 0.5 * B
    # finite part, Horner in th (th >= 0)
    cm = []
    for m in range(NTERM + 1):
        s = None
        for j in range(d + 1):
            t = qs[j] * IAc(MU[(j, m)])
            s = t if s is None else s + t
        cm.append(s * float((-1) ** m * comb(r + m - 1, m)))
    S = cm[NTERM]
    for m in range(NTERM - 1, -1, -1):
        S = S * th + cm[m]
    # signed tail
    beta = []
    for i in range(d + 1):
        b = None
        for j in range(i + 1):
            t = qs[j] * IAc(Fr(comb(i, j), comb(d, j)))
            b = t if b is None else b + t
        beta.append(b)
    bh = IA(th.hi)
    ratio = bh * IAc(Fr(r + NTERM + 1, NTERM + 2))
    assert np.all(ratio.hi < 1)
    pw = bh
    for _ in range(NTERM):
        pw = pw * bh
    ctail = (pw * float(comb(r + NTERM, NTERM + 1)) / (1 - ratio)).hi
    neg = np.zeros_like(ctail); pos = np.zeros_like(ctail)
    for i in range(d + 1):
        om = IAc(OM[(i, d)])
        neg = up(neg + up(np.maximum(0.0, -beta[i].lo) * om.hi))
        pos = up(pos + up(np.maximum(0.0, beta[i].hi) * om.hi))
    tail = IA(dn(-up(ctail * neg)), up(ctail * pos))
    return (S + tail) * pow_inv(D0, r)

def pow_inv(D0, r):
    x = D0.inv(); y = x
    for _ in range(r - 1):
        y = y * x
    return y

# ------------------------------------------------------------- kernel pieces (values or one-direction jets)
def kernel(V, eps, var):
    """V = [lam, tau, delta, y, p, t] IA arrays; var in (None, 3, 4, 5).
    Returns (q0, q1, A, B, th_gram) as JT (direction var) ; th_gram is an IA value enclosure of theta."""
    z = IA(0.0); one = IA(1.0)
    xs = [JT(v, one if i == var else z, z) for i, v in enumerate(V)]
    lam, tau, delta, y, p, t = xs
    tt = tau.sq(); a = (1 - tt) / (1 + tt); b = 2 * tau / (1 + tt)
    x = y * (2 - y); A2 = a.sq()
    Ny = 1 - A2 * x
    M = delta + (1 - delta) * A2 * x
    s = ((1 - delta) * Ny).sqrt()
    d = M / (1 + s)
    sNy = Ny.sqrt(); qx = (1 - y) * a / sNy; qz = b / sNy
    tq = t.sq(); cb = eps * ((1 - tq) / (1 + tq)); sb = 2 * t / (1 + tq); jt = 1 / (1 + tq)
    pp = p.sq(); ip = 1 / (1 + pp); ip2 = ip.sq()
    C = (1 - 6 * pp + pp.sq()) * ip2
    S = 4 * p * (1 - pp) * ip2
    om = 8 * pp * ip2                                          # 1 - C = 2 sigma^2
    # exact value ranges of C, S on the p-interval (C decreasing; S max 1 at sqrt2-1)
    pv = p.v
    Pa = IA(pv.lo); Pb = IA(pv.hi)
    Cf = lambda q: (1 - 6 * q.sq() + q.sq().sq()) / (1 + q.sq()).sq()
    Sf = lambda q: 4 * q * (1 - q.sq()) / (1 + q.sq()).sq()
    Ca, Cb = Cf(Pa), Cf(Pb); Sa, Sb_ = Sf(Pa), Sf(Pb)
    fa = (Pa.sq() + 2 * Pa - 1); fb = (Pb.sq() + 2 * Pb - 1)
    cont = (fa.lo <= 0) & (fb.hi >= 0)
    Srng = IA(np.minimum(Sa.lo, Sb_.lo), np.where(cont, 1.0, np.maximum(Sa.hi, Sb_.hi)))
    C = C.withv(C.v.meet(IA(Cb.lo, Ca.hi)).clamp(-1.0, 1.0))
    S = S.withv(S.v.meet(Srng).clamp(0.0, 1.0))
    if var == 4:                                               # rotation derivatives (B): theta = 4 atan p
        ap = 4 * ip.v; bp = -8 * pv * ip2.v
        Crot = JT(C.v, -(ap * S.v), -(bp * S.v) - ap.sq() * C.v)
        Srot = JT(S.v, ap * C.v, bp * C.v - ap.sq() * S.v)
        C = C.meet(Crot); S = S.meet(Srot)
    xi_x = C * qx - S * cb * qz; xi_y = S * sb; xi_z = C * qz + S * cb * qx
    k = d - om
    vx = k * qx - S * cb * qz; vy = S * sb; vz = k * qz + S * cb * qx
    h = d + s * om
    Dl = d.sq() + 2 * s * om                                   # Delta = |v|^2
    l2 = lam.sq(); ml2 = 1 - l2
    V_ = vx.sq() + vy.sq() + l2 * vz.sq()
    V_ = V_.withv(V_.v.clamp((l2.v * Dl.v).lo, Dl.v.hi))       # lam^2 Delta <= V <= Delta (value only)
    U = vy.sq() + l2 * vz.sq()
    W = l2 * (xi_x.sq() + xi_y.sq()) + xi_z.sq()
    W = W.withv(W.v.clamp(VK.CL, 1.0))
    T = (W * V_).sqrt()
    G = lam * h
    E1 = -(s * qx * S.sq() * sb.sq()) - s * S * cb * vz + ml2 * xi_x * vz.sq()
    E2 = h * vx - xi_x * V_
    E3 = vx * vz * (s * qz + ml2 * vz) - s * qx * U
    E = E1.meet(E2).meet(E3)
    P = h.sq() * U; R = E.sq()
    X1 = T * (P - 2 * R); X2 = G * (P - R)
    q0 = (X1 + X2) * jt; q1 = (X1 - X2) * jt
    A = V_ * (T + G); B = V_ * (T - G)
    # Gram form of theta (value): |a x b|^2 / ((T+G)(3T+G)),  a=(lam xi_x, lam xi_y, xi_z), b=(vx, vy, lam vz)
    r0, r1, r2 = lam.v * xi_x.v, lam.v * xi_y.v, xi_z.v
    w0, w1, w2 = vx.v, vy.v, lam.v * vz.v
    c0 = r1 * w2 - r2 * w1; c1 = r2 * w0 - r0 * w2; c2 = r0 * w1 - r1 * w0
    thg = (c0.sq() + c1.sq() + c2.sq()) / ((T.v + G.v) * (3 * T.v + G.v))
    return q0, q1, A, B, thg

def polymul(P, Q):
    out = [None] * (len(P) + len(Q) - 1)
    for i, a in enumerate(P):
        for j, b in enumerate(Q):
            t = a * b; out[i + j] = t if out[i + j] is None else out[i + j] + t
    return out
def polyadd(*Ps):
    n = max(len(P) for P in Ps); out = [None] * n
    for P in Ps:
        for i, a in enumerate(P):
            out[i] = a if out[i] is None else out[i] + a
    return out
def polyscale(P, c):
    return [a * c for a in P]

def Fbar(V, th_bar):
    """sum_eps int_0^1 F du (value enclosure)."""
    tot = None
    for eps in (1, -1):
        q0, q1, A, B, thg = kernel(V, eps, None)
        v = u_integral([q0.v, q1.v], A.v, B.v, 2, th_bar, thg)
        tot = v if tot is None else tot + v
    return tot

def Fbar_xx(V, var, th_bar):
    """sum_eps int_0^1 d^2F/dx_var^2 du (enclosure), via K_xx numerator (D) of degree 3, r = 4."""
    tot = None
    for eps in (1, -1):
        q0, q1, A, B, thg = kernel(V, eps, var)
        Qv, Qa, Qb = [q0.v, q1.v], [q0.a, q1.a], [q0.b, q1.b]
        Dv, Da, Db = [A.v, B.v], [A.a, B.a], [A.b, B.b]
        Nz = polyadd(polymul(Qb, polymul(Dv, Dv)),
                     polyscale(polymul(Qa, polymul(Dv, Da)), -4.0),
                     polyscale(polymul(Qv, polymul(Dv, Db)), -2.0),
                     polyscale(polymul(Qv, polymul(Da, Da)), 6.0))
        v = u_integral(Nz, A.v, B.v, 4, th_bar, thg)
        tot = v if tot is None else tot + v
    return tot

# ------------------------------------------------------------- exact p-weight moments
def _atan_small(x, tol=Fr(1, 10 ** 45)):
    """[lo, hi] for atan(x), 0 <= x <= 1/2 (alternating series)."""
    s = Fr(0); k = 0; term = x
    lo = hi = None
    while True:
        s_new = s + (-1) ** k * term / (2 * k + 1)
        if k % 2 == 0: hi = s_new
        else: lo = s_new
        s = s_new; k += 1; term = term * x * x
        if lo is not None and hi is not None and term / (2 * k + 1) < tol:
            return (min(lo, hi), max(lo, hi)) if lo <= hi else (hi, lo)
def _log1p_small(yv, tol=Fr(1, 10 ** 45)):
    s = Fr(0); k = 1; term = yv; lo = hi = None
    while True:
        s_new = s + (-1) ** (k + 1) * term / k
        if k % 2 == 1: hi = s_new
        else: lo = s_new
        s = s_new; k += 1; term = term * yv
        if lo is not None and hi is not None and term / k < tol:
            return (lo, hi)
_PM = {}
def pmoments(a0, b0):
    """exact-rational enclosures (M0, c, M2) for w on [a0, b0] (0 <= a0 < b0 <= 1)."""
    key = (a0, b0)
    if key in _PM: return _PM[key]
    sg = lambda p: 2 * p / (1 + p * p)
    M0 = 4 * (sg(b0) ** 2 - sg(a0) ** 2)
    g1 = lambda p: 8 * (3 * p ** 3 + p) / (1 + p * p) ** 2           # I1 = g1 - 8 atan p
    g2 = lambda p: -16 * (3 * p ** 2 + 2) / (1 + p * p) ** 2          # I2 = g2 - 16 log(1+p^2)
    x = (b0 - a0) / (1 + a0 * b0); assert 0 < x <= Fr(1, 2)
    at = _atan_small(x)
    yv = (b0 * b0 - a0 * a0) / (1 + a0 * a0); assert 0 < yv < 1
    lg = _log1p_small(yv)
    I1 = (g1(b0) - g1(a0) - 8 * at[1], g1(b0) - g1(a0) - 8 * at[0])
    I2 = (g2(b0) - g2(a0) - 16 * lg[1], g2(b0) - g2(a0) - 16 * lg[0])
    c = (I1[0] / M0, I1[1] / M0)
    assert a0 <= c[0] <= c[1] <= b0
    M2lo = I2[0] - max(I1[0] ** 2, I1[1] ** 2) / M0
    M2hi = I2[1] - min(I1[0] ** 2, I1[1] ** 2) / M0
    M2 = (max(M2lo, Fr(0)), min(M2hi, M0 * (b0 - a0) ** 2 / 4))
    assert M2[0] <= M2[1]
    _PM[key] = (M0, c, M2)
    return _PM[key]

# ------------------------------------------------------------- cells x outer sub-boxes
def cols(rows):
    return [IA.from_pairs([r[k] for r in rows]) for k in range(6)]

ORDERS = ('ypt', 'ytp', 'pyt', 'pty', 'typ', 'tpy')
PSPLIT = 8                                   # p-pieces for curvature domains in which p is free

def p3_lower(cells, outers, th_bar, orders=ORDERS):
    """max over integration orders of the sequential lower bound (each order is a valid lower bound of the
    same cell integral). For order x1 x2 x3, L_xk is the inf of Fbar_xkxk over the cell with x1..x(k-1) fixed at
    their evaluation points (y, t: midpoints; p: centroid c) and the others over their full intervals."""
    VAR = {'y': 3, 'p': 4, 't': 5}
    need = set()
    for od in orders:
        for k, x in enumerate(od):
            need.add((x, frozenset(od[:k])))
    rows_v, meta = [], []
    rows_d = {key: [] for key in need}
    for ci, ((ya, yb), (pa, pb), (ta, tb)) in enumerate(cells):
        M0, c, M2 = pmoments(pa, pb)
        my = (ya + yb) / 2; mt = (ta + tb) / 2
        full = {'y': (ya, yb), 'p': (pa, pb), 't': (ta, tb)}; pt = {'y': (my, my), 'p': c, 't': (mt, mt)}
        for ri, o in enumerate(outers):
            rows_v.append(o + ((my, my), c, (mt, mt)))
            for (x, fx) in need:
                if 'p' in fx:
                    rows_d[(x, fx)].append(o + tuple(pt[n] if n in fx else full[n] for n in 'ypt'))
                else:                                   # inf over Ip = min over PSPLIT equal pieces
                    for i in range(PSPLIT):
                        piece = (pa + (pb - pa) * i / PSPLIT, pa + (pb - pa) * (i + 1) / PSPLIT)
                        rows_d[(x, fx)].append(o + tuple(pt[n] if n in fx else (piece if n == 'p' else full[n]) for n in 'ypt'))
            meta.append((ci, ri, M0, M2, yb - ya, tb - ta))
    Fv = Fbar(cols(rows_v), th_bar)
    Lmin = {}
    for key, rows in rows_d.items():
        lo = Fbar_xx(cols(rows), VAR[key[0]], th_bar).lo
        lo = np.where(np.isfinite(lo), lo, -np.inf)
        if 'p' not in key[1]:
            lo = lo.reshape(-1, PSPLIT).min(axis=1)
        Lmin[key] = IA(lo)
    KP = IA.from_pairs([(m[3][0] / (2 * m[2]), m[3][1] / (2 * m[2])) for m in meta])
    KY = IA.from_pairs([(m[4] ** 2 / 24, m[4] ** 2 / 24) for m in meta])
    KT = IA.from_pairs([(m[5] ** 2 / 24, m[5] ** 2 / 24) for m in meta])
    KAP = {'y': KY, 'p': KP, 't': KT}
    best = np.full(len(meta), -np.inf)
    for od in orders:
        br = Fv
        for k, x in enumerate(od):
            br = br + KAP[x] * Lmin[(x, frozenset(od[:k]))]
        lo = np.where(np.isfinite(br.lo), br.lo, -np.inf)
        best = np.maximum(best, lo)
    out = [[None] * len(outers) for _ in cells]
    for k, (ci, ri, M0, M2, hy, ht) in enumerate(meta):
        out[ci][ri] = hy * ht * M0 * Fr(float(best[k])) if np.isfinite(best[k]) else None
    return out

def p3_lower_single(cells, outers, th_bar):
    """cells: list of ((ya,yb),(pa,pb),(ta,tb)) Fractions; outers: list of ((la,lb),(ta,tb),(da,db)).
    Returns array [len(cells), len(outers)] of Fractions (P3 lower of the cell integral, valid on each outer)."""
    rows_v, rows_y, rows_p, rows_t, meta = [], [], [], [], []
    for ci, ((ya, yb), (pa, pb), (ta, tb)) in enumerate(cells):
        M0, c, M2 = pmoments(pa, pb)
        my = (ya + yb) / 2; mt = (ta + tb) / 2
        for ri, o in enumerate(outers):
            rows_v.append(o + ((my, my), c, (mt, mt)))
            rows_y.append(o + ((ya, yb), (pa, pb), (ta, tb)))
            rows_p.append(o + ((my, my), (pa, pb), (ta, tb)))
            rows_t.append(o + ((my, my), c, (ta, tb)))
            meta.append((ci, ri, M0, M2, yb - ya, tb - ta))
    Fv = Fbar(cols(rows_v), th_bar)
    Ly = Fbar_xx(cols(rows_y), 3, th_bar)
    Lp = Fbar_xx(cols(rows_p), 4, th_bar)
    Lt = Fbar_xx(cols(rows_t), 5, th_bar)
    out = [[None] * len(outers) for _ in cells]
    kp_lo = []; kp_hi = []
    for (ci, ri, M0, M2, hy, ht) in meta:
        kp_lo.append(M2[0] / (2 * M0)); kp_hi.append(M2[1] / (2 * M0))
    KP = IA.from_pairs(list(zip(kp_lo, kp_hi)))
    KY = IA.from_pairs([(m[4] ** 2 / 24, m[4] ** 2 / 24) for m in meta])
    KT = IA.from_pairs([(m[5] ** 2 / 24, m[5] ** 2 / 24) for m in meta])
    br = Fv + KY * IA(Ly.lo) + KP * IA(Lp.lo) + KT * IA(Lt.lo)
    lo = br.lo
    for k, (ci, ri, M0, M2, hy, ht) in enumerate(meta):
        if not np.isfinite(lo[k]):
            out[ci][ri] = None
        else:
            out[ci][ri] = hy * ht * M0 * Fr(float(lo[k]))
    return out

def f0_lower(cells, outers):
    """max(ASTRA3, K_FLOOR) on C x [0,1]_u for each outer (b7iv_vleaf)."""
    out = [[None] * len(outers) for _ in cells]
    leaves = [{'cell': (cy, cp, ct, (Fr(0), Fr(1)))} for (cy, cp, ct) in cells]
    for ri, o in enumerate(outers):
        a3 = VL.astra3_lower(o, leaves)
        for ci, ((ya, yb), (pa, pb), (ta, tb)) in enumerate(cells):
            kf = -2 * VL.KQ * VL.dsigma(pa, pb) * VL.dbeta_hi(ta, tb) * (yb - ya)
            out[ci][ri] = max(a3[ci], kf)
    return out

def outer_split(box, n):
    return [(l, t, d) for l in VL.parts(box[0], n[0]) for t in VL.parts(box[1], n[1]) for d in VL.parts(box[2], n[2])]
