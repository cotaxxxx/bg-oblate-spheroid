import sys
from fractions import Fraction as Fr
sys.path.insert(0,'.')
import chat_b7v54_iv as V
import numpy as np
OUT=V.outer_split(((Fr(2,5),Fr(173,400)),(Fr(7,8),Fr(29,32)),(Fr(1,25),Fr(4,25))),(2,2,4))
o=OUT[3]; TH=Fr(23,77)
(ya,yb),(pa,pb),(ta,tb)=(Fr(3,8),Fr(7,16)),(Fr(23,32),Fr(31,40)),(Fr(0),Fr(1,16))
my=(ya+yb)/2; M0,c,M2=V.pmoments(pa,pb)
for kp in (1,2,4,8,16,32):
  for kt in (1,4):
    rows=[]
    for i in range(kp):
      for j in range(kt):
        rows.append(o+((my,my),(pa+(pb-pa)*i/kp,pa+(pb-pa)*(i+1)/kp),(ta+(tb-ta)*j/kt,ta+(tb-ta)*(j+1)/kt)))
    L=V.Fbar_xx(V.cols(rows),4,TH)
    print('kp',kp,'kt',kt,'Lp_min %.4e'%np.min(L.lo), ' kappa*L*mu %.3e'%(float(M2[1]/(2*M0))*np.min(L.lo)*float((yb-ya)*(tb-ta)*M0)))
