# B7 V5.4 数学設計 — u の解析消去・中央展開の共通モーメント・3変数逐次中点下界

2026-11-07 / 作成・検算：Codex

依頼：`ASTRA_REQUEST_B7_V54_20261107(1).md`。納品名は依頼指定に従う。本書はCodexによる数学案であり、Astra・chat・Museの独立監査済み成果とは扱わない。

## 1. 結論と範囲

**判定：METHOD_PROMISING。** u方向の葉を不要にする厳密な表示、値・方向別2階微分を共通の有理モーメントで包囲する式、符号を保持した剰余、3変数の逐次中点下界を導出した。遠い帯での改善を狙う構成として有望である。ただし、D3・D4の大幅な改善量、30万葉以内での正値性、実行時間・RSSは未認証。既存の4下界に必ず勝るという主張ではない。

主な新規構成は、分母をu²=1/2で中央展開することにある。通常のq=(T−G)/(T+G)ではなく

\[
\theta=\frac{T-G}{3T+G},\qquad 0\le\theta\le\frac13
\]

を展開比に使う。D3では θ≤23/77、D4では θ≤21/79 が一様に成り立つ。これにより、値の分母次数2と、2階微分の分母次数4の双方に、同じ有限有理モーメント表と符号つき尾部を使える。arccosやχ=1での商を実装する必要はない。

| 依頼項目 | 到達点 |
|---|---|
| A：u消去・共通モーメント | 厳密表示、分母下界、中央展開、符号つき剰余を証明 |
| B：3変数中点則・jet | 全セル→中点面→中点線の下界と方向別2階分子を導出 |
| C：遠い帯の改善量 | 同領域maxによる非悪化と改善判定式を証明。実際の改善量は未較正 |
| D：近い層のκ変換 | 正確な式と可変端点の処理を提示。単純な固定区間化だけではδ依存は消えない |
| E：葉数・帯別受け持ち | 帯別規則、条件付き葉数式、30万葉の格子換算を提示。外箱別の必要葉数は未確定 |

## 2. 正典・記号・前提

数式の入力は同梱 `b7iv_vk.py` の `F_K`、既存の葉下界・接触帯処理は `b7iv_vleaf.py` とする。新たな物理的正規化やP1の証明は本書の範囲外。既存表示Hとの接続は依頼書の前提を引き継ぐ。

外側パラメータを α=(λ,τ,δ)、残る内側変数を x=(y,p,t) とする。主対象は

\[
\lambda\in[2/5,93/200],\quad\tau\in[7/8,1],\quad
\delta\in[1/25,15/64],\quad y,t\in[0,1],\ p\in[P_0,1],\quad P_0=1/2000000.
\]

D3=[1/25,4/25]、D4=[4/25,15/64]。以下のD4はB7の深さ帯である。

正典のT,G,P,R,W,V2をそのまま使う。P=Ĥ²U2、R=E²。D⁴という記号は用いず、常に `(V2)^2` と書く。Σの座標r、ASTRA3のρ、後述の幾何ベクトルは区別する。

\[
j(p,t)=\sigma'(p)\beta'(t)
=\frac{4(1-p^2)}{(1+p^2)^2(1+t^2)},\qquad C=\frac{jW}{(V2)^2}.
\]

jとWを含むCも、微分の対象に含める。

切除後の全域を Ω=[0,1]×[P0,1]×[0,1]×[0,1] とし、積分の一様下界J⁻から

\[
H\ge \operatorname{pre}(J^-)-2\lambda_{\rm hi}\frac{275}{4}\sigma(P_0),
\quad
\operatorname{pre}(z)=
\begin{cases}
\lambda_{\rm lo}c_-z&z\ge0,\\
\lambda_{\rm hi}c_+z&z<0,
\end{cases}
\]

を使う。正典の有理包囲は c_-=636619772/10^9、c_+=636619773/10^9。新方式でもこの符号処理を維持する。

## 3. 補題1：幾何・正則性・一様な展開比

### 3.1 分母下界

正典の A_c=(1−τ²)/(1+τ²)、B_s=2τ/(1+τ²)、N=1−A_c²y(2−y)、M=δ+(1−δ)A_c²y(2−y)、s=√((1−δ)N)、δ_v=M/(1+s) を使う。

A_c²+B_s²=1、0≤y(2−y)≤1 より

\[
N\ge B_s^2\ge(112/113)^2,\quad
s\ge(7/8)(112/113)=98/113,\quad
1-s^2=M,\quad \delta_v=1-s\ge\delta/2\ge1/50.
\]

またs≤√(24/25)<1である。したがってκ形の全分母と平方根は、対象の閉領域上で正の下界を持つ。

### 3.2 単位ベクトルとGram恒等式

q=(q_x,0,q_z)、e=(-c_b q_z,s_b,c_b q_x) とおく。|q|=|e|=1、q·e=0。正典に合わせ

\[
\xi=(1-2\sigma^2)q+2\sigma g e,\quad
\omega=Lq+J_t e,
\quad L=c_p-\sigma s_p/\sqrt{s},\quad J_t=g s_p/\sqrt{s}.
\]

g²+σ²=1、c_p²+s_p²=1、s_p=2√s σc_p/δ_v である。

まず |ξ|²=(1−2σ²)²+4σ²g²=1。また

\[
L^2+J_t^2=c_p^2+s_p^2/s-2c_p\sigma s_p/\sqrt{s}
=c_p^2+s_p^2(1-\delta_v)/s=1.
\]

同様に ξ·ω=c_p+√s σs_p=Ĥ。したがって0<Ĥ≤1。

\[
\mathbf a=(\lambda\xi_x,\lambda\xi_y,\xi_z),\qquad
\mathbf b=(\omega_x,\omega_y,\lambda\omega_z)
\]

と定義すると |a|²=w²、|b|²=V2、a·b=λĤ=G。Lagrange恒等式から

\[
\boxed{T^2-G^2=|\mathbf a\times\mathbf b|^2\ge0.}
\]

よって λ²≤T≤1、0<G≤T、V2≥λ²≥4/25。さらに
U2=V2−ω_x²=ω_y²+λ²ω_z²≥0、したがってP,R≥0。

### 3.3 θの一様上界

\[
\widehat H=\frac{\delta_v+2s\sigma^2}{\sqrt{\delta_v^2+4s\sigma^2}},\qquad
\widehat H^2-M
=\frac{4s^2(\sigma^2-\delta_v/2)^2}{\delta_v^2+4s\sigma^2}\ge0.
\]

この恒等式は M=δ_v(1+s)、s=1−δ_v を代入して分子を展開すれば得られる。したがって

\[
\chi=G/T\ge\lambda\sqrt M\ge\lambda\sqrt\delta.
\]

D3ではχ≥2/25、D4ではχ≥4/25。関数(1−χ)/(3+χ)はχ≥0で減少するから

\[
0\le\theta=\frac{1-\chi}{3+\chi}\le
\begin{cases}23/77&\text{D3},\\21/79&\text{D4}.\end{cases}
\]

実装では減算を避けた

\[
\boxed{\theta=\frac{|\mathbf a\times\mathbf b|^2}{(T+G)(3T+G)}}
\]

と、直接式(T−G)/(3T+G)の値包囲を交差できる。必要ならv=(1−χ)/2も Gram/[2T(T+G)] で評価できる。交差してよいのは同じ量の正しい包囲だけである。

### 3.4 正則性と端点

本節の正の下界により、κ形の核は対象閉領域の近傍で内側・外側変数について滑らかである。p=0への拡張もκ形ならW=0として滑らか。p=1ではj=0だが、元のp有理座標は正則であり、1−p²で割らない。τ=1、y=1、t=0,1、χ=1も本書の式の特異点ではない。

η形はp=0で使わない。κ座標で√(1−σ²)を使う別表示はσ=1で微分に不向きなので、近い層だけに限定する。

## 4. 補題2：値と2階微分を同じ有理核にする

補助記号z=u²と置く。sは正典の幾何量に予約しているため、u²をsとは書かない。

\[
A=T+G,\ B=T-G,\ D(z)=A+Bz,
\]
\[
n_0=T(P-2R)+G(P-R),\quad n_1=T(P-2R)-G(P-R),
\quad Q(z)=C(n_0+n_1z).
\]

正典の分子をu²でまとめるだけで、枝εごとに

\[
\boxed{K(x,u;\alpha)=\frac{Q(u^2)}{D(u^2)^2},\qquad
f_\varepsilon(x;\alpha)=\int_0^1\frac{Q(u^2)}{D(u^2)^2}\,du.}
\tag{4.1}
\]

P項・R項の積分を別々に評価してから差し引く必要はない。Qの係数を先に結合する。ただし、自然区間評価が常に狭くなるとは限らない。

x_iをy,p,tのいずれかとし、微分時にはuを固定する。商の微分から

\[
\partial_i\frac Q{D^2}=\frac{Q_iD-2QD_i}{D^3},
\]
\[
\boxed{\partial_i^2\frac Q{D^2}
=\frac{Q_{ii}D^2-4Q_iDD_i-2QDD_{ii}+6Q(D_i)^2}{D^4}.}
\tag{4.2}
\]

Q,Dおよび各導関数はzの1次多項式である。従って、(4.1)は分母次数r=2・分子次数d≤1、(4.2)はr=4・d≤3で閉じる。明示的な巨大展開を必要としない。

補題1の正則性とコンパクト性により、2階までの微分とu積分を交換できる。値と曲率はいずれも同じexact fから作る。有限打切りの下界関数やmax関数を微分してはならない。

### jetに渡す規則

各方向で次数2までのTaylor係数を保持し、積は係数畳込みで計算する。a(h)=a0+a1h+a2h²なら

- 逆数：b0=1/a0、b1=−a1/a0²、b2=a1²/a0³−a2/a0²。
- 平方根：b0=√a0、b1=a1/(2b0)、b2=(a2−b1²)/(2b0)。
- 実2階微分は2a2。

正典の `JT.b` はTaylor係数ではなく実2階微分である。接続時に2倍を重ねない。Q_i,Q_ii,D_i,D_iiを作ってから(4.2)のz多項式を畳み込む。C=jW/(V2)²の微分を落とさない。

## 5. 補題3：中央展開と符号つきの有理剰余

これは値・曲率の双方に使う一般補題である。

### 5.1 仮定と有限モーメント

0≤B≤A、D0=A+B/2>0、θ=B/(2A+B)∈[0,1/3]、整数r≥1、多項式Q(z)=Σ_{j=0}^d q_j z^jとする。z=u²、w=2u²−1とすれば

\[
A+Bu^2=D_0(1+\theta w).
\]

Nを正の奇数とする（第一候補N=23または31）。

\[
\mu_{jm}=\int_0^1u^{2j}(2u^2-1)^mdu
=\sum_{k=0}^m\binom mk\frac{2^k(-1)^{m-k}}{2(j+k)+1}\in\mathbb Q.
\tag{5.1}
\]

有限部を

\[
S_{r,N}(Q,\theta)=\sum_{m=0}^{N}(-1)^m\binom{r+m-1}{m}\theta^m
\left(\sum_{j=0}^d q_j\mu_{jm}\right)
\tag{5.2}
\]

とする。μ表は有理数で事前生成する。展開後の大きな有理項を浮動小数で相殺させてμを作ってはならない。Σ_j q_j μ_jmを先に結合し、θの多項式はHorner等で包囲する。

### 5.2 尾部の符号

\[
(1+\theta w)^{-r}=\sum_{m=0}^N(-1)^m\binom{r+m-1}{m}\theta^mw^m+\mathcal R_{r,N}(w).
\]

N+1は偶数。Taylorの積分剰余で、(1+x)^{-r}のN+1階導関数はx>−1で正だから

\[
0\le\mathcal R_{r,N}(w)\le c_{r,N}(\bar\theta)w^{N+1},\qquad
c_{r,N}(b)=\frac{\binom{r+N}{N+1}b^{N+1}}{1-b(r+N+1)/(N+2)}
\tag{5.3}
\]

が成り立つ。ただし0≤θ≤b、b(r+N+1)/(N+2)<1。

上界の証明：二項級数のm≥N+1の絶対値をとる。隣接係数比は b(r+m)/(m+1) でmについて非増加。最初の比 b(r+N+1)/(N+2) を上界とし、|w|≤1を使って初項以降を幾何級数で支配すれば(5.3)。Nが奇数という符号条件は省けない。

### 5.3 分子の相殺を尾部にも残す

次数dのBernstein基底 B_{i,d}(z)=binom(d,i) z^i(1−z)^{d−i} で

\[
Q(z)=\sum_{i=0}^d\beta_iB_{i,d}(z),\qquad
\beta_i=\sum_{j=0}^i\frac{\binom ij}{\binom dj}q_j.
\]

\[
\omega_{i,d,N}=\int_0^1B_{i,d}(u^2)(2u^2-1)^{N+1}du
=\binom di\sum_{k=0}^{d-i}(-1)^k\binom{d-i}k\mu_{i+k,N+1}\ge0.
\tag{5.4}
\]

これも非負の有理数である。β_i^- = max(0,−β_i)、β_i^+=max(0,β_i)として

\[
\boxed{
\frac{S_{r,N}-c_{r,N}\sum_i\beta_i^-\omega_{i,d,N}}{D_0^r}
\le\int_0^1\frac{Q(u^2)}{(A+Bu^2)^r}du
\le\frac{S_{r,N}+c_{r,N}\sum_i\beta_i^+\omega_{i,d,N}}{D_0^r}.}
\tag{5.5}
\]

証明：0≤R≤c w^{N+1}、B_i≥0を各符号の係数へ適用し、積分する。β_iを作る線形変換の係数は非負なので、正確な係数に対してβ_i^-≤Σ_j binom(i,j)/binom(d,j) q_j^-。従って、この尾部支払いは同じ中央展開で単項式の負係数を個別に支払う方法より大きくならない。有限精度の区間包囲どうしの優劣までは保証しない。

### 5.4 外箱・セルでの区間評価

q_j,A,Bの包囲を、同じ外箱と同じ内側領域で作る。β_iの区間下端ℓ_i・上端h_iから、β_i^-≤max(0,−ℓ_i)、β_i^+≤max(0,h_i)を使う。(5.2)の有限部は区間演算で、(5.3)(5.4)の定数は厳密有理数で評価する。D0^{-r}は正の区間として、符号を考慮した区間乗算を行う。負の分子にD0の下端を機械的に掛ける、といった符号誤りを避ける。

T≥4/25なのでD0=(3T+G)/2≥6/25。値のθ包囲だけをGram式や既知上界と交差してよい。曲率は(4.2)で先にexactに微分済みのため、clampやmaxの導関数は一切不要。

### 5.5 剰余定数の目安

以下はc_{r,N}単独の参考小数であり、積分全体の誤差ではない。実際の支払いはD0^{-r}Σβ_i^-ω_iを掛けたものとなる。

| 帯 | r | N=23 | N=31 |
|---|---:|---:|---:|
| D3：θ≤23/77 | 2 | 9.230×10⁻¹² | 7.688×10⁻¹⁶ |
| D3 | 4 | 1.119×10⁻⁹ | 1.566×10⁻¹³ |
| D4：θ≤21/79 | 2 | 5.354×10⁻¹³ | 1.756×10⁻¹⁷ |
| D4 | 4 | 6.454×10⁻¹¹ | 3.561×10⁻¹⁵ |

N=23で先に試し、実際の尾部支払いがセル誤差予算を超えた場合にN=31を試す規則は数学的に有効。次数・選択規則は実装契約で固定する。本書はN=23が全セルで十分とは主張しない。

## 6. 補題4：3変数逐次中点下界

f=f_++f_-とし、外箱α全体についてC²とする。セルC=I1×I2×I3の中点をm、辺長をh_iとする。積分順1→2→3に対し

\[
\boxed{\int_C f\ge |C|\left[
f(m)^-+\frac{h_1^2}{24}d_1^-+\frac{h_2^2}{24}d_2^-+\frac{h_3^2}{24}d_3^-\right],}
\tag{6.1}
\]

ここで

\[
d_1^-\le\inf_{\alpha\times C}f_{11},\quad
d_2^-\le\inf_{\alpha\times\{m_1\}\times I_2\times I_3}f_{22},\quad
d_3^-\le\inf_{\alpha\times\{m_1\}\times\{m_2\}\times I_3}f_{33}.
\]

**2階微分をすべて中点線だけで評価してはならない。** 正しい順序は全セル、2次元の中点面、1次元の中点線である。

証明：1次元中点則の誤差を非負Peano核で表す。長さhの区間で核の積分はh³/24。まずx1を積分し、f11の全セル下界を使う。残るf(m1,x2,x3)に同じ操作をx2、x3の順に適用する。それぞれを残りの辺長で掛け合わせると(6.1)。外箱αは各操作で固定され、使用した下界はα全体で一様なので、最後の不等式も一様。

混合内側微分は不要。6通りの積分順それぞれが有効であり、同じCの下界としてmaxを取れる。ただし6通りを計算する費用は別途較正する。最初は(y,p,t)と(p,y,t)など、契約で定めた少数の順序でよい。

各d_i^-は(4.2)の分子に(5.5)を適用する。枝の微分下界は和で結合する。

## 7. 枝の対化と外側一様性

### 7.1 ε=±1

正典では枝の違いはc_b=±(1−t²)/(1+t²)に入る。T,G等も枝で変わるため、共通でない分母を同じと仮定して差し引いてはならない。

安全な主線は、枝ごとに(4.1)(4.2)(5.5)を評価し、その区間を加えること。これは正負の大きなP積分・R積分を分離することとは異なる。枝間の追加相殺は保証しない。

追加候補としてc_bを補助変数cとし、k(c)+k(−c)をTaylor展開すれば奇数係数は厳密に消える。ただしc∈[−|c_b|,|c_b|]全体で定義・剰余を保証する必要がある。物理的な関係c²+s_b²=1はcを独立に動かすと失われるため、この補助区間へ補題1の単位ベクトル下界を無条件に転用できない。本書はこの追加対化を採用条件に含めない。

### 7.2 外側Taylorを積分後まで保持する方法

外箱の中心α_cについて

\[
f(\alpha,x)=f(\alpha_c,x)+\sum_i f_i(\alpha_c,x)\Delta\alpha_i
+\int_0^1(1-v)\Delta\alpha^\top D^2_\alpha f(\alpha_c+v\Delta\alpha,x)\Delta\alpha\,dv.
\]

中心値・勾配の積分区間を先にセル間で合計する。|∫D²_{ij}f|≤C_ijを全線分上で保証すれば

\[
\int f(\alpha,x)dx\ge I_c^-+\inf_{\Delta\alpha\in A}\sum_i I_i\Delta\alpha_i
-\tfrac12\sum_{i,j}C_{ij}|\Delta\alpha_i\Delta\alpha_j|.
\]

実装では区間勾配I_iの積を外向きに評価する。外側の混合微分を省略できない。同じ商の混合微分は

\[
\partial_{ij}(Q/D^2)=
\frac{Q_{ij}D^2-2(Q_iD_j+Q_jD_i)D-2QDD_{ij}+6QD_iD_j}{D^4}
\]

であり、分子次数≤3の同じモーメントに閉じる。ただしそれらの積分を中点則で認証するなら、さらに内側微分が必要になる。主線より高価になる可能性があり、初期実装の必須項目にはしない。λ単調性は使わない。

## 8. 近い層：κ変換の正確な式と限界

κ=2√s σ/δ_vとすると

\[
\sigma=\frac{\delta_v\kappa}{2\sqrt s},\quad
c_p=(1+\kappa^2)^{-1/2},\quad s_p=\kappa c_p,\quad
W\,d\sigma=\frac{\delta_v}{s}\frac{\kappa}{\sqrt{1+\kappa^2}}d\kappa.
\tag{8.1}
\]

p∈[p_a,p_b]の像は

\[
\kappa_a(\alpha,y)=2\sqrt s\,\sigma(p_a)/\delta_v,\quad
\kappa_b(\alpha,y)=2\sqrt s\,\sigma(p_b)/\delta_v.
\]

変換後は幾何量をσ=δ_vκ/(2√s)、g=√(1−σ²)で作り、(4.1)のCを

\[
C_\kappa=\frac{\beta'(t)}{(V2)^2}\frac{\delta_v}{s}
\frac{\kappa}{\sqrt{1+\kappa^2}}
\tag{8.2}
\]

に置き換える。κを固定した微分ではc_p,s_pがδに依存しなくなる。ただしσ、δ_v/s、残る幾何量、そして積分端点のδ依存は残る。

### 8.1 単純な[0,1]正規化では期待した利点が消える

κ=κ_a+v(κ_b−κ_a)と正規化すると

\[
\sigma=\sigma(p_a)+v[\sigma(p_b)-\sigma(p_a)]
\]

となり、κ=2√s σ/δ_vのδ依存がc_p,s_pへ戻る。また

\[
\frac{\delta_v}{s}(\kappa_b-\kappa_a)
=\frac{2[\sigma(p_b)-\sigma(p_a)]}{\sqrt s}.
\]

これは正確な変換だが、固定κで得たδ依存の軽減を、そのまま正規化後の利点と主張できない。

### 8.2 共通κ核と端の可変区間

外箱とyセル上の有理包囲を κ_a∈[a_-,a_+]、κ_b∈[b_-,b_+] とする。a_+≤b_-なら固定の共通核[a_+,b_-]を3変数(y,κ,t)で積分できる。両端は[κ_a,a_+]と[b_-,κ_b]である。

左端の密度がその全可変領域でL_left以上なら、そのκ積分は

\[
\min(0,L_{\rm left})(a_+-a_-)
\]

以上。右端も min(0,L_right)(b_+−b_-) 以上。これらをy,tの面積で積分すれば、有効な保守的補正となる。未知の長さに正の寄与を期待しない。

評価用の長方形拡張でσ>1になったり、単位ベクトルの前提が失われたりする場合には、その拡張を使わない。近い層p≤1/100に限定して、拡張上でも0≤σ≤σ_max<1を保証する。共通核が空、端補正が大きい、または分母を保証できない場合は元のp座標へ戻す。

この構成の効果には端区間幅の評価が必要である。依頼書の「約−1.4の床」をどこまで上げられるかは、本書では未定量。κ変換だけで床が消えるとの結論は出さない。

## 9. 実装に渡す最終手順・失敗条件

1. 外箱αと共通3次元セルCを受け取る。入力有理端点、帯、積分順、打切り次数を記録する。
2. 枝ごとに正典のκ形からT,G,P,R,Cを生成し、Q,Dを作る。必要ならη形から得た同量の包囲と交差する。
3. 中点ではr=2,d=1の(5.5)、曲率では指定した全セル・中点面・中点線でr=4,d=3の(5.5)を使う。
4. 有理μ・ω、上界θ_bar、符号つき尾部、正のD0の区間を使い、値・曲率の下界を得る。
5. 枝を合算し、(6.1)を作る。複数順序を用いた場合は同じCの下界としてmaxを取る。
6. C×[0,1]_uを**ちょうど**覆う旧4次元葉の下界を合計し、旧合計と新下界のmaxを取る。
7. 内側セルを和、外箱分割を最小値で結合し、接触帯を一度だけ支払い、§2の符号つきprefactorを適用する。

旧葉と共通3次元セルの境界が一致しない場合、共通細分上で旧下界を再評価する必要がある。既存葉の積分下界を体積比で任意の部分領域へ配分する操作は無効。

**新候補を無効にする条件：** 前提域外、D0の正値を確認できない、θの有効包囲なし、幾何包囲の交差が空、非有限値、(5.3)の比が1以上、Nが偶数なのに同じ尾部符号を使用、セル被覆の不一致、曲率評価域不足、変数変換後の領域保証不足。この場合は新候補だけを捨て、既存の有効な下界を使う。

## 10. V5.3との差分・改善量・葉数

### 10.1 変えるもの／維持するもの

| 項目 | V5.4案 |
|---|---|
| 内側積分 | uを有限有理モーメント＋厳密尾部で消去。葉座標はy,p,t |
| 新下界 | 中央展開モーメントによる3次元逐次中点下界 |
| 旧4下界 | 維持。共通積分領域の合計で新下界とmax |
| 曲率 | exact核を先に微分。全セル→面→線で包囲 |
| 正規化・接触帯 | 変更しない |
| 外箱全域一様性 | 維持。外箱ごとの最小値結合を変更しない |
| 証明書・監査 | 新たな3次元被覆・次数・剰余・比較領域の仕様とverifierが必要 |

### 10.2 定量的に言える改善判定

共通セルごとの旧合計をL_old,C、新候補をL_new,Cとする。

\[
\Delta_C=\max(0,L_{\rm new,C}-L_{\rm old,C}),\qquad
J^-_{54}=J^-_{53}+\sum_C\Delta_C.
\tag{10.1}
\]

したがって同じ領域・外箱上の下界は悪化しない。これは精度についての保証であり、処理時間・メモリの保証ではない。

\[
J_{\rm crit}=\frac{2\lambda_{\rm hi}(275/4)\sigma(P_0)}{\lambda_{\rm lo}c_-}>0
\]

とすれば、外箱の正値に十分な条件は
Σ_C Δ_C > J_crit−J^-_53。これをp帯ごとに集計すれば、遠い帯の回復だけで足りるかを判定できる。

u方向の中点誤差項そのものは消える。ただし、その代わりにモーメント包囲の幅・尾部・残る3方向の曲率が入る。旧ZEROTH・ASTRA3が選ばれたセルでどれだけ改善するかは、これらを同じセルで実際に評価するまで数値を出せない。資料の「遠い帯約−6」をそのまま回復可能量とはしない。

### 10.3 条件付き格子数式

長方形領域Rの辺長L_i、体積Vについて、選択した中点則の負の曲率を −f_ii≤M_i（M_i≥0）で一様に支配できるとする。各方向n_i等分の曲率支払いは

\[
E_{\rm curv}\le\frac V{24}\sum_{i=1}^3\frac{M_iL_i^2}{n_i^2}.
\tag{10.2}
\]

外箱の全積分に必要な閾値、他帯の寄与、有限部と尾部を計上した後、曲率へ許される正の予算gが得られたなら、a_i=VM_iL_i²/24として

\[
n_i\ge\left\lceil\sqrt{3a_i/g}\right\rceil
\]

でE_curv≤gとなる（a_i=0ではn_i=1）。有限部の下界もその格子で保証する必要があり、gを未計算のまま使ってはならない。

| 対象 | 30万葉と比較できる確定算術 | 実際の必要葉数 |
|---|---|---|
| D3の外箱1つ | 一様3D格子66³=287,496、67³=300,763 | M_i、有限部、尾部の全箱評価未了のため未確定 |
| D4の外箱1つ | 同上 | 同上。θ上界はD3より小さいが曲率が小さいとは限らない |

参考として4D一様格子では23⁴=279,841、24⁴=331,776。u消去は細分の次元を1つ減らす。ただし適応格子の実測葉数をこの換算で予測することはできない。

N=31、枝2つ、中点1評価＋方向別曲率3評価なら、(5.2)の素朴な係数収縮だけで1セルあたり2×(2×32+3×4×32)=896項。jet、区間演算、尾部、複数順序の費用はこれに加わる。RSS/葉を旧版の28KBから単純換算しない。

### 10.4 帯ごとの受け持ち

| p帯 | 主候補 | フォールバック・扱い |
|---|---|---|
| [0,P0) | 既存接触帯補正 | 新たな葉を作らず一度だけ支払う |
| [P0,10⁻³] | 既存4下界 | 新3D下界は定義できるが初期較正の優先度は低い |
| [10⁻³,10⁻²] | p座標の新3D下界と旧合計のmax | 固定κ共通核案は端補正を評価した場合だけ候補追加 |
| [10⁻²,10⁻¹] | 新3D下界を優先較正 | 同じC×[0,1]の旧合計へ戻せる |
| [10⁻¹,1] | 新3D下界を優先較正 | p=1では元の有理p座標を使用 |

## 11. 検算結果と未解決事項

### 実施済みの小検算

付録のスクリプトをローカル環境で実行した。producerの本走、外部PCの較正、既存証明書・ソースの変更、commit/pushは行っていない。

- 有理点792組で、中央展開尾部の非負性と(5.3)の上界を厳密分数で検査：PASS。
- 尾部重み24個の非負性と総和恒等式を厳密分数で検査：PASS。
- 独立の2次jet除算と(4.2)の一致を50組の厳密分数で検査：PASS。
- 既存χ級数に使う25個のモーメント恒等式を厳密分数で検査：PASS。
- 実核の代表6点×2枝で共通分子表示、閉形式、数値求積、正典の点区間値を照合：PASS。閉形式との差の最大参考値2.23×10⁻¹⁵未満。
- 単位ベクトル・Gram恒等式の点計算誤差の最大参考値6.67×10⁻¹⁶未満。
- 符号の異なる合成分子2例で有理包囲と求積を比較：PASS（求積側は診断）。

有限点の検査や浮動小数の一致は、上記補題の証明の代替ではない。一般の保証は本文の恒等式・剰余証明による。

### 未解決・NOT_RUN

1. **D3・D4の全外箱でのM_iと有限部・尾部の一様評価：NOT_RUN。** 実装・較正は依頼の役割分担でDigの担当。実際の共通3Dセル集合も同梱されていない。
2. **30万葉以内での大幅改善・正値：未認証。** 必要条件は(10.1)の回復量と(10.2)の誤差予算で特定した。
3. **近い層のκ端補正の実効性：未認証。** 必要な量はa_+−a_-、b_+−b_-、および各端帯の密度下界。単純な正規化ではδ依存が戻ることは示した。
4. **ε対化による追加改善：未認証。** 主線の妥当性には不要。
5. **時間・RSS、旧実測値の再取得：NOT_RUN。** 本書の葉換算は工程見積もり用の算術に限る。
6. **新verifierの独立監査：NOT_RUN。** 本書の数式と小検算をchatが監査し、実装後のverifierをMuseが監査する流れを維持する。

本書は既存の24/40 PASSを再判定せず、新たな箱PASSやFREEZEを宣言しない。

## 12. 入力と再現情報

入力は添付の改訂版パッケージ。同梱の有理モーメント・符号つき尾部の考え方を用いたが、中央展開の比θ、偶数次数剰余、重みωを持つ(5.1)〜(5.5)は本書で導出した形である。D5のq上界や正規化係数をB7へ転用していない。

付録スクリプトはPython標準ライブラリ、NumPy、SciPyと、依頼パッケージの変更していない `b7iv_vk.py`・`b7iv_ia.py` を使う。再実行時はこれらを同じディレクトリに置く。実行結果JSONはスクリプトの隣に作られる。これは有限検算用であり、B7のproducer/verifierではない。


### SHA-256

| ファイル | SHA-256 |
|---|---|
| `ASTRA_REQUEST_B7_V54_20261107(1).md` | `5a64768e47673f7b7c57530034082b0cc8f8fb975890219e7b086aee11cd61ea` |
| `ASTRA_PACKAGE_B7_V54_20261107(1).zip` | `d404901e6100afdde442e905b3e8b9a1a73274c4b005cc178df1d743f7bc7d36` |
| `b7iv_vk.py` | `f2d6c4a91f30e672a8eb5014c30900604b2c455b44ddce55d1e7256e93bbe524` |
| `b7iv_ia.py` | `b2d26146647903e9656413548b354113efcc818a75cd73d02f043e6ceb56f7e4` |
| `check_v54_math.py` | `2c7a66850c539d6ae51f990e6b584cd102618c3c90aeb66abd655e5155b75928` |
| `check_v54_math_result.json` | `6e0daecff03eeff9560207f87207cfc4fd701ab0f71131f70d2ea052260a1219` |

## 付録A：実施した有限検算スクリプト

```python
#!/usr/bin/env python3
"""Finite algebra checks and point diagnostics; NOT a B7 producer/certificate."""
from fractions import Fraction as Q
from math import comb, sqrt, acos, pi
from itertools import product
import json, hashlib
from pathlib import Path
from scipy.integrate import quad

def moment(j,m):
    return sum((Q(comb(m,k)*2**k*(-1)**(m-k),2*(j+k)+1)
                for k in range(m+1)),Q(0))

def weight(i,d,n):
    return comb(d,i)*sum(((-1)**k*comb(d-i,k)*moment(i+k,n)
                         for k in range(d-i+1)),Q(0))

def tail(r,n,theta):
    ratio=theta*Q(r+n+1,n+2)
    assert ratio<1
    return comb(r+n,n+1)*theta**(n+1)/(1-ratio)

def bernstein(coeff):
    d=len(coeff)-1
    return [sum((Q(comb(i,j),comb(d,j))*coeff[j] for j in range(i+1)),Q(0))
            for i in range(d+1)]

def enclosure(coeff,A,B,r,n):
    D0=A+B/2;theta=B/(2*A+B)
    finite=sum(((-1)**m*comb(r+m-1,m)*theta**m*
                sum((c*moment(j,m) for j,c in enumerate(coeff)),Q(0))
                for m in range(n+1)),Q(0))
    beta=bernstein(coeff);d=len(coeff)-1;c=tail(r,n,theta)
    neg=sum((max(Q(0),-b)*weight(i,d,n+1) for i,b in enumerate(beta)),Q(0))
    pos=sum((max(Q(0), b)*weight(i,d,n+1) for i,b in enumerate(beta)),Q(0))
    return (finite-c*neg)/D0**r,(finite+c*pos)/D0**r

class Jet:
    # coefficients of 1,h,h^2; this small checker uses exact rational arithmetic.
    def __init__(self,a,b=Q(0),c=Q(0)): self.x=(Q(a),Q(b),Q(c))
    @staticmethod
    def j(v): return v if isinstance(v,Jet) else Jet(v)
    def __add__(self,v):
        v=self.j(v);return Jet(*(a+b for a,b in zip(self.x,v.x)))
    __radd__=__add__
    def __neg__(self):return Jet(*(-a for a in self.x))
    def __sub__(self,v):return self+-self.j(v)
    def __rsub__(self,v):return self.j(v)+-self
    def __mul__(self,v):
        v=self.j(v);return Jet(*(sum((self.x[i]*v.x[k-i] for i in range(k+1)),Q(0)) for k in range(3)))
    __rmul__=__mul__
    def inv(self):
        a,b,c=self.x;return Jet(1/a,-b/a**2,b*b/a**3-c/a**2)
    def __truediv__(self,v):return self*self.j(v).inv()

def geometry(lam,tau,delta,y,p,t,eps):
    ac=(1-tau*tau)/(1+tau*tau);bs=2*tau/(1+tau*tau)
    x=y*(2-y);N=1-ac*ac*x;M=delta+(1-delta)*ac*ac*x
    s=sqrt((1-delta)*N);rs=sqrt(s);dv=M/(1+s)
    qx=(1-y)*ac/sqrt(N);qz=bs/sqrt(N)
    sig=2*p/(1+p*p);g=(1-p*p)/(1+p*p)
    cb=eps*(1-t*t)/(1+t*t);sb=2*t/(1+t*t)
    kap=2*rs*sig/dv;cp=1/sqrt(1+kap*kap);sp=kap*cp
    W=4*sig/sqrt(dv*dv+4*s*sig*sig)
    L=cp-sig*sp/rs;Jt=g*sp/rs
    ox=L*qx-Jt*cb*qz;oy=Jt*sb;oz=L*qz+Jt*cb*qx
    xx=(1-2*sig*sig)*qx-2*sig*g*cb*qz
    xy=2*sig*g*sb;xz=(1-2*sig*sig)*qz+2*sig*g*cb*qx
    Hh=cp+rs*sig*sp;V2=1-(1-lam*lam)*oz*oz
    U2=V2-ox*ox;w2=lam*lam*(xx*xx+xy*xy)+xz*xz
    T=sqrt(w2*V2);G=lam*Hh
    E=-s*qx*Jt*Jt*sb*sb-s*Jt*cb*oz+(1-lam*lam)*xx*oz*oz
    P=Hh*Hh*U2;R=E*E;jac=4*(1-p*p)/((1+p*p)**2*(1+t*t))
    rv=(lam*xx,lam*xy,xz);vv=(ox,oy,lam*oz)
    cross=(rv[1]*vv[2]-rv[2]*vv[1],rv[2]*vv[0]-rv[0]*vv[2],rv[0]*vv[1]-rv[1]*vv[0])
    gram=sum(c*c for c in cross)
    return dict(T=T,G=G,P=P,R=R,C=jac*W/V2**2,V2=V2,Hh=Hh,M=M,
                unit_omega=ox*ox+oy*oy+oz*oz,unit_xi=xx*xx+xy*xy+xz*xz,
                dot=xx*ox+xy*oy+xz*oz,gram=gram,theta=(T-G)/(3*T+G))

def run():
    exact={};nchecks=0
    for r,n,theta in product([2,4],[7,15,23],[Q(0),Q(1,10),Q(23,77),Q(1,3)]):
        for k in range(33):
            s=Q(k,32);w=2*s-1
            poly=sum(((-1)**m*comb(r+m-1,m)*(theta*w)**m for m in range(n+1)),Q(0))
            rem=1/(1+theta*w)**r-poly
            assert 0<=rem<=tail(r,n,theta)*w**(n+1)
            nchecks+=1
    exact['signed_remainder_rational_point_tests']=nchecks
    weights=0
    for d,n in product([1,3],[7,15,23,31]):
        ws=[weight(i,d,n+1) for i in range(d+1)]
        assert min(ws)>=0 and sum(ws)==moment(0,n+1)
        weights+=len(ws)
    exact['nonnegative_exact_tail_weights']=weights
    for k in range(1,51):
        N=Jet(Q(k-25,7),Q(3-k,11),Q(k+2,13))
        D=Jet(Q(k+3,5),Q(k-9,17),Q(4-k,19))
        a,b,c=N.x;d,e,f=D.x
        expected=(2*c*d*d-4*b*d*e-4*a*d*f+6*a*e*e)/d**4
        assert 2*(N/D/D).x[2]==expected
    exact['second_derivative_jet_tests']=50
    for n in range(0,25):
        # Identity used for chi series: integral (1-u^2)^n du = a_n.
        integral=sum((Q((-1)**k*comb(n,k),2*k+1) for k in range(n+1)),Q(0))
        from math import factorial
        assert integral==Q(4**n*factorial(n)**2,factorial(2*n+1))
    exact['original_series_moment_identities']=25
    diagnostics=[];maxerr=0.0;geomerr=0.0
    samples=[(0.4,0.875,0.04,0.3,0.001,0.4),
             (0.4325,0.94,0.10,0.5,0.01,0.5),
             (0.465,1.0,0.16,1.0,0.2,0.0),
             (0.4,0.875,0.16,0.0,0.6,1.0),
             (0.465,0.94,15/64,0.5,0.9,0.5),
             (0.4,1.0,15/64,0.0,1.0,0.0)]
    import numpy as np
    import b7iv_vk as vk
    from b7iv_ia import IA
    for args,eps in product(samples,[-1,1]):
        g=geometry(*args,eps);T,G,P,R,C=[g[x] for x in ['T','G','P','R','C']]
        A=T+G;B=T-G;n0=T*(P-2*R)+G*(P-R);n1=T*(P-2*R)-G*(P-R)
        def direct(u):return C*((1+u*u)*T*(P-2*R)+(1-u*u)*G*(P-R))/((1+u*u)*T+(1-u*u)*G)**2
        def common(u):return C*(n0+n1*u*u)/(A+B*u*u)**2
        val=quad(direct,0,1,epsabs=1e-11,epsrel=1e-11)[0]
        val2=quad(common,0,1,epsabs=1e-11,epsrel=1e-11)[0]
        chi=G/T
        if abs(1-chi)>1e-5:
            I=acos(chi)/(2*sqrt(1-chi*chi));J=((2-chi*chi)*I-chi/2)/(1-chi*chi)
            val3=C/T*(P*I-R*J);maxerr=max(maxerr,abs(val-val3))
        geomerr=max(geomerr,abs(g['unit_omega']-1),abs(g['unit_xi']-1),abs(g['dot']-g['Hh']),abs(T*T-G*G-g['gram']))
        assert g['Hh']**2+1e-12>=g['M']
        assert -1e-12<=g['theta']<=float(Q(23,77))+1e-12
        assert abs(val-val2)<1e-8
        # Cross-check scalar formula against supplied interval kernel at u=0.37.
        V=[IA(float(x)) for x in (*args,0.37)]
        it=vk.F_K(V,eps,form='kappa')[1].v
        scalar=direct(0.37)
        assert float(it.lo)-1e-9<=scalar<=float(it.hi)+1e-9
        diagnostics.append({'parameters':args,'epsilon':eps,'u_integral_reference':val,'theta_reference':g['theta'],'common_form_error':abs(val-val2)})
    assert maxerr<1e-8 and geomerr<1e-12
    # Synthetic signed numerator integrals. Enclosures are exact; quadrature comparisons are diagnostics.
    synth=[]
    for coeff,r in [([Q(2),Q(-3)],2),([Q(-3),Q(7),Q(-5),Q(2)],4)]:
        A=Q(4,5);B=Q(3,5);lo,hi=enclosure(coeff,A,B,r,15)
        val=quad(lambda u:sum(float(c)*u**(2*j) for j,c in enumerate(coeff))/(float(A)+float(B)*u*u)**r,0,1,epsabs=1e-12)[0]
        assert float(lo)-1e-13<=val<=float(hi)+1e-13
        synth.append({'r':r,'lower_exact':str(lo),'upper_exact':str(hi),'quadrature_reference':val,'width_reference':float(hi-lo)})
    tails=[{'band':label,'theta_upper':str(th),'r':r,'N':n,'tail_coefficient_exact':str(tail(r,n,th)),
            'tail_coefficient_reference':float(tail(r,n,th))}
           for label,th in [('global',Q(1,3)),('D3',Q(23,77)),('D4',Q(21,79))]
           for r,n in product([2,4],[23,31])]
    result={'status':'FINITE_CHECKS_PASS_NOT_A_B7_CERTIFICATE','exact_checks':exact,
            'point_diagnostics':diagnostics,'max_closed_form_difference_reference':maxerr,
            'max_geometry_identity_error_reference':geomerr,'synthetic_signed_integrals':synth,
            'tail_constants':tails,'not_run':['full_outer_box_curvature_enclosures','D3_D4_leaf_calibration','runtime_RSS_benchmarks','new_independent_verifier_audit']}
    return result

if __name__=='__main__':
    out=Path(__file__).with_name('check_v54_math_result.json')
    result=run();out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'exact_checks':result['exact_checks'],
                     'point_diagnostics':len(result['point_diagnostics']),
                     'max_geometry_error':result['max_geometry_identity_error_reference'],
                     'max_closed_form_error':result['max_closed_form_difference_reference'],
                     'result_file':str(out)},indent=2))
```

## 付録B：検算結果（参考小数を含む）

```json
{
  "status": "FINITE_CHECKS_PASS_NOT_A_B7_CERTIFICATE",
  "exact_checks": {
    "signed_remainder_rational_point_tests": 792,
    "nonnegative_exact_tail_weights": 24,
    "second_derivative_jet_tests": 50,
    "original_series_moment_identities": 25
  },
  "point_diagnostics": [
    {
      "parameters": [
        0.4,
        0.875,
        0.04,
        0.3,
        0.001,
        0.4
      ],
      "epsilon": -1,
      "u_integral_reference": 3.0306156950294385,
      "theta_reference": 0.03287776838571037,
      "common_form_error": 0.0
    },
    {
      "parameters": [
        0.4,
        0.875,
        0.04,
        0.3,
        0.001,
        0.4
      ],
      "epsilon": 1,
      "u_integral_reference": 7.638704144559693,
      "theta_reference": 0.010256537092102481,
      "common_form_error": 1.7763568394002505e-15
    },
    {
      "parameters": [
        0.4325,
        0.94,
        0.1,
        0.5,
        0.01,
        0.5
      ],
      "epsilon": -1,
      "u_integral_reference": 1.092908452636011,
      "theta_reference": 0.14373867332974571,
      "common_form_error": 2.220446049250313e-16
    },
    {
      "parameters": [
        0.4325,
        0.94,
        0.1,
        0.5,
        0.01,
        0.5
      ],
      "epsilon": 1,
      "u_integral_reference": 1.468924550470661,
      "theta_reference": 0.13904839899279103,
      "common_form_error": 2.220446049250313e-16
    },
    {
      "parameters": [
        0.465,
        1.0,
        0.16,
        1.0,
        0.2,
        0.0
      ],
      "epsilon": -1,
      "u_integral_reference": -0.5542076464600352,
      "theta_reference": 0.21367240730371578,
      "common_form_error": 1.1102230246251565e-16
    },
    {
      "parameters": [
        0.465,
        1.0,
        0.16,
        1.0,
        0.2,
        0.0
      ],
      "epsilon": 1,
      "u_integral_reference": -0.5542076464600352,
      "theta_reference": 0.21367240730371578,
      "common_form_error": 1.1102230246251565e-16
    },
    {
      "parameters": [
        0.4,
        0.875,
        0.16,
        0.0,
        0.6,
        1.0
      ],
      "epsilon": -1,
      "u_integral_reference": 3.759953008159416,
      "theta_reference": 0.024098111670792212,
      "common_form_error": 4.440892098500626e-16
    },
    {
      "parameters": [
        0.4,
        0.875,
        0.16,
        0.0,
        0.6,
        1.0
      ],
      "epsilon": 1,
      "u_integral_reference": 3.759953008159416,
      "theta_reference": 0.024098111670792212,
      "common_form_error": 4.440892098500626e-16
    },
    {
      "parameters": [
        0.465,
        0.94,
        0.234375,
        0.5,
        0.9,
        0.5
      ],
      "epsilon": -1,
      "u_integral_reference": 1.8732678391342363,
      "theta_reference": 0.0017027633338566033,
      "common_form_error": 2.220446049250313e-16
    },
    {
      "parameters": [
        0.465,
        0.94,
        0.234375,
        0.5,
        0.9,
        0.5
      ],
      "epsilon": 1,
      "u_integral_reference": 1.6976209488894722,
      "theta_reference": 0.0037233082584966627,
      "common_form_error": 0.0
    },
    {
      "parameters": [
        0.4,
        1.0,
        0.234375,
        0.0,
        1.0,
        0.0
      ],
      "epsilon": -1,
      "u_integral_reference": 0.0,
      "theta_reference": 3.469446951953614e-17,
      "common_form_error": 0.0
    },
    {
      "parameters": [
        0.4,
        1.0,
        0.234375,
        0.0,
        1.0,
        0.0
      ],
      "epsilon": 1,
      "u_integral_reference": 0.0,
      "theta_reference": 3.469446951953614e-17,
      "common_form_error": 0.0
    }
  ],
  "max_closed_form_difference_reference": 2.220446049250313e-15,
  "max_geometry_identity_error_reference": 6.661338147750939e-16,
  "synthetic_signed_integrals": [
    {
      "r": 2,
      "lower_exact": "89296722328810028639834665044/64202712388027943478056787479",
      "upper_exact": "89296722708260445645154955856/64202712388027943478056787479",
      "quadrature_reference": 1.3908559213496818,
      "width_reference": 5.9101929325353155e-09
    },
    {
      "r": 4,
      "lower_exact": "-822467744291567557055657780888000/303359950195616676521967175911543",
      "upper_exact": "-822467617383906619051485162095600/303359950195616676521967175911543",
      "quadrature_reference": -2.7111942102704965,
      "width_reference": 4.18340195718551e-07
    }
  ],
  "tail_constants": [
    {
      "band": "global",
      "theta_upper": "1/3",
      "r": 2,
      "N": 23,
      "tail_coefficient_exact": "625/4613015762523",
      "tail_coefficient_reference": 1.3548620515837307e-10
    },
    {
      "band": "global",
      "theta_upper": "1/3",
      "r": 2,
      "N": 31,
      "tail_coefficient_exact": "121/4460974528717395",
      "tail_coefficient_reference": 2.7124118109409948e-14
    },
    {
      "band": "global",
      "theta_upper": "1/3",
      "r": 4,
      "N": 23,
      "tail_coefficient_exact": "8125/491636600541",
      "tail_coefficient_reference": 1.652643434410538e-08
    },
    {
      "band": "global",
      "theta_upper": "1/3",
      "r": 4,
      "N": 31,
      "tail_coefficient_exact": "10285/1853020188851841",
      "tail_coefficient_reference": 5.550398242758888e-12
    },
    {
      "band": "D3",
      "theta_upper": "23/77",
      "r": 2,
      "N": 23,
      "tail_coefficient_exact": "300156727497813735493853598089400625/32520529025200355641730433693072046470382788491",
      "tail_coefficient_reference": 9.229761522797506e-12
    },
    {
      "band": "D3",
      "theta_upper": "23/77",
      "r": 2,
      "N": 31,
      "tail_coefficient_exact": "338480194594671639359118667957650365757415689/440243496925134640378802462232225407230403305375872152426867",
      "tail_coefficient_reference": 7.688476876064604e-16
    },
    {
      "band": "D3",
      "theta_upper": "23/77",
      "r": 4,
      "N": 23,
      "tail_coefficient_exact": "11706112372414735684260290325486624375/10464405345712548499637449274259053385722268791",
      "tail_coefficient_reference": 1.118660065782996e-09
    },
    {
      "band": "D3",
      "theta_upper": "23/77",
      "r": 4,
      "N": 31,
      "tail_coefficient_exact": "3196757393394121038391676308488920121042259285/20415742446540394676869666688426923375989627821783724440489",
      "tail_coefficient_reference": 1.565829605151507e-13
    },
    {
      "band": "D4",
      "theta_upper": "21/79",
      "r": 2,
      "N": 23,
      "tail_coefficient_exact": "33817623985795365081569120789300625/63161920759661303930624631601432011745814999131",
      "tail_coefficient_reference": 5.354115831036154e-13
    },
    {
      "band": "D4",
      "theta_upper": "21/79",
      "r": 2,
      "N": 31,
      "tail_coefficient_exact": "742889220232742980703551377631251845778491883/42312549027676369790190638982639908221988184430940072898748249",
      "tail_coefficient_reference": 1.755718427048259e-17
    },
    {
      "band": "D4",
      "theta_upper": "21/79",
      "r": 4,
      "N": 23,
      "tail_coefficient_exact": "3956662006338057714543587132348173125/61305517210392042373531395403209377390794544293",
      "tail_coefficient_reference": 6.454006403305174e-11
    },
    {
      "band": "D4",
      "theta_upper": "21/79",
      "r": 4,
      "N": 31,
      "tail_coefficient_exact": "147339695346160691172871023230198282746067556795/41373760301230301363783873616939498213893359419794017398617543",
      "tail_coefficient_reference": 3.561186952150911e-15
    }
  ],
  "not_run": [
    "full_outer_box_curvature_enclosures",
    "D3_D4_leaf_calibration",
    "runtime_RSS_benchmarks",
    "new_independent_verifier_audit"
  ]
}
```
