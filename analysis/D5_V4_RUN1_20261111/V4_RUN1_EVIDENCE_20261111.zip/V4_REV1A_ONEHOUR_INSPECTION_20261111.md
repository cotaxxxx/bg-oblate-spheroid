# D5 V4-RUN-1 rev1a — 1時間検収と20ワーカー切替記録

検収日：2026-11-11 JST。実行機：daybreak-works。記録者：ChatGPT（Desktop Commander Remoteによる実機読出し）。

## 12ワーカーの1時間検収

- 02:33:12 JST：PID 1139261、`--workers 12 --refine`、既存352箱から再開。起動時 `free -h` available 約25GiB。
- 02:43:43 JST：495箱、available 約25GiB。forkserver配下に12ワーカー。
- 03:37:14 JST：1256箱、available 約25GiB、Mem used 4.6GiB、Swap used 997MiB/8.0GiB。
- 03:37:25 JST：1258箱、JSONL全行parse成功、重複0、全1258件 `pos=True`、`H_float` 最小 0.1774539652475178。12ワーカーは各CPUほぼ100%、RSSはワーカー更新サイクルの時点で約20～152MiB。ワーカーPIDの交代を確認（1箱ごとに再生成）。
- `journalctl -k --since 2026-11-11 02:33:00` と `dmesg -T` に新規OOM記録なし。kernel journal閲覧権限を確認済み。
- driver SHA256：`1bbd66dfa8b5e8180eca01fd852138ad3d7d7fc9bbfdb16783df2525025f4c0c`、凍結rev1aと一致。
- **判定：12ワーカーの1時間検収PASS。** 起動時25GiB availableから1時間後も25GiB availableであり、メモリ累積増加は見られない。進捗あり・全件POS・OOMなし。20ワーカーへ移行を許可。

## 20ワーカー切替

- 03:37:44 JST：旧PID 1139261の専用PGID 1139261の15プロセス（親、forkserver、tracker、12ワーカー）だけを照合。B7監視PID 621947は別PGID 621946。
- 旧PGIDにのみSIGTERM。1秒後に全プロセス停止を確認。SIGKILLは不使用。
- 停止直前・停止直後の出力バックアップを保存。双方のSHA256 `ccfdb89d5e86fe298db158b624ce216d40d2f502f19b33de8488320be4cc6b4b`、1259件、JSON parse失敗0、重複0、全件POS、末尾改行あり。
- 03:37:45 JST：同一driver・同一入力・同一出力を用いて `--workers 20 --refine` で再開。新PID `1143679`、専用PGID `1143679`。
- 03:37:56 JST：新グループ23プロセス（親+tracker+forkserver+20ワーカー）、available 約25GiB。
- 03:38:56 JST：新親PID 1143679と20ワーカー稼働、各ワーカーCPU約100%、RSS約53～142MiB、available 23GiB、Swap used 997MiB、進捗1263件、ログ末尾POS、新規OOMなし。
- 旧プール停止時に`resource_tracker`のsemaphore leak警告が1回表示された。OOMではない。新20ワーカーの継続監視で再発や異常終了の有無を確認する。
- B7監視PID 621947は停止・変更せず稼働確認。B7公式32/40。

**総合：12ワーカー1時間検収PASS、20ワーカー切替成功、ただし20ワーカー長時間安定性は未検証。数学的大域証明はOPEN。**
