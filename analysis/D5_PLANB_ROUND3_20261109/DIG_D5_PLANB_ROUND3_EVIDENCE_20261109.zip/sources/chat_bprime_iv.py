#!/usr/bin/env python3
"""chat independent verifier for D5 B' v2 (outer face r=1):  H(L_lam Q(tau)) >= m_d.

H = (1/pi) sum_{eps=+-1} int_0^1 int_0^1 g dr ds,  contact-centred polar coordinates (spec v2):
  r = tan(psi/4), s = tan(theta/2) (theta in [0,pi/2]; eps=-1 flips cos theta for theta in [pi/2,pi])
  g = f * sin(psi) * 4/(1+r^2) * 2/(1+s^2),  f = gamma/(2K) [alpha R(gamma) - gamma beta R'(gamma)]
R^(m)(gamma) = 2(-1)^m m! (1+gamma)^-(m+1) K_{m+1}(q),  q=(1-gamma)/(1+gamma),
K_n(q) = int_0^1 (1-t^2)^(n-1) (1+q t^2)^-n dt, enclosed by the p-series (p = 1-q in [0,1]):
  (1+q t^2)^-n = (1+t^2)^-n sum_k C(n+k-1,k) (p t^2/(1+t^2))^k   (all terms >= 0; ratio <= p/2 <= 1/2),
  int_0^1 (1-t^2)^(n-1) t^(2k) (1+t^2)^-(n+k) dt = int_0^{pi/4} cos^(n-1)(2th) sin^(2k)(th) dth  (exact: rational + rational*pi).
Cells: sequential midpoint-line rule  |C| [ g(m) + h_r^2/24 inf_C g_rr + h_s^2/24 inf_{r=m_r} g_ss ].
Interval arithmetic and jets: chat_m40iv / chat_m22iv (Muse-audited), jets used with DA=0, DB=2.
usage: python3 -I chat_bprime_iv.py COVER.json [--workers N] [--out out.jsonl] [--target 1/5]
COVER.json: {"boxes":[{"tau":[a,b],"lam":[a,b]},...], "cells":{"r":32,"s":32}}
"""
import sys, os, json, argparse, time
from fractions import Fraction as Fr
from math import comb, factorial
from multiprocessing import Pool
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import chat_m40iv as M
I = M.I; J = M.J; rd = M.base.rd; ru = M.base.ru
PI = I(Fr(103993, 33102), Fr(104348, 33215))          # 3.14159265301 < pi < 3.14159265392
NP = 60

_W = {}
def wallis(m):                                           # int_0^{pi/2} cos^m = (rational, rational*pi) pair
    if m not in _W:
        if m % 2: v = (Fr(1), Fr(0)); num, den = 1, 1
        else: v = (Fr(0), Fr(1, 2))
        r = Fr(1)
        for j in range(m, 1, -2): r *= Fr(j - 1, j)
        _W[m] = (r * v[0], r * v[1])
    return _W[m]
_MM = {}
def Mnk(n, k):
    """int_0^{pi/4} cos^(n-1)(2th) sin^(2k)(th) dth = (1/2) int_0^{pi/2} c^(n-1) ((1-c)/2)^k dphi, c=cos phi."""
    if (n, k) not in _MM:
        A = Fr(0); B = Fr(0)
        for j in range(k + 1):
            co = Fr(comb(k, j) * (-1) ** j, 2 ** k)
            a, b = wallis(n - 1 + j); A += co * a; B += co * b
        val = I(A) + PI * I(B)
        _MM[(n, k)] = val * I(Fr(1, 2))
    return _MM[(n, k)]
_K = {}
def Kn_point(n, p):
    """interval for K_n(1-p), p rational in [0,1]."""
    key = (n, p)
    if key not in _K:
        # truncation N: smallest N <= NP with tail bound <= 2^-80 (else N = NP); bound is rigorous for any N
        h = p / 2; N = NP; hf = float(h)                 # float only chooses N; the tail used below is exact
        for N0 in range(0, NP + 1):
            rf = (n + N0 + 1) / (N0 + 2) * hf
            if rf < 0.99 and comb(n + N0, N0 + 1) * hf ** (N0 + 1) / (1 - rf) <= 2.0 ** -82:
                N = N0; break
        # tail: term_k <= C(n+k-1,k) (p/2)^k * Mnk(n,0) (since t^2/(1+t^2) <= 1/2); ratio (n+k)/(k+1) * p/2 <= rho
        rho = Fr(n + N + 1, N + 2) * h
        assert rho < 1
        tail = ru(Fr(comb(n + N, N + 1)) * h ** (N + 1) * Mnk(n, 0).b / (1 - rho))
        X = I(p); s = Coef(n, N)                             # Horner with coefficients c_k = C(n+k-1,k) M(n,k) >= 0, p >= 0
        for k in range(N - 1, -1, -1):
            s = s * X + Coef(n, k)
        s = s + I(0, tail)
        _K[key] = s
    return _K[key]
_C = {}
def Coef(n, k):
    if (n, k) not in _C: _C[(n, k)] = Mnk(n, k) * I(comb(n + k - 1, k))
    return _C[(n, k)]
def Kn(n, q):
    """K_n is decreasing in q; q interval inside [0,1]."""
    G = 2 ** 48                                          # coarse outward grid for p (valid: K_n monotone in p)
    pa = Fr((1 - q.b).numerator * G // (1 - q.b).denominator, G)
    pb = Fr(-((-(1 - q.a).numerator * G) // (1 - q.a).denominator), G)
    pa = max(pa, Fr(0)); pb = min(pb, Fr(1))
    lo = Kn_point(n, pa).a; hi = Kn_point(n, pb).b       # q large <-> p small <-> K small
    return I(lo, hi)
def Rderivs(g0):
    """intervals of R^(m)(gamma) for gamma in g0 (subset of [0,1]), m=0..3."""
    q0 = I(rd((1 - g0.b) / (1 + g0.b)), ru((1 - g0.a) / (1 + g0.a)))
    q0 = I(max(q0.a, Fr(0)), min(q0.b, Fr(1)))
    ainv = (I(1) + g0).recip()
    out = []; apow = ainv
    for m in range(4):
        out.append(Kn(m + 1, q0) * apow * I(Fr(2 * (-1) ** m * factorial(m))))
        apow = apow * ainv
    return out

def g_coeff(tau, lam, R, S, eps, var):
    """var None: value of g; 'r'/'s': second derivative of g in that variable. R,S intervals (cell or point)."""
    DB = 0 if var is None else 2
    one = J.const(1, 0, DB)
    r = J.const(R, 0, DB); s = J.const(S, 0, DB)
    if var == 'r': r.c[(0, 1)] = I(1)
    if var == 's': s.c[(0, 1)] = I(1)
    a = (I(1) - tau * tau) / (I(1) + tau * tau); b = tau * 2 / (I(1) + tau * tau)
    r2 = r * r; s2 = s * s
    Sh = (r * 2 / (one + r2)).cap0(0, 1); Ch = ((one - r2) / (one + r2)).cap0(0, 1)
    sinpsi = Sh * Ch * 2; cospsi = one - Sh * Sh * 2
    cth = (one - s2) / (one + s2) * I(eps); sth = (s * 2 / (one + s2)).cap0(0, 1)
    sigma = Sh * 2
    nx = Sh * (-a) - Ch * cth * b; ny = Ch * sth; nz = Sh * (-b) + Ch * cth * a
    xiz = cospsi * b + cth * sinpsi * a
    lam2 = lam * lam
    K = (one - nz * nz * (I(1) - lam2)).cap0(lam.a ** 2, 1)
    n = (ny * ny / K).cap0(0, 1)
    w = (J.const(lam2, 0, DB) + xiz * xiz * (I(1) - lam2)).sqrt().cap0(lam.a, 1)
    k = K.sqrt()
    gam = (sigma * lam / (w * k * 2)).cap0(0, 1)
    one2K = one - K * 2
    al = one - n - n * one2K * one2K * 2
    be = n * one2K * one2K
    g0 = gam.c[(0, 0)]; D = gam.nil()
    Rd = Rderivs(g0)
    Rj = J.const(Rd[0], 0, DB) + D * Rd[1] + D * D * (Rd[2] * I(Fr(1, 2)))
    Rpj = J.const(Rd[1], 0, DB) + D * Rd[2] + D * D * (Rd[3] * I(Fr(1, 2)))
    f = gam / (K * 2) * (al * Rj - gam * be * Rpj)
    gfun = f * sinpsi * (one * 4 / (one + r2)) * (one * 2 / (one + s2))
    return gfun.c[(0, 0)] if var is None else gfun.c[(0, 2)] * 2

def grid(spec):
    if isinstance(spec, int): e = [Fr(k, spec) for k in range(spec + 1)]
    else: e = [Fr(x) for x in spec]
    assert e[0] == 0 and e[-1] == 1 and all(x < y for x, y in zip(e, e[1:]))
    return list(zip(e, e[1:]))

def box_lower(box, cells):
    tau = I(Fr(box['tau'][0]), Fr(box['tau'][1])); lam = I(Fr(box['lam'][0]), Fr(box['lam'][1]))
    rg = grid(cells['r']); sg = grid(cells['s'])
    raw = I(0); mid = I(0); cur = I(0)
    for eps in (1, -1):
        for ra, rb in rg:
            hr = rb - ra; rm = (ra + rb) / 2
            for sa, sb in sg:
                hs = sb - sa; sm = (sa + sb) / 2; A = hr * hs
                v = g_coeff(tau, lam, I(rm), I(sm), eps, None) * A
                cr = g_coeff(tau, lam, I(ra, rb), I(sa, sb), eps, 'r') * (A * hr * hr / 24)
                cs = g_coeff(tau, lam, I(rm), I(sa, sb), eps, 's') * (A * hs * hs / 24)
                mid = mid + v; cur = cur + cr + cs; raw = raw + v + cr + cs
    pinv = PI.recip()
    lo = raw.a * (pinv.a if raw.a >= 0 else pinv.b)
    return lo, mid, cur

def check_cover(boxes, tau_lo=Fr(0), tau_hi=Fr(1), lam_lo=Fr(2, 5), lam_hi=Fr(33, 50)):
    ts = sorted({(Fr(b['tau'][0]), Fr(b['tau'][1])) for b in boxes}); ls = sorted({(Fr(b['lam'][0]), Fr(b['lam'][1])) for b in boxes})
    if len(boxes) != len(ts) * len(ls) or len({(tuple(b['tau']), tuple(b['lam'])) for b in boxes}) != len(boxes): return False, 'not a product grid'
    for seg, lo, hi in ((ts, tau_lo, tau_hi), (ls, lam_lo, lam_hi)):
        if seg[0][0] != lo or seg[-1][1] != hi or any(x[1] != y[0] for x, y in zip(seg, seg[1:])): return False, 'gap/overlap'
    return True, '%d x %d = %d boxes' % (len(ts), len(ls), len(boxes))

def work(arg):
    box, cells, target = arg; t0 = time.time(); lo, mid, cur = box_lower(box, cells)
    return {'box': box, 'cells': cells, 'lower': str(lo), 'lower_float': float(lo), 'pass': lo >= target,
            'mid_lo_raw': float(mid.a), 'curv_lo_raw': float(cur.a), 'sec': round(time.time() - t0, 1)}

if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('cover'); ap.add_argument('--workers', type=int, default=1)
    ap.add_argument('--out', default='chat_bprime_out.jsonl'); ap.add_argument('--target', default='1/5'); ap.add_argument('--nocover', action='store_true')
    a = ap.parse_args(); d = json.load(open(a.cover)); target = Fr(a.target); cells = d.get('cells', {'r': 32, 's': 32})
    ok = True
    if not a.nocover:
        ok, info = check_cover(d['boxes']); print('COVER', 'PASS' if ok else 'FAIL', info, flush=True)
    res = []
    with Pool(a.workers) as pool, open(a.out, 'w') as f:
        for r in pool.imap_unordered(work, [(b, cells, target) for b in d['boxes']]):
            res.append(r); f.write(json.dumps(r) + '\n'); f.flush()
            print(r['box'], '%.6f' % r['lower_float'], 'PASS' if r['pass'] else 'FAIL', r['sec'], 's', flush=True)
    worst = min(res, key=lambda r: Fr(r['lower']))
    print('boxes', len(res), '| all >= target:', all(r['pass'] for r in res), '| worst', worst['box'], '%.6f' % worst['lower_float'])
    if not a.nocover: print('BPRIME VERDICT:', 'PASS' if (ok and all(r['pass'] for r in res)) else 'NOT PASS')
