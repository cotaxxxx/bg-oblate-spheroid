from fractions import Fraction as F
from concurrent.futures import ProcessPoolExecutor, as_completed
from time import monotonic
from pathlib import Path
import json, os,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import chat_bprime_iv as B
I,J=B.I,B.J
CUT=F(552960,16777217)
PI=B.PI
TL={"E":("0","1/32","2/5","41/100"),"M":("15/32","1/2","1/2","51/100")}
def asjet(x,DB):return J.const(x,0,DB)
def g_coeff(tau,lam,Dbox, parent_j, i, Ziv, Siv, eps, var):
    """(3.12) value or second derivative in z/s using rigorous 1-D jets."""
    DB=0 if var is None else 2
    one=asjet(1,DB)
    z=asjet(Ziv,DB); s=asjet(Siv,DB)
    if var=='z': z.c[(0,1)]=I(1)
    if var=='s': s.c[(0,1)]=I(1)
    Dj=F(2)**(-16+parent_j)
    Ui=F(2)**(-12+i)
    ell=max(Dj,Ui)
    # boxes all refer to parent Dj and never rechoose scale after subdivision
    zeta=asjet(Dbox/I(ell),DB)
    r=one-zeta*ell
    u=z*ell
    a=(I(1)-tau*tau)/(I(1)+tau*tau)
    b=tau*2/(I(1)+tau*tau)
    L=one+u*u
    qbar=z*z*I(8*ell)/(L*L)
    Bbar=z*(one-u*u)*4/(L*L)
    s2=s*s
    ct=(one-s2)/(one+s2)*I(eps)
    st=(s*2/(one+s2)).cap0(0,1)
    x=(zeta-qbar)*a-Bbar*b*ct
    y=Bbar*st
    zc=((zeta-qbar)*b+Bbar*a*ct)*lam
    zsq=(x*x+y*y+zc*zc)
    if Dbox.a>0: zsq=zsq.cap0(lam.a*lam.a,100)
    U=(x*x+zc*zc).cap0(0,100)
    hbar=(zeta+r*qbar)*lam
    A0=hbar-zsq*I(ell)*lam
    xiz=(one-qbar*I(ell))*b+Bbar*ct*I(ell)*a
    w2=(one*(lam*lam)+(xiz*xiz).cap0(0,1)*(I(1)-lam*lam)).cap0(lam.a*lam.a,1)
    w=w2.sqrt().cap0(lam.a,1)
    sqz=zsq.sqrt()
    if Dbox.a>0: sqz=sqz.cap0(lam.a,10)
    gam=(hbar/(w*sqz)).cap0(0,1)
    P=((hbar*hbar).cap0(0,100)*U).cap0(0,None)
    Q0=((y*y).cap0(0,100)*(A0*A0).cap0(0,None)).cap0(0,None)
    g0=gam.c[(0,0)]
    dl=gam.nil()
    rd=B.Rderivs(g0)
    Rj=asjet(rd[0],DB)+dl*rd[1]+dl*dl*(rd[2]*I(F(1,2)))
    Rpj=asjet(rd[1],DB)+dl*rd[2]+dl*dl*(rd[3]*I(F(1,2)))
    CR=Rj*2+gam*Rpj
    # exact sum of nonnegative minus nonnegative; no independent-interval eta
    val=Rj*P-CR*Q0
    L3=L*L*L
    Z52=zsq*zsq*sqz
    G=(val*I(64*ell)*z*(one-u*u))/(L3*(one+s2)*w*Z52)
    ans=G.c[(0,0)] if var is None else G.c[(0,2)]*2
    return ans


def bandwork(item):
    lab,i,eps,depth,mode,child,negative=item
    tau=I(F(TL[lab][0]),F(TL[lab][1]));lam=I(F(TL[lab][2]),F(TL[lab][3]))
    dj,dhi=(F(1,32),F(1,16)) if depth=='deep' else (F(1,64),F(1,32))
    dbox=I(dj+(dhi-dj)*F(child,2) if depth=='deep' and mode!='a' else dj,dj+(dhi-dj)*F(child+1,2) if depth=='deep' and mode!='a' else dhi)
    Ui=F(2)**(-12+i);ell=max(dj,Ui)
    n=max(4,int(64*Ui))
    factor=(4 if 3<=i<=8 else 1) if mode=='a' else (2 if i in negative else 1) if mode=='b' else ((4 if 3<=i<=8 else 1)*(2 if i in negative else 1) if mode=='c' else 1)
    n*=factor;ns=32
    mid=I(0); zc=I(0);sc=I(0)
    t0=monotonic()
    for k in range(n):
        za=(Ui+Ui*F(k,n))/ell;zb=(Ui+Ui*F(k+1,n))/ell
        zm=(za+zb)/2;hz=zb-za
        for h in range(ns):
            sa=F(h,ns);sb=F(h+1,ns);sm=(sa+sb)/2;hs=sb-sa;area=hz*hs
            mid+=g_coeff(tau,lam,dbox,11 if depth=='deep' else 10,i,I(zm),I(sm),eps,None)*area
            zc+=g_coeff(tau,lam,dbox,11 if depth=='deep' else 10,i,I(za,zb),I(sa,sb),eps,'z')*I(area*hz*hz/F(24))
            sc+=g_coeff(tau,lam,dbox,11 if depth=='deep' else 10,i,I(zm),I(sa,sb),eps,'s')*I(area*hs*hs/F(24))
    return dict(i=i,eps=eps,mid=str(mid.a),z=str(zc.a),s=str(sc.a),raw=str((mid+zc+sc).a),cells=n*ns,seconds=round(monotonic()-t0,3))

def main():
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--label',choices=['E','M'],default='E');p.add_argument('--workers',type=int,default=16);p.add_argument('--out',default='bench.json');p.add_argument('--depth',choices=['deep','boundary'],default='deep');p.add_argument('--mode',choices=['base','a','b','c'],default='a');p.add_argument('--child',type=int,default=0);p.add_argument('--negative',default='');a=p.parse_args();negative=tuple(int(x) for x in a.negative.split(',') if x)
    start=monotonic();results=[]
    with ProcessPoolExecutor(max_workers=a.workers) as ex:
        fs=[ex.submit(bandwork,(a.label,i,eps,a.depth,a.mode,a.child,negative)) for i in range(12) for eps in (1,-1)]
        for f in as_completed(fs):
            v=f.result();results.append(v);print('BENCH_BAND',v['i'],v['eps'],v['seconds'],flush=True)
    raw=sum((F(v['raw']) for v in results),F(0))
    lam=I(F(TL[a.label][2]),F(TL[a.label][3]));pref=(PI*I(2)*lam).recip()
    H=raw*(pref.a if raw>=0 else pref.b)-CUT
    obj=dict(label=a.label,depth=a.depth,mode=a.mode,child=a.child,negative=negative,workers=a.workers,wall_seconds=round(monotonic()-start,4),
             H_lower=str(H),H_display=float(H),raw_lower=str(raw),
             bands=sorted(results,key=lambda x:(x['i'],x['eps'])),cells=sum(v['cells'] for v in results),
             classification='CALIBRATION_ONLY_NOT_CERTIFIED')
    Path(a.out).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
    print('BENCH_FINAL',json.dumps({k:v for k,v in obj.items() if k!='bands'},ensure_ascii=False),flush=True)
if __name__=='__main__':main()
