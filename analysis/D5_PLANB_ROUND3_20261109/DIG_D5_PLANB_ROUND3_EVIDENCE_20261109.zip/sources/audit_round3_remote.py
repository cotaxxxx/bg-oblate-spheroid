from fractions import Fraction as F
from pathlib import Path
import json,hashlib
import sys;sys.path.insert(0,str(Path(__file__).resolve().parent))
import chat_bprime_iv as B
CUT=F(552960,16777217)
TL={"E":("2/5","41/100"),"M":("1/2","51/100")}
items=list(Path("round3_remote_results").glob("*.json"))
assert len(items)>=17
checked=0
for file in items:
 r=json.loads(file.read_text())
 mode=r["mode"]
 if file.name.startswith("c_union_"):continue
 lab=r["label"];neg=set(r.get("negative",()))
 br=r["bands"]
 assert len(br)==24
 assert {(v["i"],v["eps"]) for v in br}=={(i,e) for i in range(12) for e in (1,-1)}
 ncell=0
 for v in br:
  i=v["i"];Ui=F(2)**(-12+i);n=max(4,int(64*Ui))
  if mode=="a": factor=4 if 3<=i<=8 else 1
  elif mode=="b": factor=2 if i in neg else 1
  elif mode=="c": factor=(4 if 3<=i<=8 else 1)*(2 if i in neg else 1)
  else: factor=1
  assert v["cells"]==n*factor*32,(file,i,v["cells"],n,factor)
  ncell+=v["cells"]
  assert F(v["raw"])==F(v["mid"])+F(v["z"])+F(v["s"]),(file,i)
 assert ncell==r["cells"]
 raw=sum((F(v["raw"]) for v in br),F(0))
 assert raw==F(r["raw_lower"])
 lam=B.I(F(TL[lab][0]),F(TL[lab][1]))
 pref=(B.PI*B.I(2)*lam).recip()
 h=raw*(pref.a if raw>=0 else pref.b)-CUT
 assert h==F(r["H_lower"]),(file,"H aggregate")
 checked+=1
print("AGGREGATE_AND_GRID_CHECKS_OK",checked,"of",len(items),"(c_union excluded)")
