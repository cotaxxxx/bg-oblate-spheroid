from pathlib import Path
from fractions import Fraction as F
import json,subprocess,sys,time
out=Path("round3_remote_results");out.mkdir(exist_ok=True)
jobs=[(lab,dep,child,'base','') for lab in 'EM' for dep,children in [('deep',[0,1]),('boundary',[0])] for child in children]
jobs += [('M','deep',0,'a','')]
def go(lab,depth,child,mode,negative):
    tag=f"{mode}_{lab}_{depth}_child{child}"
    file=out/f"{tag}.json";log=out/f"{tag}.log"
    if file.exists():return json.loads(file.read_text())
    args=[sys.executable,'-u','remote_round3_suite.py','--label',lab,'--depth',depth,'--mode',mode,'--child',str(child),'--negative',negative,'--workers','16','--out',str(file)]
    with log.open('w') as fd: r=subprocess.run(args,stdout=fd,stderr=subprocess.STDOUT)
    if r.returncode:raise RuntimeError((tag,r.returncode,log.read_text()[-2000:]))
    o=json.loads(file.read_text())
    print('DONE',tag,'H',o['H_display'],'WALL',o['wall_seconds'],'N',o['cells'],'NEG',negative,flush=True)
    return o
for lab,dep,child,mode,negative in jobs:go(lab,dep,child,mode,negative)
for lab in 'EM':
 for dep,children in [('deep',[0,1]),('boundary',[0])]:
  for child in children:
   prior=json.loads((out/f"base_{lab}_{dep}_child{child}.json").read_text())
   neg=','.join(str(i) for i in range(12) if sum(F(b['raw']) for b in prior['bands'] if b['i']==i)<0)
   go(lab,dep,child,'b',neg)
   if dep=='deep':go(lab,dep,child,'c',neg)
print('ALL_REMOTE_ROUND3_FINISHED',flush=True)
