from pathlib import Path
from fractions import Fraction as F
import json,hashlib
root=Path("round3_remote_results")
def get(mode,lab,child=0,depth="deep"):
    if mode=="a" and lab=="E":return json.loads(Path("E_deep_method_a_16workers.json").read_text())
    return json.loads((root/f"{mode}_{lab}_{depth}_child{child}.json").read_text())
def v(r):return r["H_display"]
def fmt(x):return f"{x:+.10f}"
def bandrows(r):
    out=[]
    for i in range(12):
        bb=[x for x in r["bands"] if x["i"]==i]
        f=lambda k:sum((F(x[k]) for x in bb),F())
        out.append((i,float(f("raw")),float(f("mid")),float(f("z")),float(f("s")),sum(x["cells"] for x in bb)))
    return out
s=["# Dig: D5 Plan B Grid C 第3回較正 — 2026-11-09",
   "",
   "**CALIBRATION ONLY / NOT_CERTIFIED / NO FULL RUN / NO JUDGE PASS / V4 GENERAL DOMAIN OPEN**",
   "",
   "2026-11-09 JST, daybreak-works, python3 -I, 16-worker ProcessPoolExecutor. The K_n and R derivative functions are unchanged from SHA-pinned B′ v2 source; the new normalised kernel is the same algebraic producer (3.12) as Round 2. The 16-worker code divides each outer box into 12 angular bands × two theta branches and sums exact rational interval lower endpoints. This is *not* an independent mathematical verifier.",
   "",
   "## Method definitions",
   "",
   "- (a) depth [1/32,1/16], grid C with four times the baseline subdivisions for i=3..8; beta=1.",
   "- (b) split parent depth into beta=2 children, evaluate baseline C per child and double all bands with negative baseline raw lower endpoints (per-child selection).",
   "- (c) beta=2 plus both modifications: fourfold i=3..8 and an additional twofold for baseline-negative bands, yielding eightfold subdivisions in their overlap.",
   "- The scale ell is fixed by the parent depth band in both children. The two child minima are compared on the same parent region. Each child pays CUT once. Original face/analytic thin-layer bounds are not added.",
   "",
   "## E and M deep-band results",
   "",
   "| mode | box | child 0 lower | child 1 lower | guaranteed parent lower | child wall time(s) |",
   "|---|---|---:|---:|---:|---|"]
for mode in ("a","b","c"):
 for lab in "EM":
    r0=get(mode,lab)
    r1=get(mode,lab,1) if mode!="a" else None
    vals=[r0]+([r1] if r1 else [])
    s.append(f"| {mode} | {lab} | {fmt(v(r0))} | {fmt(v(r1)) if r1 else '—'} | **{fmt(min(v(x) for x in vals))}** | {' + '.join(str(x['wall_seconds']) for x in vals)} |")
s+=["",
    "## Preceding-depth band [1/64,1/32] with C plus negative-band 2× (beta=1)",
    "",
    "| box | H_B lower | wall time(s) |",
    "|---|---:|---:|"]
for lab in "EM":
 r=get("b",lab,0,"boundary")
 s.append(f"| {lab} | {fmt(v(r))} | {r['wall_seconds']} |")
s+=["", 
    "Both boundary checks remain negative; negative interval lower endpoints do not establish H<0. The deepest representative E and M pass the numerical target H_B>1/20 only under (c) for both, and under (b) for M. These are calibration results, not a certified general-domain result.",
    "",
    "## Angular band breakdown",
    "",
    "Each table combines both branches at each i. Values are decimal presentations of exact rational interval lower endpoints, not replacement proof inputs; full rationals are in JSON. Parent guarantee for beta=2 is the minimum across child 0/1, not an average.",
    ""]
for mode in ("a","b","c"):
 for lab in "EM":
  rr=[get(mode,lab)]
  if mode!="a":rr.append(get(mode,lab,1))
  worst=min(rr,key=v)
  s += [f"### mode {mode} / {lab} — {'child '+str(worst['child']) if mode!='a' else 'parent'}", "", "| i | raw lower | midpoint lower | z-curvature lower | s-curvature lower | both-branch cells |", "|---:|---:|---:|---:|---:|---:|"]
  for i,raw,mid,zc,sc,n in bandrows(worst):
   s.append(f"| {i} | {raw:+.9g} | {mid:+.9g} | {zc:+.9g} | {sc:+.9g} | {n} |")
  s.append("")
s+=["## Boundary-band breakdown", ""]
for lab in "EM":
 r=get("b",lab,0,"boundary")
 s+=[f"### boundary / {lab}", "", "| i | raw lower | midpoint lower | z-curvature lower | s-curvature lower | both-branch cells |", "|---:|---:|---:|---:|---:|---:|"]
 for i,raw,mid,zc,sc,n in bandrows(r):
  s.append(f"| {i} | {raw:+.9g} | {mid:+.9g} | {zc:+.9g} | {sc:+.9g} | {n} |")
 s.append("")
t=get('a','E')['wall_seconds']
s += ["## Wall-time extrapolation — provisional only", "",
   f"Measured (a)/E 16-worker single-box time: {t} s. The empirical (a)/M time is {get('a','M')['wall_seconds']} s. The remote CPU exposes 24 logical CPUs.",
   "",
   "| stage r_in | distinct depth bands | parent boxes | cumulative time at constant a/E sample | incremental time |",
   "|---|---:|---:|---:|---:|"]
last=0
for r,bands,n in [("255/256",8,6656),("63/64",10,8320),("15/16",12,9984)]:
 hrs=n*t/3600;delta=hrs-last
 s.append(f"| {r} | {bands} | {n} | {hrs:.2f} h | +{delta:.2f} h |");last=hrs
s+=["",
    "This is a *conditional planning proxy*, not a predicted proof run. In particular, mode (a) itself fails E/M. Using beta=2 on one full 832-box depth band adds a second child evaluation to those parents. For the deepest band, the measured (c) E parent costs 38.6414+31.4448=70.0862 s instead of 28.6316 s for (a), a sample extra of roughly 9.58 h over 832 boxes. M costs 74.393 s per beta=2 parent (sample extra roughly 10.58 h). Other boxes may behave differently. Full proof costs also require independent verifier time, and boundary-band negative checks cannot be budgeted as certified.",
    "",
    "## Integrity and limitations", "",
    "- `audit_round3_remote.py` verifies 17 current result JSON objects: all 24 branch-band contributions, exact rational aggregation, sign-aware prefactor, one CUT deduction, and method-specific grid factors. A superseded exploratory combined refinement with only max(factors) is not used.",
    "- The 2026-11-08 (round 2) independent aggregate checker is not a mathematical verifier; neither is the present round 3 checker.",
    "- No proof of all 9,984 outer boxes, no V4 freeze, no chat independent verifier, no Muse code audit, no official PASS, no Judge ruling.",
    "- B7 L0_T2_D3/L0_T3_D3 new ZIPs and remaining 11 box runs were not found in the inspected remote workspaces. Official B7 remains 25/40; V5.3 FROZEN.",
    ""]
Path("DIG_D5_PLANB_ROUND3_REPORT_20261109.md").write_text("\n".join(s))
print("REPORT_LINES",len(s))
